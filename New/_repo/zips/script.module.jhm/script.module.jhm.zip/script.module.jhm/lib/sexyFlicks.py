"""

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import os, re, sys, string, json, random, base64

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

convert_special_characters = HTMLParser()
dlg = xbmcgui.Dialog()

from resources.lib.modules.common import *

art = 'special://home/addons/script.module.jhm/lib/resources/art/'
genreImage = 'special://home/addons/script.module.jhm/lib/resources/images/genres/'

channellist=[
        ("[B]If You Dont Stop It Youll Go Blind (1975)[/B]", "dUcDGjdJPPo", 801, "Comedy", "A collection of jokes makes this an hilarious spoof.", fanart),
        ("[B]The Sweet Pussycats (1969)[/B]", "B3RRwbBzkpk", 801, "Classic, Comedy", "(German) An Earl and a Colonel both claim ownership of the same castle by dividing it up with a red line. They bet each other that the first man to bed a local virgin of his choice gets to keep the castle.", fanart),
        ("[B]Doctor Jekyll Likes Them Hot (1979)[/B]", "-EBNp0no1VY", 801, "Comedy", "A lusty young woman decides to use her sexual powers to tame the evil and murderous Dr. Jekyll. ", fanart),
        ("[B]My Darling Slave (1973)[/B]", "QLPJ7c9kVmk", 801, "Comedy, Romance", "Demetrio Cultrera, is a young, rich car dealership Sicilian bachelor who becomes engaged to the beautiful Rosalba Giordano, daughter of a local business owner Giordano Tuna Company.", fanart),
        ("[B]Cavegirl (1985)[/B]", "UOA9Wz66xiQ", 801, "Comedy, Fantasy", "Thanks to a strange crystal, a shy student finds himself in the Stone Age, where he falls in love with a beautiful cave woman and helps her clan stave off a tribe of cannibals.", fanart),
        ("[B]Lucky Bastard (1998)[/B]", "-FLl7HYjUvE", 801, "Crime, Drama, Thriller", "A fan is invited to take part in a porn video with his favourite porn star. He is romantically rejected, and goes on a killing spree on location.", fanart),
        ("[B]The Beach Girls (1982)[/B]", "DV0OU0AXnrA", 801, "Comedy", "School is out, and three girls head to the beach for vacation. Two of the girls are world-wise party-goers who attempt to loosen up their naive, virginal friend", fanart),
        ("[B]Cherry Hill High (1977)[/B]", "FyKYLI44grA", 801, "Comedy", "Five sexy high school graduates try to lose their virginity in a creative manner.", fanart),
        ("[B]Red Light Distict Amsterdam[/B]", "PpRFHIQ4DYE", 801, "Docs", "National Geographics documentary or Amsterdams Red Light District", fanart),
        ("[B]Cheerleader Camp (1988)[/B]", "xjguFaueHOs", 801, "Sports, Comedy, Horror, Thriller", "A group of cheerleaders become the targets of an unknown killer at a remote summer camp.", fanart),
        ("[B]Invasion of the Bee Girls (1973)[/B]", "n5zv516PD4c", 801, "Scifi, Horror", "A powerful cosmic force is turning Earth women into queen bees who kill men by wearing them out sexually.", fanart),
        ("[B]Wonder Women (1973)[/B]", "yC3ekXYq2Ac", 801, "Action, Horror, Scifi", "An insurance investigator battles Dr. Tsu and her sexy all-girl army.", fanart),
        ("[B]The Fear Of Speed (2002)[/B]", "yyJEblBO9Pc", 801, "Comedy, Action", "A low budget spoof of The Fast and the Furious - fast cars, cute girls, drugs, guns and a girl with fear of speed (Tachophobia).", fanart),
        ("[B]Mischief (1985)[/B]", "atP61pHpUwU", 801, "Comedy, Romance", "1956. Obsessed with the hottest girl in class, a gawky high school student takes a crash course in teenage coolness from his motorcycle rebel neighbour, under the watchful eye of the eternal symbol of teenage rebellion: James Dean.", fanart),
        ("[B]Submission (2016)[/B]", "Ctk0mCRgxQg", 801, "Drama, Mystery, Romance", "The sexual awakening chronicles of the beautiful, but unfulfilled Ashley is told in 6 episodes", fanart),
        ("[B]Vixen (1968)[/B]", "ffxXG7U6OV4", 801, "Drama", "Vixen lives in a Canadian mountain resort with her naive pilot husband. While he is away flying in tourists, she gets it on with practically everybody", fanart),
        ("[B]Supervixens (1975)[/B]", "nvDOeSewg1Q", 801, "Comedy", "Clint Ramsey has to leave his job working at Martin Bormanns gas station and flee after his wife is murdered by psycho cop Harry Sledge, who tries to pin the murder on Clint. Crossing America, Clint gets sexually harassed on all sides by various voluptuous nymphomaniacs", fanart),
        ("[B]Private Call (1998)[/B]", "v0Z6xXh2s1o", 801, "Drama, Crime", "In order to avenge the murder of an old friend, a recently suspended female police officer goes undercover at an illegal gambling den where the winning prize is a night with one of the female staff.", fanart),
        ("[B]The Naked Venus (1959)[/B]", "gvVLwKdl7nQ", 801, "Classic, Drama", "A young American painter and his French wife move with their small daughter to the US when the husbands father dies. His mother takes an instant dislike to the wife, and when she finds out that her daughter-in-law is a nudist who once posed naked for an artist", fanart),
        ("[B]Dr. Sex (1964)[/B]", "P4s73NLDBPo", 801, "Classic, Comedy, Scifi", "Three sex researchers discuss their strangest cases.", fanart),
        ("[B]Sex Galaxy (2008)[/B]", "3xxY8gIi9Vk", 801, "Comedy, Scifi", "One hundred years in the future... Due to overpopulation and the effects of global warming, sex has been declared illegal on Earth. ", fanart),
        ("[B]Down and Dirty Duck (1974)[/B]", "T0Qi0s78b98", 801, "Comedy, Fantasy", "Willard, a mild mannered insurance adjuster, teams up with a foul-mouthed fowl who takes Willard on a surreal quest to become less uptight - and possibly get laid in the process.", fanart),
        ("[B]Hey Good Lookin (1982)[/B]", "dxjxTywzF8k", 801, "Comedy, Drama", "An outrageous, affectionate look at coming of age in the Eisenhower era in Brooklyn", fanart),
        ("[B]Wizards (1977)[/B]", "cr56uMIohC8", 801, "Action, Fantasy, Scifi", "On a post-apocalyptic Earth, a wizard and his faire folk comrades fight an evil wizard who is using technology in his bid for conquest.", fanart),
        ("[B]Tarzoon Shame of the Jungle (1975)[/B]", "LsQeT0rUefo", 801, "Comedy, Action", "Shame, the ape man of the jungle, is aghast when his woman, June, is kidnapped by a gang of giant penises. They take her to their queen, Bazunga, a bald woman with fourteen breasts.", fanart),
        ("[B]The Big Bang (1987)[/B]", "4dVA0CYYAAw", 801, "Comedy, Action", "Sex farce about Fred, an inept post WWIII superhero garbageman, who must prevent WW4 by disarming the continents of Virginia, where mutated feminists live, and USSSR, where mutated buttless men live. Beautiful Liberty is his only ally.", fanart),
        ("[B]Heavy Traffic (1973)[/B]", "NrS6gDBaMKA", 801, "Comedy, Drama", "An underground cartoonist contends with life in the inner city, where various unsavory characters serve as inspiration for his artwork.", fanart),
        ("[B]Cry Uncle (1971)[/B]", "S0aCD_n2xJQ", 801, "Comedy, Crime, Mystery", "Private detective takes on a case and gets mixed up in murder, sex and blackmail.", fanart),
        ("[B]Beneath the Valley of the Ultra Vixens (1979)[/B]", "Y3JRu55Bnpk", 801, "Comedy", "Believe it or not even in Smalltown USA there are still people who are unfulfilled and unrelieved in the midst of plenty. Levonna and Lamar could have the perfect relationship if it were not Lamars obsession with rear entry.", fanart),
        ("[B]Girl From Starship Venus (1975)[/B]", "H9E1bn2vffk", 801, "Comedy, Horror, Scifi", "A young Venusian girl lands on Earth to explore the planet. She lands in Soho in London, UK where she has ample opportunities to research sex on Earth.", fanart),
        ("[B]The Playbirds (1978)[/B]", "rxe6u8lbIOg", 801, "Drama, Crime", "Two detectives are drawn into the world of porn, while investigating murders of centrefolds...", fanart),
        ("[B]Planet of Baybes (2013)[/B]", "ChKXUh-JFZw", 801, "Comedy, Scifi, Music", "Sci fi, musical spoof shot in Yorkshire, England on a shoe string budget.", fanart),
        ("[B]The Invisible Maniac (1990)[/B]", "Ds7QfRFlnjA", 801, "Comedy, Horror, Scifi", "A scientist announces his theories of invisibility, and his colleagues laugh, to which he responds by killing 4 of them. He escapes from the loony bin and gets a job teaching summer school physics. The students decide to tease him just as he perfects his invisible juice, and he goes on a spree of vengeance", fanart),
        ("[B]Dr. Minx (1975)[/B]", "wXAMfPMfqUA", 801, "Comedy, Drama, Crime", "A female physician finds no fun in brief affairs. Her luck finally seems to change with her latest lover, but when she learns that he is more interested in her money than her, murder ensues.", fanart),
        ("[B]Attack of the 50 Foot Cheerleader (2012)[/B]", "kgNJfiJs_i0", 801, "Sports, Comedy, Sport", "Cassie Stratford consumes an experimental drug that grants her beauty and enough athletic ability to make the cheer squad. The drug has an unforeseen side effect - Cassie starts to grow and grow and grow.", fanart),
        ("[B]Lap Dancing (1995)[/B]", "YdgajREYcAU", 801, "Drama", "Angie is having no luck auditioning for movies. She thinks about going back home, but her roommate Claudia convinces her to try working at the gentlemans club with her in order to gain more life experience. Angie hopes to be able to turn the experience toward more effective acting but ", fanart),
        ("[B]Lady Frankenstein (1971)[/B]", "XpDdQERwto0", 801, "Horror", "Baron Frankenstein (Joseph Cotten) is hard at work trying to reanimate human tissue when his daughter, Tania (Rosalba Neri), comes home from university with a medical degree and announces that it has always been her intention to carry on her fathers work.", fanart),
        ("[B]Stuck on You (1982)[/B]", "sc3u2rb0Sjg", 801, "Comedy, Romance", "A couple with marriage problems goes to Family Court, where a judge takes them back in time to view lovers through the ages.", fanart),
        ("[B]Taking It All Off (1987)[/B]", "S8rz140zNIw", 801, "Comedy", "A school for strippers is in financial trouble. They audition for The Big Strip Joint Owner, and he is pleased, except that the new girl can not make herself take her clothes off", fanart),
        ("[B]Deep End (1970)[/B]", "8GloyJ9IGao", 801, "Comedy, Drama, Romance", "15-year-old dropout Mike takes a job at Newford Baths, where inappropriate sexual behaviour abounds, and becomes obsessed with his coworker Susan.", fanart),
        ("[B]Blond Heaven (1995)[/B]", "bxYuy19tSoI", 801, "Horror", "A coven of vampires operates out of a modeling - escort agency known as Blonde Heaven.", fanart),
        ("[B]Unkissed Bride (1966)[/B]", "EwV1yVELoPk", 801, "Classic, Comedy", "A young couples honeymoon is disrupted by the grooms childhood obsession with Mother Goose. Unable to consummate the marriage, they head off to the psychiatrist, where the fun really begins (LSD as a treatment!?!).", fanart),
        ("[B]Spaced Out (1979)[/B]", "mMdLFzZRyKI", 801, "Comedy, Scifi", "Low-budget aliens (three nice-looking women and a gay computer voice-over) crash-land in England and abduct four earthlings.", fanart),
        ("[B]Whos Your Daddy (2004)[/B]", "i7k4cPj0Wgw", 801, "Comedy", "Chris Hughes, an awkward high school student struggling to be popular, suddenly finds himself the unwitting heir and appointed mogul of a vast, multimillion-dollar adult entertainment media empire left to him by the biological parents he never knew.", fanart),
        ("[B]Taking It Off (1985)[/B]", "FTlQhZ62wYQ", 801, "Comedy", "A stripper named Betty Bigones wants to be an actress, but is informed by her agent that her large breasts are keeping her from getting parts.", fanart),
        ("[B]Hot Moves (1984)[/B]", "t4lTYI6AQKQ", 801, "Comedy", "Four Venice Beach boys make a pact to lose their virginity before beginning their senior year of high school.", fanart),
        ("[B]Spanking the Monkey (1994)[/B]", "l6liQi9giM0", 801, "Comedy, Drama", "Susan is a troubled woman, and along with Raymonds own emotional strains, it leads them to intimate physical contact, which Raymond finds uneasy. He soon meets a high school girl, Toni, but his ability to handle starting a relationship with her is difficult", fanart),
        ("[B]Private Obsession (1995)[/B]", "NdDJyLj8ckc", 801, "Drama, Thriller", "Emanuelle, a world famous fashion model, is held captive by Richard Tate, a crazed fan. Richard wants her for himself but Emanuelle uses her assets to try and escape.", fanart),
        ("[B]Crazy Little Thing (2002)[/B]", "lY0RjYRd1VM", 801, "Comedy, Romance", "A waiter/writer living with his dad and a neat freak who has just landed a job as a reporter in New York, meet by colliding on the Brooklyn Bridge, and romance ensues.", fanart),
        ("[B]Hollywood Hot Tubs (1984)[/B]", "jn_F1vDOwRk", 801, "Comedy", "A young man gets a job repairing hot tubs for the rich and famous in Tinseltown, thanks to his parents. As he moves from one bubbly tub to the next, sexual situations change accordingly.", fanart),
        ("[B]Recruits (1986)[/B]", "zJ6isUDUdM8", 801, "Comedy", "A Canadian sex comedy in the tradition of Police Academy", fanart),
        ("[B]Pink Motel (1982)[/B]", "o_4lzG6wL8c", 801, "Comedy", "A couple who own and run a cheap motel have to put up with an assortment of weirdos and perverts who rent rooms there on a Friday night.", fanart),
        ("[B]Disco Beaver From Outer Space (1979)[/B]", "eeVyOuDYrks", 801, "Comedy, Horror, Fantasy", "National Lampoons mockery of everything that is wrong with cable TV.", fanart),
        ("[B]A Nymphoid Barbarian From Dinosaur Hell (1990)[/B]", "7fw9a96Ei0k", 801, "Fantasy, Horror, Scifi", "In a post-Armageddon world, a young woman finds herself in a fight for survival against mutant cavemen, dinosaurs and other prehistoric animals.", fanart),
        ("[B]Come Undone (2010)[/B]", "Lq9mQ5_Ct-s", 801, "Drama, Romance", "One day at a colleagues going away party, Anna meets Domenico, a virile, slightly older chap who is married with two small kids. Passions flames are rapidly kindled and result in steamy encounters.", fanart),
        ("[B]Blood Sisters (1987)[/B]", "0tVCHNQZY88", 801, "Horror, Thriller", "Seven girls must spend the night in an old house, which once was a brothel, as part of an initiation.", fanart),
        ("[B]Im Not Feeling Myself Tonight (1976)[/B]", "d49607kIJGc", 801, "Comedy", "Virginal nerd Jon Pigeon works in a peculiar sex research institute in which patients run about the corridors naked, nude aerobics are encouraged and where no man is safe from a crotch", fanart),
        ("[B]All Ladies Do It (1992)[/B]", "F7Zf0Xnnaos", 801, "Comedy, Drama", "Italian - A happily married 24-year-old woman who experiences an inexplicable, rather restless craving to finally live her life intensely, retells her extra-marital escapades to her husband intending to spice up their marriage.", fanart),
        ("[B]Play Motel (1979)[/B]", "sKYGHjFJBjM", 801, "Crime, Drama, Comedy", "A reporter and his girlfriend investigate deaths surrounding a hotel where several prominent people go to have sex", fanart),
        ("[B]A Woman For All Men (1975)[/B]", "zyetLw6nek4", 801, "Drama, Crime", "Irascible and domineering millionaire Walter McCoy marries the beautiful, but shady and duplicitous Karen Petrie. Walters son Steve automatically becomes smitten with Karen while both Walters daughter Cynthia suspect that something is up. This provokes a tangled web of deception, infidelity, and even murder.", fanart),
        ("[B]Cougar Hunting (2011)[/B]", "oJO15FYAdi0", 801, "Comedy", "Tells the tale of three buddies in their 20s whose love-lives are in shambles. They go to Aspen to pursue the booming trend of dating cougars: hot older women who prey on hot young guys.", fanart),
        ("[B]Die Watching (1993)[/B]", "uDzYAy2BfK4", 801, "Romance, Thriller", "A serial killer who makes his living as an adult video maker/editor, becomes involved with an artist neighbour. He tries to keep his secret from her, but the police are slowly closing in on him.", fanart),
        ("[B]Love & Sex (2000)[/B]", "DRN_geRk-Cs", 801, "Comedy, Drama, Romance", "Kate is fired from a womens magazine for writing about BJs, based on own experience as requested. She gets a last chance - 2500 happy, perky words on finding/keeping that perfect man. She tells about her relationships.", fanart),
        ("[B]Alice in Wonderland (1976)[/B]", "mIarEXmbx_4", 801, "Music, Fantasy", "X Rated version of Alice in Wonderland", fanart),
        ("[B]Emanuelle and the Last Cannibals (1977)[/B]", "2oPfifnhGNo", 801, "Horror, Action", "A female journalist decides to traverse the Amazon Jungle after going undercover in a mental asylum and witnessing a disturbing behavior from a rescued white woman, who she believes was raised by a cannibalistic tribe long thought extinct.", fanart),
        ("[B]Wicket City (1987)[/B]", "k6rRjNInBkU", 801, "Anime, Horror, Fantasy", "Two agents - a lady-killer human and a voluptuous demon - attempt to protect a signatory to a peace ceremony between the human world and the Black World from radicalized demons. ", fanart),
        ("[B]Lady Death (2004)[/B]", "bNIHrhYtuxs", 801, "Anime, Action, Fantasy", "Based on a comic book series. A woman burned at the stake in 15th century Sweden actually is Lucifers daughter - and plots revenge against him.", fanart),
        ("[B]Vampire Wars (1990)[/B]", "dh7W6euTIsw", 801, "Anime, Action, Crime", "First, a brutal terrorist attack on a NASA base takes place deep in the Arizona desert. Then ten days later, the corpse of a CIA man is found floating in the Seine in Paris.", fanart),
        ("[B]Up! (1976)[/B]", "7pYBFfCosgA", 801, "Comedy", "This kicks off with the murder of one Adolf Schwartz by placing a ravenous piranha fish in his bathtub. Who did it? No-one knows or cares, as they are too busy being distracted by busty Margo Winchester, who hitch-hikes into town", fanart),
        ("[B]All American Bikini Car Wash (2015)[/B]", "MKh4AOipuOw", 801, "Comedy", "An enterprising college student agrees to run his professors Las Vegas car wash to avoid flunking out of school. But its Vegas gone wild when he decides to staff it with gorgeous bikini-clad girls. ", fanart),
        ("[B]Castaway (1986)[/B]", "8tt6d9b5hHA", 801, "Drama,Action", "Middle-aged Gerald Kingsland advertises in a London paper for a female companion to spend a year with him on a desert island.", fanart),
        ("[B]Cinderella 2000 (1977)[/B]", "VZxd6-16fUA", 801, "Music, Scifi", "In the year 2047, sex is forbidden and Big Brother uses robots to keep on eye on everyone. One young girl tries to outwit the government so she can be with the man she loves.", fanart),
        ("[B]Twisted Seduction (2010)[/B]", "0QUwSlqKsak", 801, "Comedy, Romance, Thriller", "Genius British guy kidnaps a woman and is convinced that by following certain psychological steps and well planned charm, her brain will have no choice but to trigger feelings of love towards him.", fanart),
        ("[B]Slave Girls From Beyond Infinity (1986)[/B]", "KAlyETmWrkY", 801, "Comedy, Action", "Lovely and resourceful Daria and Tisa escape a space gulag only to crash land on a nearby world where a guy in tight pants named Zed is playing The Most Dangerous Game.", fanart),
        ("[B]Joysticks (1983)[/B]", "BYtqvSTWmGg", 801, "Comedy", "When a top local businessman and his two bumbling nephews try to shut down the towns only video arcade, arcade employees and patrons fight back.", fanart),
        ("[B]The Vampire Lovers (1970)[/B]", "y1i7rMi9ZJc", 801, "Horror", "Seductive vampire Carmilla Karnstein and her family target the beautiful and the rich in a remote area of late eighteenth-century Gemany.", fanart),
        ("[B]Lured Innocents (2000)[/B]", "ILIBdrBK5co", 801, "Drama, Thriller", "Elsie Townsend is a country towns-girl who wants to leave far away and get rich. She becomes the spoiled mistress of married local businessman Rick Chambers", fanart),
        ("[B]The Hitchhikers (1972)[/B]", "m45crVMbtCw", 801, "Action, Drama", "Maggie learns she is pregnant so she runs away from home. Before long she gets involved with some other girls on their own who have found a way of supporting themselves. She joins them in hitchhiking around wearing sexy outfits and robbing the men who pick them up on the road.", fanart),
        ("[B]Sorority Babes in the Slimeball Bowl-O-Rama (1988)[/B]", "itQM4AL-O-4", 801, "Sports, Comedy, Horror", "As part of a sorority ritual, pledges and their male companions steal a trophy from a bowling alley; unbeknownst to them, it contains a devilish imp who makes their lives a living Hell.", fanart),
        ("[B]Dinosaur Island (1994)[/B]", "MoP5NgQN6V8", 801, "Action, Fantasy, Comedy", "An army captain is flying three misfit deserters home for a court martial when the plane has engine trouble and they must land on an uncharted island. There they find a primitive society of cave women who routinely sacrifice virgins", fanart),
        ("[B]The Swinging Cheerleaders (1974)[/B]", "qfB09KqzfQw", 801, "Comedy, Sports", "In order to write an expose on how cheerleading demeans women, a reporter for a college newspaper infiltrates the cheerleading squad.", fanart),
        ("[B]Manhandlers (1974)[/B]", "jZiiVd4UWJE", 801, "Crime, Action, Drama", "A gorgeous girl named Katie inherits her deceased uncles business and decides that she too can be a businesswoman and hire two hot girlfriends. Katie does not like the brothel part so she gets rid of that and is soon giving legit massages.", fanart),
        ("[B]The Roomates (1973)[/B]", "KBfX39ki3mY", 801, "Crime, Drama, Thriller", "Heather, Beth, Carla, Brea, and Paula are five lovely ladies who decide to spend their summer vacation at Lake Arrowhead. While there the women hit the party circuit and get involved with various men. However, things go awry when the gals find themselves the targets of a mysterious murderer.", fanart),
        ("[B]The Body Shop (1972)[/B]", "Esm2NHDviv4", 801, "Comedy", "Emminent plastic surgeon and mad scientist Don Brandon loses his wife Anitra - pinup model and social butterfly - in a tragic accident. He and his faithful humpbacked and drooling assistant Igor - oops, I mean Greg - busy themselves experimenting with re-animation experiments.", fanart),
        ("[B]Amazon Warrior (1998)[/B]", "gjEblPgw5QI", 801, "Action, Scifi", "A  post-apocalyptic world, a camp of Amazon women is raided by a gang of murderous bandits, who kill everyone in the camp except one small girl. She grows up to be a mercenary, and one day she takes a job escorting the two daughters of a powerful warlord across a river. ", fanart),
        ("[B]She (1984)[/B]", "YoxcpyXriEM", 801, "Action, Fantasy", "In a post-apocalyptic world, She aids two brothers quest to rescue their kidnapped sister. Along the way, they battle weird creatures before standing against the odds to defeat the evil Norks.", fanart),
        ("[B]Attack of the 60ft Centerfold (1995)[/B]", "_vG0mi7aOho", 801, "Action, Comedy", "A magazine centerfold overdoses on a beauty-enhancement drug and grows 60 feet tall.", fanart),
        ("[B]Caged Heat (1974)[/B]", "vXf_Q5NC-Ns", 801, "Action, Drama, Comedy", "In a womens prison, a group of inmates band together to combat the repressive and abusive policies of the warden.", fanart),
        ("[B]Barbarian Queen II (1990)[/B]", "HXfv3rLuLmw", 801, "Action, Fantasy", "In a final and epic battle in the thrilling sequel to the now classic Barbarian Queen, Althalia, leads a revolt of peasants and female warriors against the wicked ruler, Arkaris, to regain her throne.", fanart),
        ("[B]Barbarian Queen (1985)[/B]", "Z6Z1SvfCWTc", 801, "Action, Fantasy", "The sword-wielding warrior, Amethea, embarks on a life-or-death mission to liberate her sister from the clutches of an evil monarch. However, only torture and death await her.", fanart),
        ("[B]Corrupted (1973)[/B]", "iQ4b6j5sxzY", 801, "Drama", "A story concerns the love that develops between a young woman employee and a customer at a very unusual photo shop. The store in question invites men in to take pictures of naked women.", fanart),
        ("[B]Swap Meet (1979)[/B]", "49AuoWyoW6Y", 801, "Comedy", "A brainless teen comedy, pepped up with a few moderate erotic scenes.", fanart),
        ("[B]A Taste For Women (1964)[/B]", "uwf_fIWvCCo", 801, "Classic, Comedy, Crime", "A secret sect of cannibals owns a vegetarian restaurant, which they use as a cover so they can find a beautiful young woman to serve as the main course at their full-moon sacrifice.", fanart),
        ("[B]The Hot Box (1972)[/B]", "r6y2OIe5ikg", 801, "Action, Drama", "Hot action and lust in the steamy tropical jungle, as heroines break out of a womens prison and start a local revolution.", fanart),
        ("[B]The Man From O.R.G.Y. (1970)[/B]", "scFHr2U1x3k", 801, "Comedy, Crime", "A rich man suddenly dies and leaves his vast fortune to a Madam who played a number of female stars for him. She dies too, and leaves her inheritance to her top three girls, all living in different parts of the world - and the map to the fortune location can be uncovered only when their three bottoms are placed together.", fanart),
        ("[B]Nude on the Moon (1961)[/B]", "czxgLpcFovg", 801, "CLassic, Fantasy, Scifi", "A rich rocket scientist organizes an expedition to the moon, which they discover is inhabited by nude women.", fanart),
        ("[B]The Boob Tube (1975)[/B]", "XvThHBZUCrA", 801, "Comedy", "In Live Action, young psychiatrist Henry Carstairs moves into an apartment building filled with lonely, sex starved women. This soap is interrupted several times by sexy ads.", fanart),
        ("[B]Love on the Side (2004)[/B]", "0wgI4PocHEI", 801, "Comedy, Romance", "A small-town waitress vies with a sassy city slicker for the attention of the towns most eligible bachelor.", fanart),
        ("[B]The Swinging Barmaids (1975)[/B]", "AOF4ikg_2DY", 801, "Crime, Drama", "A deranged serial killer infiltrates a popular club and slowly starts killing cocktail waitresses.", fanart),
        ("[B]Just a Little Harmless Sex (1998)[/B]", "pG9kdDzctY8", 801, "Comedy, Romance", "A strictly monogamous man stops to help a stranded female with a broken down car. In gratitude she offers oral sex, when he reluctantly accepts. However, just as they get involved, the cops show up", fanart),
        ("[B]Gimme a F (1984)[/B]", "6EfS8fFi9BY", 801, "Comedy, Sports", "Can a squad of misfit cheerleaders with an over-age trainer possibly win the big cheerleading competition? Looked down upon by the other teams, it will be an difficult.", fanart),
        ("[B]The Groove Tube (1974)[/B]", "IKBryUZIPCc", 801, "Comedy", "A collection of skits that make fun of 1970s television, featuring early appearances by Chevy Chase and Richard Belzer.", fanart),
]

#=====================================

class sexyListing:

    @staticmethod
    def Genres(type):
		
        #errorMsg="%s" % (type)
        #xbmcgui.Dialog().ok("type", errorMsg)

        for name, url, zmode, genre, desc, fanart in sorted(channellist, reverse=False):

            addIt=False
            if type is "All":
                icon=genreImage+"All.png"
                addIt=True

            elif "Action" in genre and type is "Action":
                icon=genreImage+"Action.png"
                addIt=True

            elif "Anime" in genre and type is "Anime":
                icon=genreImage+"Anime.png"
                addIt=True

            elif "Classic" in genre and type is "Classic":
                icon=genreImage+"Classic.png"
                addIt=True

            elif "Comedy" in genre and type is "Comedy":
                icon=genreImage+"Comedy.png"
                addIt=True

            elif "Crime" in genre and type is "Crime":
                icon=genreImage+"Crime.png"
                addIt=True

            elif "Docs" in genre and type is "Docs":
                icon=genreImage+"Documentary.png"
                addIt=True

            elif "Drama" in genre and type is "Drama":
                icon=genreImage+"Drama.png"
                addIt=True

            elif "Romance" in genre and type is "Romance":
                icon=genreImage+"Romance.png"
                addIt=True

            elif "Fantasy" in genre and type is "Fantasy":
                icon=genreImage+"Fantasy.png"
                addIt=True

            elif "Horror" in genre and type is "Horror":
                icon=genreImage+"Horror.png"
                addIt=True

            elif "Music" in genre and type is "Music":
                icon=genreImage+"Music.png"
                addIt=True

            elif "Mystery" in genre and type is "Mystery":
                icon=genreImage+"Mystery.png"
                addIt=True

            elif "Scifi" in genre and type is "Scifi":
                icon=genreImage+"Scifi.png"
                addIt=True

            elif "Sports" in genre and type is "Sports":
                icon=genreImage+"Sports.png"
                addIt=True
				
            elif "Thriller" in genre and type is "Thriller":
                icon=genreImage+"Thriller.png"
                addIt=True

            elif "Western" in genre and type is "Western":
                icon=genreImage+"Western.png"
                addIt=True

            elif "Zombie" in genre and type is "Zombie":
                icon=genreImage+"Zombie.png"
                addIt=True
		
            if addIt==True:
                name = name +" | " +desc
				
                #MyAddLink(name, url, zmode, icon, fanart, desc)				
                addLink(name,url,zmode,icon,fanart)
                #if desc:
                    #add_link_info(desc, "", fanart)

				
#=====================================

