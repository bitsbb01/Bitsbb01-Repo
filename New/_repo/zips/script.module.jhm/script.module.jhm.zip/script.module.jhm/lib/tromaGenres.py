"""

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import os, re, sys, string, json, random, base64

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

convert_special_characters = HTMLParser()
dlg = xbmcgui.Dialog()

from resources.lib.modules.common import *

genreImage = 'special://home/addons/script.module.jhm/lib/resources/images/genres/'

channellist=[
        ("[B]Cannibal: The Musical[/B]", "3COBeoWejmA", 801, "Comedy", icon, fanart),
        ("[B]Dark Nature[/B]", "-IjvHgPYe98", 801, "Horror", icon, fanart),
        ("[B]Def By Temptation[/B]", "j_JQeA6PiwA", 801, "Horror", icon, fanart),
        ("[B]Klown Kamp Massacre[/B]", "FE5HNZFtimc", 801, "Horror", icon, fanart),
        ("[B]Decampitated[/B]", "FKQJkJpdCnI", 801, "Comedy", icon, fanart),
        ("[B]Banana Motherf*ck*r[/B]", "BzoAiiBeW8A", 801, "Comedy", icon, fanart),
        ("[B]Ghosts Of The Heartland[/B]", "GWf_tydTTnA", 801, "Thriller", icon, fanart),
        ("[B]Another Space Daze[/B]", "2PdM8fci4iM", 801, "Scifi", icon, fanart),
        ("[B]Connect 5[/B]", "GoNpbChQ6bo", 801, "Horror", icon, fanart),
        ("[B]Blood Junkie[/B]", "hxGVs01M9EE", 801, "Horror", icon, fanart),
        ("[B]Viewer Discretion Advised[/B]", "j8yBz3xIzkY", 801, "Comedy", icon, fanart),
        ("[B]A Nymphoid Barbarian In Dinosaur Hell[/B]", "7fw9a96Ei0k", 801, "Scifi", icon, fanart),
        ("[B]Troma: Ellie[/B]", "H8VNwTLCv1k", 801, "Thriller", icon, fanart),
        ("[B]Troma: Fag Hag[/B]", "h-Htv8y7xSA", 801, "Comedy", icon, fanart),
        ("[B]Fatty Drives The Bus[/B]", "N0Dt9i9IUNg", 801, "Comedy", icon, fanart),
        ("[B]Ferocious Female Freedom Fighters[/B]", "HCljpl9EOpw", 801, "Action", icon, fanart),
        ("[B]Frightmare[/B]", "tEJKx6SpXu0", 801, "Horror", icon, fanart),
        ("[B]Graduation Day[/B]", "QlmtF3oe1HM", 801, "Horror", icon, fanart),
        ("[B]Troma: Bigfoot[/B]", "5fLmxV9bXr4", 801, "Scifi", icon, fanart),
        ("[B]Hot Summer In Barefoot County[/B]", "0SNPzXLxIvo", 801, "Comedy", icon, fanart),
        ("[B]Wizards Of The Demon Sword[/B]", "lqTpKEju95M", 801, "Fantasy", icon, fanart),
        ("[B]Jurassic Women[/B]", "scWyknOtfbs", 801, "Scifi", icon, fanart),
        ("[B]Macabre Pair Of Shorts[/B]", "9TEVgyiQpZE", 801, "Comedy", icon, fanart),
        ("[B]Horror Of The Hungry Humongous Hungan[/B]", "Jma_o6vX72Y", 801, "Scifi", icon, fanart),
        ("[B]Blood Hook[/B]", "4VI7ntoJNEk", 801, "Horror", icon, fanart),
        ("[B]Tromas War[/B]", "yfDzF2oN7Tc", 801, "Action", icon, fanart),
        ("[B]When Nature Calls[/B]", "zM-sr-hSiV8", 801, "Comedy", icon, fanart),
        ("[B]Beyond Evil[/B]", "zlMl-SUGBjI", 801, "Horror", icon, fanart),
        ("[B]Beware Children At Play[/B]", "dau1jqsdhl4", 801, "Horror", icon, fanart),
        ("[B]Troma: Grim[/B]", "WsPrVbXYgcU", 801, "Horror", icon, fanart),
        ("[B]Rock & Roll Space Patrol[/B]", "z1L87pKMKzE", 801, "Music", icon, fanart),
        ("[B]Killer Yacht Party[/B]", "FEUE1dbwqRI", 801, "Horror", icon, fanart),
        ("[B]Luther The Geek[/B]", "W82sjP_mIQY", 801, "Horror", icon, fanart),
        ("[B]Where Evil Lives[/B]", "ijKfFvdt0L0", 801, "Horror", icon, fanart),
        ("[B]A Tale Of Two Sisters[/B]", "IjvMU0Bt46I", 801, "Fantasy", icon, fanart),
        ("[B]Igor And The Lunatics[/B]", "mJkRQHX3brw", 801, "Horror", icon, fanart),
        ("[B]Troma: Lollilove[/B]", "KktVoWlsj1E", 801, "Comedy", icon, fanart),
        ("[B]Madigans Millions[/B]", "eleqXRSnUmY", 801, "Comedy", icon, fanart),
        ("[B]Actium Maximus: War Of The Alien Dinosaurs[/B]", "6Zor9h7bfy8", 801, "Scifi", icon, fanart),
        ("[B]Troma: Bugged[/B]", "iCorDG3OHuU", 801, "Scifi", icon, fanart),
        ("[B]Attack Of The Tromaggot[/B]", "UYwhQVlXQQ8", 801, "Horror", icon, fanart),
        ("[B]Hollowgate[/B]", "BzoAiiBeW8A", 801, "Horror", icon, fanart),
        ("[B]Wiseguys VS Zombies[/B]", "V895cCmwcbU", 801, "Zombie", icon, fanart),
        ("[B]Big Gus Whats The Fuss[/B]", "zS2EgumLXXE", 801, "Crime", icon, fanart),
        ("[B]Troma: Bloodspit[/B]", "Xcthxl8lVzA", 801, "Horror", icon, fanart),
        ("[B]Video Demons Do Psychotown[/B]", "GFTi49b9eus", 801, "Scifi", icon, fanart),
        ("[B]Doggie Tails[/B]", "VirQxX9QGHw", 801, "Fantasy", icon, fanart),
        ("[B]I Was A Teenage TV Terrorist[/B]", "Eay9cz3kXCI", 801, "Crime", icon, fanart),
        ("[B]Baconhead[/B]", "CMZcmdL6Pzc", 801, "Comedy", icon, fanart),
        ("[B]Battle of Loves Return[/B]", "RVKgsM6Eiug", 801, "Comedy", icon, fanart),
        ("[B]The Wedding Party[/B]", "TEfHuo2MdKU", 801, "Comedy", icon, fanart),		
        ("[B]Back Road Diner[/B]", "lU1UFx8-92o", 801, "Horror", icon, fanart),
        ("[B]The Evolved Part 1[/B]", "oJ0KDTujx7U", 801, "Horror", icon, fanart),
        ("[B]Troma: Pyro[/B]", "ZiZkc0PjKzo", 801, "Horror", icon, fanart),
        ("[B]Viral Assasins[/B]", "t-W9TXDOpy0", 801, "Scifi", icon, fanart),
        ("[B]Splendor And Wisdom[/B]", "OlPP0-6qqVU", 801, "Documentary", icon, fanart),
        ("[B]The Butchers[/B]", "0DsS0pdS-Dk", 801, "Horror", icon, fanart),
        ("[B]Troma: Jefftowne[/B]", "7Tyz2u1Amys", 801, "Documentary", icon, fanart),
        ("[B]Space Zombie Bingo[/B]", "W9bPOXpqq30", 801, "Zombie", icon, fanart),
        ("[B]They Call Me Macho Woman[/B]", "jnVtQb0NrgY", 801, "Action", icon, fanart),
        ("[B]Troma: Pep Squad[/B]", "CWssk2UTPJo", 801, "Comedy", icon, fanart),
        ("[B]Invasion Of The Space Preachers[/B]", "57F44ECk-iM", 801, "Scifi", icon, fanart),
        ("[B]Nerds Of A Feather[/B]", "ZPlMd9FOSmI", 801, "Thriller", icon, fanart),
        ("[B]Redneck Zombies[/B]", "pXuZXp_U0WQ", 801, "Zombie", icon, fanart),
        ("[B]Nightbeast[/B]", "CjSdZT1zufI", 801, "Horror", icon, fanart),
        ("[B]Contra Conspiracy[/B]", "JLoRFWyLkdQ", 801, "Action", icon, fanart),
        ("[B]Fear Town USA[/B]", "FyBlE3jOMQw", 801, "Horror", icon, fanart),
        ("[B]Toxic Avenger II[/B]", "LBYcmNSv1RQ", 801, "Comedy", icon, fanart),
        ("[B]Toxic Avenger III[/B]", "PV3UUt-0RBM", 801, "Comedy", icon, fanart),
        ("[B]Toxic Avenger IV[/B]", "4roVT6QK-OY", 801, "Comedy", icon, fanart),
        ("[B]Toxic Avenger[/B]", "TyrzsAfr8dE", 801, "Comedy", icon, fanart),
        ("[B]Class Of Nuke Em High[/B]", "_hhSnjzYvMw", 801, "Horror", icon, fanart),
        ("[B]Frog Monster From Hell[/B]", "B3Bmy3I4O9I", 801, "Horror", icon, fanart),
        ("[B]Stuck On You[/B]", "sc3u2rb0Sjg", 801, "Scifi", icon, fanart),
        ("[B]Coons, Night Of The Bandits Of The Night[/B]", "HY8Ln05PZmw", 801, "Horror", icon, fanart),
        ("[B]Class Of Nuke Em High II[/B]", "-2s1TlGSWjY", 801, "Horror", icon, fanart),
        ("[B]Class Of Nuke Em High III[/B]", "AB_ll3X6-x4", 801, "Horror", icon, fanart),
        ("[B]Video Vixens[/B]", "-3jXwec34BU", 801, "Horror", icon, fanart),
        ("[B]Squeeze Play[/B]", "tBjXnIQefGU", 801, "Comedy", icon, fanart),
        ("[B]Blood Boobs N Beast[/B]", "3iFi8EcDg7o", 801, "Documentary", icon, fanart),
        ("[B]Mothers Day[/B]", "XJlpqk_uXtQ", 801, "Horror", icon, fanart),
        ("[B]State Of Mind[/B]", "33GzdFK7fuY", 801, "Horror", icon, fanart),
        ("[B]Dead Dudes In The House[/B]", "wNZHms_OHqs", 801, "Horror", icon, fanart),
        ("[B]Surf Nazis Must Die[/B]", "CnWOnBaVtow", 801, "Scifi", icon, fanart),
        ("[B]Rockabilly Vampire[/B]", "0uy2hO_iGus", 801, "Horror", icon, fanart),
        ("[B]Theres Nothing Out There[/B]", "9y8aXXCsz8k", 801, "Horror", icon, fanart),
        ("[B]Reel Horror[/B]", "My3TrFAuhWE", 801, "Horror", icon, fanart),
        ("[B]Rabid Grannies[/B]", "kexYPMWIfwE", 801, "Horror", icon, fanart),
        ("[B]The Media Madman[/B]", "DFo4TvgyUFg", 801, "Horror", icon, fanart),
        ("[B]Curse Of The Cannibal Confederates[/B]", "WZ2B2oFcTI8", 801, "Horror", icon, fanart),
        ("[B]Psycho Sleepover[/B]", "mekP8mvJSuU", 801, "Horror", icon, fanart),
        ("[B]Troma: Badmouth[/B]", "w5smqiQ6deE", 801, "Zombie", icon, fanart),
        ("[B]Teenape VS The Monster Nazi Apocalypse[/B]", "dHwBeSGRzwA", 801, "Scifi", icon, fanart),
        ("[B]The Seduction Of Dr. Fugazzi[/B]", "e77iWeB-m_k", 801, "Thriller", icon, fanart),
        ("[B]Sgt. Kabukiman N.Y.P.D.[/B]", "XrBpISZgKyQ", 801, "Comedy", icon, fanart),
        ("[B]The Ruining[/B]", "-Luz8MVpBzY", 801, "Horror", icon, fanart),
        ("[B]Maniac Nurses Find Ecstacy[/B]", "JP0wjX3rOpU", 801, "Comedy", icon, fanart),
        ("[B]Superstarlet A.D.[/B]", "3HR2FdLGRy8", 801, "Music", icon, fanart),
        ("[B]The Children[/B]", "2K-UbThK5_I", 801, "Zombie", icon, fanart),
        ("[B]Troma: Cry Uncle[/B]", "dsMxWHbHYaI", 801, "Comedy", icon, fanart),
        ("[B]Preacherman[/B]", "-C7u8pCZ6H8", 801, "Comedy", icon, fanart),
        ("[B]Meat For Satans Icebox[/B]", "WuNLXe0yxkM", 801, "Horror", icon, fanart),
        ("[B]Crazy Animal[/B]", "DF0Ax8bXzpE", 801, "Music", icon, fanart),
        ("[B]Troma: Foreplay[/B]", "YxOKAIeGmSI", 801, "Comedy", icon, fanart),
        ("[B]Getting Lucky[/B]", "ZWwukWsLnP8", 801, "Fantasy", icon, fanart),
        ("[B]Blood Oath[/B]", "O49rj8q7CvU", 801, "Horror", icon, fanart),
        ("[B]Slaughter Party[/B]", "CX7uc_t4YJw", 801, "Horror", icon, fanart),
        ("[B]Story Of A Junkie[/B]", "3mmHtmHEBz0", 801, "Documentary", icon, fanart),
        ("[B]Troma: Belcebu[/B]", "jZD_BY7941o", 801, "Scifi", icon, fanart),
        ("[B]Legend Of The Chupacabra[/B]", "KjqcJIDWWSY", 801, "Horror", icon, fanart),
        ("[B]The Stabilizer[/B]", "S8Z4NFGTt2A", 801, "Action", icon, fanart),
        ("[B]Savage Abduction[/B]", "a1W6di81b94", 801, "Thriller", icon, fanart),
        ("[B]The Hall Monitor[/B]", "81ceeIyvros", 801, "Action", icon, fanart),
        ("[B]Troma: Large[/B]", "lfo3BVmCk6A", 801, "Comedy", icon, fanart),
        ("[B]Theatre Of The Deranged II[/B]", "ZeOFRKwCee4", 801, "Thriller", icon, fanart),
        ("[B]Vegas In Space[/B]", "sLUE_Fz5SNY", 801, "Scifi", icon, fanart),
        ("[B]Zombie Island Massacre[/B]", "A77UnQ0eYc8", 801, "Zombie", icon, fanart),
        ("[B]Special Needs[/B]", "Rx16cmCbiL0", 801, "Comedy", icon, fanart),
        ("[B]Dead Eyes Open[/B]", "8YHX1s16AEo", 801, "Horror", icon, fanart),
        ("[B]Outlaw Prophet[/B]", "fbu-zYPC6tM", 801, "Scifi", icon, fanart),
        ("[B]Witchcraft 2: The Temptress[/B]", "OVzDeki8yBk", 801, "Horror", icon, fanart),
        ("[B]Witchcraft 3: The Kiss Of Death[/B]", "XpQVprT6DRA", 801, "Horror", icon, fanart),
        ("[B]Witchcraft 4: The Virgin Heart[/B]", "G4thooe-7sg", 801, "Horror", icon, fanart),
]

#=====================================

class TromaListing:

    @staticmethod
    def Genres(type):
		
        #errorMsg="%s" % (type)
        #xbmcgui.Dialog().ok("type", errorMsg)

        for name, url, zmode, genre, icon, fanart in sorted(channellist, reverse=False):

            addIt=False
            if type is "All":
                icon=genreImage+"All.png"
                addIt=True

            elif type is "Action" and genre is "Action":
                icon=genreImage+"Action.png"
                addIt=True

            elif type is "Comedy" and genre is "Comedy":
                icon=genreImage+"Comedy.png"
                addIt=True

            elif type is "Crime" and genre is "Crime":
                icon=genreImage+"Crime.png"
                addIt=True

            elif type is "Docs" and genre is "Documentary":
                icon=genreImage+"Documentary.png"
                addIt=True

            elif type is "Fantasy" and genre is "Fantasy":
                icon=genreImage+"Fantasy.png"
                addIt=True

            elif type is "Horror" and genre is "Horror":
                icon=genreImage+"Horror.png"
                addIt=True

            elif type is "Music" and genre is "Music":
                icon=genreImage+"Music.png"
                addIt=True

            elif type is "Scifi" and genre is "Scifi":
                icon=genreImage+"Scifi.png"
                addIt=True

            elif type is "Thriller" and genre is "Thriller":
                icon=genreImage+"Thriller.png"
                addIt=True

            elif type is "Zombie" and genre is "Zombie":
                icon=genreImage+"Zombie.png"
                addIt=True
		
            if addIt==True:
	            addLink(name,url,zmode,icon,fanart)

#=====================================

