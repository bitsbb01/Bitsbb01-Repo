"""
    j1tvlib

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""

import os
import json
import base64
import re
import xbmc
import xbmcplugin
import xbmcgui
import sys
import string
import random

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

convert_special_characters = HTMLParser()
dlg = xbmcgui.Dialog()

from resources.lib.modules.common import *

stream_failed = "Unable to get stream. Please try again later."
stream_plug = "aHR0cHM6Ly9tN2xpYi5kZXYvYXBpL2xpdmVfc3RyZWFtcy92MS9nZXRfc3RyZWFtLnBocD9pZD0="
stirr_base = "aHR0cHM6Ly9vdHQtZ2F0ZXdheS1zdGlyci5zaW5jbGFpcnN0b3J5bGluZS5jb20vYXBpL3Jlc3QvdjMvc3RhdHVzLw=="
pluto_base = "aHR0cDovL2FwaS5wbHV0by50di92Mi9jaGFubmVscz9hcHBOYW1lPXdlYiZkZXZpY2VNYWtlPUNocm9tZSZkZXZpY2VUeXBlPXdlYiY="
explore_org_base = "aHR0cHM6Ly9vbWVnYS5leHBsb3JlLm9yZy9hcGkvZ2V0X2NhbV9ncm91cF9pbmZvLmpzb24/aWQ9Nzk="
tubi_tv_base = "aHR0cHM6Ly90dWJpdHYuY29tL296"

class Common:

    @staticmethod
    def print_dlg(mode,str):
        dlg.ok(mode, str)
        return
		
    @staticmethod
    def dlg_failed(mode):
        dlg.ok(mode, stream_failed)
        exit()

    @staticmethod
    def random_generator(size=6, chars=string.ascii_uppercase + string.digits):
        return ''.join(random.choice(chars) for x in range(size))

    @staticmethod
    # Parse string and extracts first match as a string
    # The default is to find the first match. Pass a 'number' if you want to match a specific match. So 1 would match
    # the second and so forth
    def find_single_match(text, pattern, number=0):
        try:
            matches = re.findall(pattern, text, flags=re.DOTALL)
            result = matches[number]
        except:
            result = ""
        return result

    @staticmethod
    # Parse string and extracts multiple matches using regular expressions
    def find_multiple_matches(text, pattern):
        matches = re.findall(pattern, text, re.DOTALL)
        return matches

    @staticmethod
    # Open URL
    def open_url(url, user_agent=True):
        req = Request(url)
        if user_agent != False:
            req.add_header('User-Agent',
                           'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11'
                           '(KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11')
        response = urlopen(req)
        link = response.read()
        response.close()
        return link

    @staticmethod
    # Section, Genre, or Channel logos
    def get_muzic_logo(channel, type=None):
        if type is None:
            return xbmc.translatePath(
                os.path.join('special://home/addons/plugin.video.j1tv', 'resources', 'images',
                             "muzic.png"))
                             #channel + ".png"))
    @staticmethod
    # Section, Genre, or Channel logos
    def get_logo(channel, type=None):
        if type is None:
            return xbmc.translatePath(
                os.path.join('special://home/addons/plugin.video.j1tv', 'resources', 'images',
                             "icon.png"))
                             #channel + ".png"))
        elif type == "section":
            return xbmc.translatePath(
                os.path.join('special://home/addons/plugin.video.j1tv', 'resources', 'images', 'sections',
                             "icon.png"))
                             #channel + ".png"))
        elif type == "genre":
            return xbmc.translatePath(
                os.path.join('special://home/addons/plugin.video.j1tv', 'resources', 'images', 'genres',
                             channel + ".png"))

    @staticmethod
    # Section, Genre, or Channel logos
    def get_channels_logo(channel, type=None):
        if type is None: 
            return xbmc.translatePath(
                os.path.join('special://home/addons/plugin.video.j1tv', 'resources', 'media', 'genres',
                             "channels.png"))
                             #channel + ".png"))
        elif type == "section":
            return xbmc.translatePath(
                os.path.join('special://home/addons/plugin.video.j1tv', 'resources', 'media', 'sections',
                             "icon.png"))
                             #channel + ".png"))
        elif type == "genre":
            return xbmc.translatePath(
                os.path.join('special://home/addons/plugin.video.j1tv', 'resources', 'media', 'genres',
                             channel + ".png"))
		
    @staticmethod
    # Available video
    def get_singles():
        channel_list = [
                            {"name": "Def Leppard Story", "type": "Docs"},
                            {"name": "Bohemian Rhapsody: Queen", "type": "Rock, Anthem"},
                            {"name": "Muppets Bohemian Rhapsody", "type": "TV, Kids"},
                            {"name": "Foreigner Story", "type": "Docs"},
                            {"name": "Happy Day: Sister Act", "type": "Movies, Faith"},
                            {"name": "Gun n Roses: Band That Time Forgot", "type": "Docs"},
                            {"name": "Bon Jovi When We Were Beautiful", "type": "Docs"},
                            {"name": "Betty Davis Eyes", "type": "Rock"},
                            {"name": "Hold Your Head Up: Argent", "type": "Rock"},
                            {"name": "Deep Purple The History", "type": "Docs"},
                            {"name": "Blues Story", "type": "Docs, Blues"},
                            {"name": "Grand Funk Railroad", "type": "Docs"},
                            {"name": "Girl Groups", "type": "Docs, Soul, RnB, Pop"},
                            {"name": "Wanna Know What Love Is: Foreigner", "type": "Rock, Anthem"},
                            {"name": "Livin On A Prayer: Bon Jovi", "type": "Rock, Metal"},
                            {"name": "Can't Fight This Feeling: Reo Speedwagon", "type": "Rock, Anthem, Blues"},
                            {"name": "Alone: Heart", "type": "Rock, Anthem, Blues"},
                            {"name": "With Or Without You: U2", "type": "Alternative, Rock, Blues"},
                            {"name": "Comfortably Numb: Pink Floyd", "type": "Rock, Anthem, Metal"},
                            {"name": "Final Countdown: Europe", "type": "Rock"},
                            {"name": "Dream On: Aerosmith", "type": "Rock, Metal"},
                            {"name": "Keep On Lovin You: Reo Speedwagon", "type": "Rock, Anthem, Blues"},
                            {"name": "Money For Nothing: Dire Straits", "type": "Rock"},
                            {"name": "Highway Star: Deep Purple", "type": "Rock, Metal"},
                            {"name": "Dont You (Forget About Me): Simple Minds", "type": "Rock, Alternative"},
                            {"name": "Since You Been Gone: Rainbow", "type": "Rock"},
                            {"name": "Hysteria: Def Leppard", "type": "Rock, Anthem"},
                            {"name": "Dont Want To Miss A Thing: Aerosmith", "type": "Rock, Anthem"},
                            {"name": "Home Sweet Home: Motley Crue", "type": "Rock, Anthem"},
                            {"name": "Separate Ways: Journey", "type": "Rock, Blues"},
                            {"name": "Don't Stop Believin: (Dan Lucas) The Voice", "type": "TV, Rock, Pop"},
                            {"name": "Crazy On You: Heart", "type": "Rock"},
                            {"name": "Try (Truth About Love): Pink", "type": "Pop, RnB"},
                            {"name": "Say You Will: Foreigner", "type": "Rock, Anthem"},
                            {"name": "You Give Love A Bad Name: Bon Jovi", "type": "Rock, Metal"},
                            {"name": "Alone: (Dan Lucas) The Voice", "type": "TV, Blues, Anthem"},
                            {"name": "Whiter Shade Of Pale: Geff Harrison The Voice", "type": "TV, Blues"},
                            {"name": "Thrill Is Gone: BB King", "type": "Blues"},
                            {"name": "Smoke On The Water: The Voice", "type": "TV, Rock, Metal"},
                            {"name": "Still Loving You: The Voice", "type": "TV, Rock, Anthem, Blues"},
                            {"name": "Without You: Mariah Carey", "type": "Pop"},
                            {"name": "Alone: Floortje Smit The Voice", "type": "TV, Blues"},
                            {"name": "Simple Man: Lynyrd Skynyrd", "type": "Rock, Anthem"},
                            {"name": "I Will Always Love You: Whitney Houston", "type": "RnB"},
                            {"name": "Feels Like The First Time: Foreigner", "type": "Rock"},
                            {"name": "Dust In The Wind: Kansas", "type": "Rock, Anthem"},
                            {"name": "Time: Pink Floyd", "type": "Rock, Metal"},
                            {"name": "Purple Rain: Prince", "type": "Rock"},
                            {"name": "Sweet Child O Mine: Guns N Roses", "type": "Rock, Metal"},
                            {"name": "Hotel California: Eagles", "type": "Rock"},
                            {"name": "What About Love: Heart", "type": "Rock, Anthem, Blues"},
                            {"name": "Go Your Own Way: Fleetwood Mac", "type": "Rock"},
                            {"name": "Little Help From My Friends: Joe Cocker", "type": "Rock, Blues"},
                            {"name": "Cant You See: Marshall Tucker Band", "type": "Rock, Country, Blues"},
                            {"name": "How Many More Times: Led Zeppelin", "type": "Rock, Blues, Metal"},
                            {"name": "Bohemian Rhaposy: The Voice", "type": "TV, Anthem"},
                            {"name": "Dont Look Back: Boston", "type": "Rock, Metal"},
                            {"name": "Lady: Styx", "type": "Rock"},
                            {"name": "Best Of Times: Styx", "type": "Rock"},
                            {"name": "Pitch Perfect 1: Finale", "type": "Movies, Pop, Alternative"},
                            {"name": "Pitch Perfect 2: Finale", "type": "Movies, Pop"},
                            {"name": "Pitch Perfect 3: Freedom", "type": "Movies, Pop"},
                            {"name": "Tumblin Dice: Linda Ronstadt", "type": "Movies, Rock, Blues"},
                            {"name": "School Of Rock", "type": "Movies, Rock"},
                            {"name": "Once Bitten: 3 Speed", "type": "Movies, Pop"},
                            {"name": "Staying Alive: Airplane", "type": "Movies, Pop"},
                            {"name": "Rocket Man: Elton John", "type": "Rock, Pop"},
                            {"name": "Tiny Dancer: Elton John", "type": "Rock, Blues"},
                            {"name": "The Chain: Fleetwood Mac", "type": "Rock, Blues"},
                            {"name": "Verace On The Floor: Bruno Mars", "type": "Pop"},
                            {"name": "Love On Top: Beyonce", "type": "RnB"},
                            {"name": "Drunk In Love: Explicit Beyonce", "type": "Pop"},
                            {"name": "Crazy In Love: Beyonce", "type": "RnB, Pop"},
                            {"name": "Run The World: Beyonce", "type": "RnB"},
                            {"name": "Love On The Brain: Rhianna", "type": "Pop, Hip Hop, Rap"},
                            {"name": "Diamonds: Rhianna", "type": "Pop"},
                            {"name": "Beautiful Trauma: Pink", "type": "Pop"},
                            {"name": "Please Dont Leave Me: Pink", "type": "pop"},
                            {"name": "Lose Yourself:Eminem", "type": "Rap"},
                            {"name": "In The Club: 50 Cent", "type": "Rap"},
                            {"name": "Hells Bells: AC/DC", "type": "Rock, Metal"},
                            {"name": "You Shook Me All Night Long: AC/DC", "type": "Rock, Metal"},
                            {"name": "Highway To Hell: AC/DC", "type": "Rock, Metal"},
                            {"name": "Shadows Of The Night: Pat Benatar", "type": "Rock, Anthem"},
                            {"name": "Best Of The Worst: Charm City Devils", "type": "Rock"},
                            {"name": "The Man Ill Never Be: Boston", "type": "Rock, Anthem, Metal"},
                            {"name": "Dreams: Van Halen", "type": "Rock, Anthem"},
                            {"name": "When It's Love: Van Halen", "type": "Rock"},
                            {"name": "Photograph: Def Leppard", "type": "Rock, Metal"},
                            {"name": "Best Of Both Worlds: Van Halen", "type": "Rock, Metal"},
                            {"name": "Why Can't This Be Love: Van Halen", "type": "Rock"},
                            {"name": "Hunger City: Cherry Bombs", "type": "Rock"},
                            {"name": "Second Chance: Shinedown", "type": "Rock, Blues"},
                            {"name": "45: Shinedown", "type": "Rock, Blues"},
                            {"name": "Remember When: Alan Jackson", "type": "Country"},
                            {"name": "Craving You: Thomas Rhett", "type": "Country"},
                            {"name": "Tennessee Whiskey Chris Stapleton", "type": "Country, Blues"},
                            {"name": "Alone With You: Jake Owen", "type": "Country"},
                            {"name": "Country Girl: Luke Bryan", "type": "Country"},
                            {"name": "Where I Come From: Montgomery Gentry", "type": "Country"},
                            {"name": "Whiskey River: Willie Nelson", "type": "Country"},
                        ]

        return channel_list
		
    @staticmethod
    # Available channels
    def get_channels():
        channel_list = [
                            {"name": "Progressive House", "type": "Mix"},
                            {"name": "Trap Music Radio", "type": "Mix"},
                            {"name": "RnB Chill", "type": "RnB"},
                            {"name": "Electro Swing", "type": "Electro"},
                            {"name": "Doom Metal Music", "type": "Metal"},
                            {"name": "RnB Soul", "type": "RnB"},
                            {"name": "Lofi Hip Hop Mix", "type": "Hip Hop"},
                            {"name": "Vocal Trance", "type": "Trance"},
                            {"name": "Best Deep House", "type": "Mix"},
                            {"name": "Jazz Hip Hop", "type": "Jazz, Hip Hop"},
                            {"name": "Fenomen Pop", "type": "Pop"},
                            {"name": "Rap Radio Music", "type": "Rap"},
                            {"name": "Space Ambient Music", "type": "Alternative"},
                            {"name": "Deep House Relax", "type": "Mix"},
                            {"name": "Chill Out Lounge Jazz", "type": "Jazz"},
                            {"name": "Spring Jazz", "type": "Jazz"},
                            {"name": "Chill Music", "type": "Sleep"},
                            {"name": "Lounge Jazz Radio", "type": "Jazz"},
                            {"name": "Progressive House Focus", "type": "Mix"},
                            {"name": "Uplifting Trance", "type": "Trance"},
                            {"name": "Best Electro House", "type": "Electro"},
                            {"name": "NCS Electronic", "type": "Electro"},
                            {"name": "Popular Song Remix", "type": "Mix"},
                            {"name": "Ultimate Game Music", "type": "Mix"},
                            {"name": "Best Gaming Mix", "type": "Mix"},
                            {"name": "Sad Boys Radio", "type": "Mix"},
                            {"name": "Gaming Radio", "type": "Mix"},
                            {"name": "Nature TV", "type": "Sleep"},
                            {"name": "Tropical House", "type": "Mix"},
                            {"name": "Good Life Radio", "type": "Mix"},
                            {"name": "Shuffle Bass Boost", "type": "Dance"}
                        ]

        return channel_list

    @staticmethod
    # Available sections
    def get_sections():
        section_list = ["All Channels", "Genres"]
        return section_list

    @staticmethod
    # Available genres
    def get_singles_genres():
        singles_genre_list = ["Alternative", "Anthem", "Blues", "Country", "Docs", "Hip Hop", "Jazz",
                      "Metal", "Movie", "Pop", "Punk", "RnB", "Rock", "Rap", "Soul",
                      "TV"]
        return singles_genre_list

    @staticmethod
    def add_channel(mode, icon, fanart, title=None, live=True):
        if live is True:
            u = sys.argv[0] + "?mode=" + str(mode) + "&pvr=.pvr"
        else:
            u = sys.argv[0] + "?mode=" + str(mode)
        ok = True
        if title is not None:
            item = title
        else:
            item = mode
        liz = xbmcgui.ListItem(str(item), iconImage="DefaultFolder.png", thumbnailImage=icon)
        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable", "true")
        liz.setInfo('video', {'Title': item})
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
        return ok

    @staticmethod
    def add_section(mode, icon, fanart, title=None):
        u = sys.argv[0] + "?mode=" + str(mode) + "&rand=" + Common.random_generator()
        ok = True
        if title is not None:
            item = title
        else:
            item = mode
        liz = xbmcgui.ListItem(str(item), iconImage="DefaultFolder.png", thumbnailImage=icon)
        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable", "true")
        liz.setInfo('video', {'Title': item})
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
        return ok

    @staticmethod
    # Return the Channel ID from YouTube URL
    def get_youtube_channel_id(url):
        return url.split("?v=")[-1].split("/")[-1].split("?")[0].split("&")[0]

    @staticmethod
    # Return the full YouTube plugin url
    def get_playable_youtube_url(channel_id):
        return 'plugin://plugin.video.youtube/play/?video_id=%s' % channel_id

    @staticmethod
    # Return the full YouTube plugin url
    def get_playable_youtube_channel(channel_id):
        return 'plugin://plugin.video.youtube/play/c/' % channel_id +'/live'

    @staticmethod
    # Add rebase=on to stream URL
    def rebase(stream):
        rebase = 'rebase=on'
        if '?' in stream:
            return stream + '&' + rebase
        return stream + '?' + rebase

    @staticmethod
    # Play stream
    # Optional: set xbmc_player to True to use xbmc.Player() instead of xbmcplugin.setResolvedUrl()
    def play(stream, channel=None, xbmc_player=False):
        if xbmc_player:
            li = xbmcgui.ListItem(channel)
            xbmc.Player().play(stream, li, False)
        else:
            item = xbmcgui.ListItem(channel, path=stream)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

    @staticmethod
    # Get and Play stream
    def get_yt_and_play(mode):

        #==========MUZIC STREAMS===========

        vid_id = ""
        stream = ""

        if mode == "Jazz Hip Hop":
            vid_id = YOUTUBE_CHANNEL_ID_1113
        elif mode == "Progressive House":
            vid_id = YOUTUBE_CHANNEL_ID_1112
        elif mode == "Trap Music Radio":
            vid_id = YOUTUBE_CHANNEL_ID_1111
        elif mode == "RnB Chill":
            vid_id = YOUTUBE_CHANNEL_ID_1109
        elif mode == "Electro Swing":
            vid_id = YOUTUBE_CHANNEL_ID_1108
        elif mode == "Doom Metal Music":
            vid_id = YOUTUBE_CHANNEL_ID_1082
        elif mode == "RnB Soul":
            vid_id = YOUTUBE_CHANNEL_ID_1118
        elif mode == "Lofi Hip Hop Mix":
            vid_id = YOUTUBE_CHANNEL_ID_1116
        elif mode == "Vocal Trance":
            vid_id = YOUTUBE_CHANNEL_ID_1114
        elif mode == "Best Deep House":
            vid_id = YOUTUBE_CHANNEL_ID_1132
        elif mode == "Fenomen Pop":
            vid_id = YOUTUBE_CHANNEL_ID_1127
        elif mode == "Rap Radio Music":
            vid_id = YOUTUBE_CHANNEL_ID_1138
        elif mode == "Deep House Relax":
            vid_id = YOUTUBE_CHANNEL_ID_1134
        elif mode == "Chill Out Lounge Jazz":
            vid_id = YOUTUBE_CHANNEL_ID_1137
        elif mode == "Spring Jazz":
            vid_id = YOUTUBE_CHANNEL_ID_1104
        elif mode == "Space Ambient Music":
            vid_id = YOUTUBE_CHANNEL_ID_1133
        elif mode == "Chill Music":
            vid_id = YOUTUBE_CHANNEL_ID_1099
        elif mode == "Lounge Jazz Radio":
            vid_id = YOUTUBE_CHANNEL_ID_1103
        elif mode == "Progressive House Focus":
            vid_id = YOUTUBE_CHANNEL_ID_1093
        elif mode == "Uplifting Trance":
            vid_id = YOUTUBE_CHANNEL_ID_1094
        elif mode == "Best Electro House":
            vid_id = YOUTUBE_CHANNEL_ID_1095
        elif mode == "NCS Electronic":
            vid_id = YOUTUBE_CHANNEL_ID_1098
        elif mode == "Popular Song Remix":
            vid_id = YOUTUBE_CHANNEL_ID_1091
        elif mode == "Ultimate Game Music":
            vid_id = YOUTUBE_CHANNEL_ID_1092
        elif mode == "Best Gaming Mix":
            vid_id = YOUTUBE_CHANNEL_ID_1089
        elif mode == "Sad Boys Radio":
            vid_id = YOUTUBE_CHANNEL_ID_1086
        elif mode == "Gaming Radio":
            vid_id = YOUTUBE_CHANNEL_ID_1085
        elif mode == "Nature TV":
            vid_id = YOUTUBE_CHANNEL_ID_1084
        elif mode == "Tropical House":
            vid_id = YOUTUBE_CHANNEL_ID_1083
        elif mode == "Shuffle Bass Boost":
            vid_id = YOUTUBE_CHANNEL_ID_1078
        elif mode == "Good Life Radio":
            vid_id = YOUTUBE_CHANNEL_ID_1080

        #==========MUZIC SINGLE VIDEO===========

        elif mode == "Def Leppard Story":
            vid_id = YOUTUBE_CHANNEL_ID_1200

        elif mode == "Bohemian Rhapsody":
            vid_id = YOUTUBE_CHANNEL_ID_1201

        elif mode == "Muppets Bohemian Rhapsody":
            vid_id = YOUTUBE_CHANNEL_ID_1202

        elif mode == "Foreigner Story":
            vid_id = YOUTUBE_CHANNEL_ID_1203

        elif mode == "Happy Day: Sister Act":
            vid_id = YOUTUBE_CHANNEL_ID_1204

        elif mode == "Gun n Roses: Band That Time Forgot":
            vid_id = YOUTUBE_CHANNEL_ID_1205

        elif mode == "Bon Jovi When We Were Beautiful":
            vid_id = YOUTUBE_CHANNEL_ID_1206

        elif mode == "Betty Davis Eyes":
            vid_id = YOUTUBE_CHANNEL_ID_1207

        elif mode == "Hold Your Head Up: Argent":
            vid_id = YOUTUBE_CHANNEL_ID_1208

        elif mode == "Deep Purple The History":
            vid_id = YOUTUBE_CHANNEL_ID_1209

        elif mode == "Blues Story":
            vid_id = YOUTUBE_CHANNEL_ID_1210

        elif mode == "Grand Funk Railroad":
            vid_id = YOUTUBE_CHANNEL_ID_1211

        elif mode == "Girl Groups":
            vid_id = YOUTUBE_CHANNEL_ID_1212

        elif mode == "Wanna Know What Love Is: Foreigner":
            vid_id = YOUTUBE_CHANNEL_ID_1213

        elif mode == "Livin On A Prayer: Bon Jovi":
            vid_id = YOUTUBE_CHANNEL_ID_1214

        elif mode == "Can't Fight This Feeling: Reo Speedwagon":
            vid_id = YOUTUBE_CHANNEL_ID_1215

        elif mode == "Alone: Heart":
            vid_id = YOUTUBE_CHANNEL_ID_1216

        elif mode == "With Or Without You: U2":
            vid_id = YOUTUBE_CHANNEL_ID_1217

        elif mode == "Comfortably Numb: Pink Floyd":
            vid_id = YOUTUBE_CHANNEL_ID_1218

        elif mode == "Final Countdown: Europe":
            vid_id = YOUTUBE_CHANNEL_ID_1219

        elif mode == "Dream On: Aerosmith":
            vid_id = YOUTUBE_CHANNEL_ID_1220

        elif mode == "Keep On Lovin You: Reo Speedwagon":
            vid_id = YOUTUBE_CHANNEL_ID_1221

        elif mode == "Money For Nothing: Dire Straits":
            vid_id = YOUTUBE_CHANNEL_ID_1222

        elif mode == "Highway Star: Deep Purple":
            vid_id = YOUTUBE_CHANNEL_ID_1223

        elif mode == "Dont You (Forget About Me): Simple Minds":
            vid_id = YOUTUBE_CHANNEL_ID_1224

        elif mode == "Since You Been Gone: Rainbow":
            vid_id = YOUTUBE_CHANNEL_ID_1225

        elif mode == "Hysteria: Def Leppard":
            vid_id = YOUTUBE_CHANNEL_ID_1226

        elif mode == "Dont Want To Miss A Thing: Aerosmith":
            vid_id = YOUTUBE_CHANNEL_ID_1227

        elif mode == "Home Sweet Home: Motley Crue":
            vid_id = YOUTUBE_CHANNEL_ID_1228

        elif mode == "Separate Ways: Journey":
            vid_id = YOUTUBE_CHANNEL_ID_1229

        elif mode == "Don't Stop Believin: (Dan Lucas) The Voice":
            vid_id = YOUTUBE_CHANNEL_ID_1230

        elif mode == "Crazy On You: Heart":
            vid_id = YOUTUBE_CHANNEL_ID_1231

        elif mode == "Try (Truth About Love): Pink":
            vid_id = YOUTUBE_CHANNEL_ID_1232

        elif mode == "Say You Will: Foreigner":
            vid_id = YOUTUBE_CHANNEL_ID_1233

        elif mode == "You Give Love A Bad Name: Bon Jovi":
            vid_id = YOUTUBE_CHANNEL_ID_1234

        elif mode == "Alone: (Dan Lucas) The Voice":
            vid_id = YOUTUBE_CHANNEL_ID_1235

        elif mode == "Whiter Shade Of Pale: Geff Harrison The Voice":
            vid_id = YOUTUBE_CHANNEL_ID_1236

        elif mode == "Thrill Is Gone: BB King":
            vid_id = YOUTUBE_CHANNEL_ID_1237

        elif mode == "Smoke On The Water: The Voice":
            vid_id = YOUTUBE_CHANNEL_ID_1238

        elif mode == "Still Loving You: The Voice":
            vid_id = YOUTUBE_CHANNEL_ID_1239

        elif mode == "Without You: Mariah Carey":
            vid_id = YOUTUBE_CHANNEL_ID_1240

        elif mode == "Alone: Floortje Smit The Voice":
            vid_id = YOUTUBE_CHANNEL_ID_1241

        elif mode == "Simple Man: Lynyrd Skynyrd":
            vid_id = YOUTUBE_CHANNEL_ID_1242

        elif mode == "I Will Always Love You: Whitney Houston":
            vid_id = YOUTUBE_CHANNEL_ID_1243

        elif mode == "Feels Like The First Time: Foreigner":
            vid_id = YOUTUBE_CHANNEL_ID_1244

        elif mode == "Dust In The Wind: Kansas":
            vid_id = YOUTUBE_CHANNEL_ID_1245

        elif mode == "Time: Pink Floyd":
            vid_id = YOUTUBE_CHANNEL_ID_1246

        elif mode == "Purple Rain: Prince":
            vid_id = YOUTUBE_CHANNEL_ID_1247

        elif mode == "Sweet Child O Mine: Guns N Roses":
            vid_id = YOUTUBE_CHANNEL_ID_1248

        elif mode == "Hotel California: Eagles":
            vid_id = YOUTUBE_CHANNEL_ID_1249

        elif mode == "What About Love: Heart":
            vid_id = YOUTUBE_CHANNEL_ID_1250

        elif mode == "Go Your Own Way: Fleetwood Mac":
            vid_id = YOUTUBE_CHANNEL_ID_1251

        elif mode == "Little Help From My Friends: Joe Cocker":
            vid_id = YOUTUBE_CHANNEL_ID_1252

        elif mode == "Cant You See: Marshall Tucker Band":
            vid_id = YOUTUBE_CHANNEL_ID_1253

        elif mode == "How Many More Times: Led Zeppelin":
            vid_id = YOUTUBE_CHANNEL_ID_1254

        elif mode == "Bohemian Rhaposy: The Voice":
            vid_id = YOUTUBE_CHANNEL_ID_1255

        elif mode == "Dont Look Back: Boston":
            vid_id = YOUTUBE_CHANNEL_ID_1256

        elif mode == "Lady: Styx":
            vid_id = YOUTUBE_CHANNEL_ID_1257

        elif mode == "Best Of Times: Styx":
            vid_id = YOUTUBE_CHANNEL_ID_1258

        elif mode == "Pitch Perfect 1: Finale":
            vid_id = YOUTUBE_CHANNEL_ID_1259

        elif mode == "Pitch Perfect 2: Finale":
            vid_id = YOUTUBE_CHANNEL_ID_1260

        elif mode == "Pitch Perfect 3: Freedom":
            vid_id = YOUTUBE_CHANNEL_ID_1261

        elif mode == "Tumblin Dice: Linda Ronstadt":
            vid_id = YOUTUBE_CHANNEL_ID_1262

        elif mode == "School Of Rock":
            vid_id = YOUTUBE_CHANNEL_ID_1263

        elif mode == "Once Bitten: 3 Speed":
            vid_id = YOUTUBE_CHANNEL_ID_1264

        elif mode == "Staying Alive: Airplane":
            vid_id = YOUTUBE_CHANNEL_ID_1265

        elif mode == "Rocket Man: Elton John":
            vid_id = YOUTUBE_CHANNEL_ID_1266

        elif mode == "Tiny Dancer: Elton John":
            vid_id = YOUTUBE_CHANNEL_ID_1267

        elif mode == "The Chain: Fleetwood Mac":
            vid_id = YOUTUBE_CHANNEL_ID_1268

        elif mode == "Verace On The Floor: Bruno Mars":
            vid_id = YOUTUBE_CHANNEL_ID_1269

        elif mode == "Love On Top: Beyonce":
            vid_id = YOUTUBE_CHANNEL_ID_1270

        elif mode == "Drunk In Love: Explicit Beyonce":
            vid_id = YOUTUBE_CHANNEL_ID_1271

        elif mode == "Crazy In Love: Beyonce":
            vid_id = YOUTUBE_CHANNEL_ID_1272

        elif mode == "Run The World: Beyonce":
            vid_id = YOUTUBE_CHANNEL_ID_1273

        elif mode == "Love On The Brain: Rhianna":
            vid_id = YOUTUBE_CHANNEL_ID_1274

        elif mode == "Diamonds: Rhianna":
            vid_id = YOUTUBE_CHANNEL_ID_1275

        elif mode == "Beautiful Trauma: Pink":
            vid_id = YOUTUBE_CHANNEL_ID_1276

        elif mode == "Please Dont Leave Me: Pink":
            vid_id = YOUTUBE_CHANNEL_ID_1277

        elif mode == "Lose Yourself:Eminem":
            vid_id = YOUTUBE_CHANNEL_ID_1278

        elif mode == "In The Club: 50 Cent":
            vid_id = YOUTUBE_CHANNEL_ID_1279

        elif mode == "Hells Bells: AC/DC":
            vid_id = YOUTUBE_CHANNEL_ID_1280

        elif mode == "You Shook Me All Night Long: AC/DC":
            vid_id = YOUTUBE_CHANNEL_ID_1281

        elif mode == "Highway To Hell: AC/DC":
            vid_id = YOUTUBE_CHANNEL_ID_1282

        elif mode == "Shadows Of The Night: Pat Benatar":
            vid_id = YOUTUBE_CHANNEL_ID_1283

        elif mode == "Best Of The Worst: Charm City Devils":
            vid_id = YOUTUBE_CHANNEL_ID_1284

        elif mode == "The Man Ill Never Be: Boston":
            vid_id = YOUTUBE_CHANNEL_ID_1285

        elif mode == "Dreams: Van Halen":
            vid_id = YOUTUBE_CHANNEL_ID_1286

        elif mode == "When It's Love: Van Halen":
            vid_id = YOUTUBE_CHANNEL_ID_1287

        elif mode == "Photograph: Def Leppard":
            vid_id = YOUTUBE_CHANNEL_ID_1288

        elif mode == "Best Of Both Worlds: Van Halen":
            vid_id = YOUTUBE_CHANNEL_ID_1289

        elif mode == "Why Can't This Be Love: Van Halen":
            vid_id = YOUTUBE_CHANNEL_ID_1290

        elif mode == "Hunger City: Cherry Bombs":
            vid_id = YOUTUBE_CHANNEL_ID_1291

        elif mode == "Second Chance: Shinedown":
            vid_id = YOUTUBE_CHANNEL_ID_1292

        elif mode == "45: Shinedown":
            vid_id = YOUTUBE_CHANNEL_ID_1293

        elif mode == "Remember When: Alan Jackson":
            vid_id = YOUTUBE_CHANNEL_ID_1294

        elif mode == "Craving You: Thomas Rhett":
            vid_id = YOUTUBE_CHANNEL_ID_1295

        elif mode == "Tennessee Whiskey Chris Stapleton":
            vid_id = YOUTUBE_CHANNEL_ID_1296

        elif mode == "Alone With You: Jake Owen":
            vid_id = YOUTUBE_CHANNEL_ID_1297

        elif mode == "Country Girl: Luke Bryan":
            vid_id = YOUTUBE_CHANNEL_ID_1298

        elif mode == "Where I Come From: Montgomery Gentry":
            vid_id = YOUTUBE_CHANNEL_ID_1299

        elif mode == "Whiskey River: Willie Nelson":
            vid_id = YOUTUBE_CHANNEL_ID_1300

        stream = Stream.get_video_id(vid_id)
		
        #if stream is not None:		
        #    try:
        #        Common.play(stream)
        #    except StandardError:
        #        return None
		
        if stream is not None:		
            Common.play(stream)
        else:
            wd = None #Common.dlg_failed(mode)


class Stream:

    @staticmethod
    def get_video_id(vid):
        try:
            channel_id = vid
            if channel_id is not "":
                return Common.get_playable_youtube_url(channel_id)
            else:
                return None
        except StandardError:
            return None


