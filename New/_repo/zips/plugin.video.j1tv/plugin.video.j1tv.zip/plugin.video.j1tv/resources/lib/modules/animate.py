# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

from resources.lib.modules.common import *

params = get_params()
mode = None

debug        = Addon_Setting(setting='debug')       
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
#artAddon     = 'script.j1.artwork'

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.j1tv')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'animate.png'))
mediapath = 'http://j1wizard.net/media/'
path   = xbmcaddon.Addon().getAddonInfo('path').decode("utf-8")

BASE  = "plugin://plugin.video.youtube/playlist/"
cBASE = "plugin://plugin.video.youtube/channel/"
uBASE = "plugin://plugin.video.youtube/user/"

def add_link_info(name, iconimage, fanart):
	u = sys.argv[0] + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'false') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz) 

#======================================================================================================================

YOUTUBE_CHANNEL_ID_5001 = "PLCZnrv5aXtJ6i4CgYfGYWS5TqbG5MMlZ6" #Violent Anime
YOUTUBE_CHANNEL_ID_5002 = "PL8LUgHL27N9bJCUp_uBjaaW-jA2brmygk" #80s And 90s Anime
YOUTUBE_CHANNEL_ID_5003 = "PL_-_wXIQjzzAQnC4GgqaOE715sHcC0GQM" #anime shows
YOUTUBE_CHANNEL_ID_5004 = "PLONmgYPagq-Hv4Z_7-jfZAoRCUWDM9i5f" #Old School Violent anime
YOUTUBE_CHANNEL_ID_5005 = "PLW5H5KwRXf4wWN7gdgXnu9a4-Q1lEWpzT" #Anime Espanol
YOUTUBE_CHANNEL_ID_5006 = "PLadhuPFEGcGfULAZgQy6bbVYbS7AtDuyP" #Monster Anime Complete Series
YOUTUBE_CHANNEL_ID_5007 = "PLNT3lulbMkNVMswPqJ8kfcCnO2HfWBTxS" #Anime en Espanol Latino
YOUTUBE_CHANNEL_ID_5008 = "PLnXd-FSg7GX7obTXlqjqH3Eh0NkObB3Lr" #Classic Anime
YOUTUBE_CHANNEL_ID_5009 = "PLwerrvRiyk8iLLcGEB8z0ZFzNuI8goQtC" #Anime Movies
YOUTUBE_CHANNEL_ID_5010 = "PLcL2LY1y1cZUXAjgdgG6atsDlvURwkaro" #Anime movie & shorts
YOUTUBE_CHANNEL_ID_5011 = "PLxABUnTlYzRfPqVPAQxSp5nMeKp-rNLP9" #Anime Shows.?
YOUTUBE_CHANNEL_ID_5012 = "PLkLimRXN6NKwOybbWpLUuYZfJZxxgLj-D" #Justice League animated s1,s2
YOUTUBE_CHANNEL_ID_5013 = "PL4NZcPRMzmJJEvCgXFApfaR8vQDwBpgDe" #Anime Shows
YOUTUBE_CHANNEL_ID_5014 = "PLQOq7rKEzlHsAz6EZ_ThXm33IwWTFdooM" #Anime Shows
YOUTUBE_CHANNEL_ID_5015 = "PL61D3aFZr8_fJ4oOHHhh3tuPx0pPW0TY2" #Anime Episodes
YOUTUBE_CHANNEL_ID_5016 = "PL6TBkJwIuDuBdGgPTL6S7kg_eIMr60pMI" #Spawn Animated series
YOUTUBE_CHANNEL_ID_5017 = "PLC1EDzqtkrh9BvltS2mcRgTQDSAO079GT" #Mr Bean Animate S2
YOUTUBE_CHANNEL_ID_5018 = "PLuI7BiC5LyGZnYLDQ1gvCNyHX-nUm-tR-" #The Tick 1994-1996
YOUTUBE_CHANNEL_ID_5019 = "UCxzTKMZKMrcPpCQ8LyGPDUw" #Sabrina Animated Series Kids
YOUTUBE_CHANNEL_ID_5020 = "PLtT9OtsVg7FgAhZYBioeAqsg7t8BhNF53" #Highlander animated 1994-1996
YOUTUBE_CHANNEL_ID_5021 = "PL6fJmjt84zZgXis8FBu51yi98pL6VGDyE" #Mega Man 1994-1995
YOUTUBE_CHANNEL_ID_5022 = "PLq9lcAuzj6eHpGG5UvfHID8pG_tO3PSel" #Spiderman Animated Series 1994-1998
YOUTUBE_CHANNEL_ID_5023 = "PLCegRdSyFHvcc-lZbLZ8aYt4PDpu6L6xg" #Anime: Movies N Shorts
YOUTUBE_CHANNEL_ID_5024 = "PLEYAll4PuSQQubc6emncRBap7TuBOO1nc" #W.I.T.C.H. The Animated Series S1
YOUTUBE_CHANNEL_ID_5025 = "PLEYAll4PuSQR2FiPUOmtuTZ_-7IZ0IA1t" #W.I.T.C.H. The Animated Series S2
YOUTUBE_CHANNEL_ID_5026 = "PLC1EDzqtkrh8IWwCVEPxcQ1SkMH1mBlA6" #Mr Bean S1
YOUTUBE_CHANNEL_ID_5027 = "PLIEbITAtGBeZIhsSNHSXd628UW68WWaeA" #Gargoyles Complete Animated Series
YOUTUBE_CHANNEL_ID_5028 = "PLoEdN65lgpA_NFZ_TVSyQT5ahmS_YiE0Z" #Holidays Cartoons Kids
YOUTUBE_CHANNEL_ID_5029 = "PLW8q9E0mB4_GgHu9cj7w6lItvJJUDo3dl" #Dungeons & Dragons Complete Animated Series
YOUTUBE_CHANNEL_ID_5030 = "PLNXCO7Z2kJDQtBXn9Xp7NZk7ksxaL53ja" #Lengend of Zorro Animated Series
YOUTUBE_CHANNEL_ID_5031 = "UCzoFjzSkbrDD1GHsz2YNLig"           #Mr Bean Cartoon World
YOUTUBE_CHANNEL_ID_5032 = "PLVAka5y7jgjYdTsbtte0pYQ5T9f0hSN3l" #Spider-Man Animated Series S3
YOUTUBE_CHANNEL_ID_5033 = "PL_PQ0mKZqubuLQIAibuVmMfoh-OY1v2gD" #Godzilla The Series
YOUTUBE_CHANNEL_ID_5034 = "PLGuvfccqZJa0MrPlInGY2Nxm-lDyleAT_" #Aladdin Series 1994-1995 Kids
YOUTUBE_CHANNEL_ID_5035 = "PLNQ-3rd6vA8k0Ruic25d5B6LwWDUjFcdE" #Buzz Lightyear Series (kids)
YOUTUBE_CHANNEL_ID_5036 = "PLySo2SlSHPSOOGZM3_2Qun52hCaRNYW9y" #Sonic the Hedgehog
YOUTUBE_CHANNEL_ID_5037 = "PLZVxGLCpA_RyvD-VeJ_tkqJbliS-JNZRZ" #Animated Movies & TV
YOUTUBE_CHANNEL_ID_5038 = "PL_LA4m8CuQkxEVZ0CYBm_ObCV5KZ_bRAw" #Sonic X (anime)
YOUTUBE_CHANNEL_ID_5039 = "UCx27Pkk8plpiosF14qXq-VA" #Sponge Bob (Kids)
YOUTUBE_CHANNEL_ID_5040 = "PLZyrems8ZnTaB1J7Y9oUDStxeEqgdCMC5" #X-men Animated Series
YOUTUBE_CHANNEL_ID_5041 = "PLlu6_-FiYhk_X92fo1VtCreYzWd7Lz3gn" #Bob the Builder Kids
YOUTUBE_CHANNEL_ID_5042 = "PLlKsLvkXtv9WbqLn4R5gi-ZEmobVpIWZS" #The Mummy
YOUTUBE_CHANNEL_ID_5043 = "PLzovi87vDfzLfWF7wuSI87P7BL_sYeQE1" #Chaotic Sci-Fi
YOUTUBE_CHANNEL_ID_5044 = "PLLgFGd95FMWzwm4nvBZ0uY1mvNKoLua1L" #Heavy Gear (scifi)
YOUTUBE_CHANNEL_ID_5045 = "PLqcNVz8UuCsIqwHQXAUkTxV0yKxwWVN4a" #Ivanhoe the king's Knight
YOUTUBE_CHANNEL_ID_5046 = "PL3oTh7HxUAl-QvH5Lszu_RzzarIqvFYdk" #ReBoot Complete Series
YOUTUBE_CHANNEL_ID_5047 = "PLwm-Da7ujg1keKyOt8eMTZiLPfXEFBThh" #Star Trek Animated Series S1
YOUTUBE_CHANNEL_ID_5048 = "PL4ah6olQcLpxsqnMLqmD5w1PirYe-ZRRM" #Animated TV Shows Mix
YOUTUBE_CHANNEL_ID_5049 = "PLd-kdZ3N0uXCWmUzlEF0f7HfwxammTJcK" #Animated Favorites
YOUTUBE_CHANNEL_ID_5050 = "PLwm-Da7ujg1mvNEbY5ParvdLme5YIfOBD" #Star Trek Animated Series S2
YOUTUBE_CHANNEL_ID_5051 = "PLYGkYENGjRLqK81KY-GzFOsBEMEqJLIsY" #Dinky Dog (kids)
YOUTUBE_CHANNEL_ID_5052 = "PLUX4fpHUux5V63R7gWyHGUqH0HqtPD6CI" #Vir: The Robot Boy (kids)
YOUTUBE_CHANNEL_ID_5053 = "PL6fJmjt84zZh1caGDR_YO66Li0IYjZRuA" #Legend of Tarzan Complete Series
YOUTUBE_CHANNEL_ID_5054 = "PLNXCO7Z2kJDRxIPt0Vn9NDAdjGQiENsWM" #Simba the king lion (kids)
YOUTUBE_CHANNEL_ID_5055 = "PL7wUqMKPcZtdLk6NWfz7pQFzkSfPwgwFb" #Little Bear Series (Kids)
YOUTUBE_CHANNEL_ID_5056 = "PLOkQ1ZM_uTEKjMEwwZz85RLAzcWucUpoT" #Kong the Animated Series
YOUTUBE_CHANNEL_ID_5057 = "PLsmrMuo7ga_Zjl8hrOtp_gw0snVA9Z9qI" #Car Cartoons for Children (Kids)
YOUTUBE_CHANNEL_ID_5058 = "PL7wUqMKPcZtd96OuKn-3vYVOzpLLSi9jB" #Angel's Friends Kids
YOUTUBE_CHANNEL_ID_5059 = "PL5xBzAogWJYriXviZipBi0za3zPGR4ROy" #Pocket Dragons Cartoon Kids
YOUTUBE_CHANNEL_ID_5060 = "PL7wUqMKPcZteiYcnG-deY6qYOP7ZeEtmO" #Jungle Book (kids)
YOUTUBE_CHANNEL_ID_5061 = "PLqbnZOnhI_5QNred5n6FVYNYYKCSOBnpA" #Grimm's fairy Tales (kids)
YOUTUBE_CHANNEL_ID_5062 = "PLqrLEr7tAISpmpzgx9DGGdTV21N8oM9WA" #cartoon
YOUTUBE_CHANNEL_ID_5063 = "PLFHLBLrXahtba_VDAfS1KtaXP1sVhIkxq" #Anime Movies
YOUTUBE_CHANNEL_ID_5064 = "PLQ1h4vDpyXDMm_G5v0VBmqtnpgsmwKuKC" #80s Cartoon Movies
YOUTUBE_CHANNEL_ID_5065 = "PLc4SFpl1YyvuwwT9RFeEZbzfKHsdDX1V5" #Cartoon & Anime Movies
YOUTUBE_CHANNEL_ID_5066 = "PLRQAisQ_6Be4x4J2zVdEuITH5lXDpPIaQ" #Anime Movies
YOUTUBE_CHANNEL_ID_5067 = "PLIyKjfr8GB7Of0lhSddXfWcbUbdhTKMaW" #Dubbed Movies N OVAs
YOUTUBE_CHANNEL_ID_5068 = "PLy6nRkX3CzyL4l6BAWjHSRwmXWvWgNdGU" #Anime 80s,90,2k
YOUTUBE_CHANNEL_ID_5069 = "PLrkKzgyiKOS_gjlak9GZ2R8RJ0p8Ycc3u" #Booba Cartoons
YOUTUBE_CHANNEL_ID_5070 = "PLiyrII9x2F7zUHMR9h3_TzGeWIBtUK0uS" #Dick Tracy
YOUTUBE_CHANNEL_ID_5071 = "PLA72C010C5A6B9EC9"                 #Micky Mouse 1928-1934
YOUTUBE_CHANNEL_ID_5072 = "PLkAnhCzB7JIi9hifMPIKWZPrYqwJGECUa" #Dinosaur Cartoons
YOUTUBE_CHANNEL_ID_5073 = "PLsm97yOU5QezeeTONhHtVgQlQ1Upt2qPr" #Mixed Cartoons
YOUTUBE_CHANNEL_ID_5074 = "PLxdrxmf1-t6frRbskKzWs2VfllxyROvzz" #70s cartoons
YOUTUBE_CHANNEL_ID_5075 = "PLOsuDHYd_McXe2ojtqbRrINFOVWudpK02" #Classic Cartoons
YOUTUBE_CHANNEL_ID_5076 = "PLJkSXo2tdjuje7Z4UDrY5pnKO2ZuA28lJ" #Looney Toons Webtoons
YOUTUBE_CHANNEL_ID_5077 = "PL7A0HrLo0US_dxNuY33u4glXusI4pcDa_" #Xmas Cartoon Movies
YOUTUBE_CHANNEL_ID_5078 = "PLqiXVPKT8F-vW_-teieFp7t70cOQAwx2w" #Old Cartoons
YOUTUBE_CHANNEL_ID_5079 = "PLnv3kzrevhDg8L4BSwy6YVKXQ6dR-rEjF" #Kids Cartoons
YOUTUBE_CHANNEL_ID_5080 = "PL3CBE08ADF1562BAA"                 #Scifi cartoons
YOUTUBE_CHANNEL_ID_5081 = "PLenpDTrubiPkWviag5IWwSTlxU-PppA4x" #Sci-fi Shorts & CGI
YOUTUBE_CHANNEL_ID_5082 = "" #
YOUTUBE_CHANNEL_ID_5083 = "PLzovi87vDfzLSVC5UD10_DNrXIGUX5CZA" #scifi Martin Mysteries
YOUTUBE_CHANNEL_ID_5084 = "PLj9r_42NzuMT7C1k6z7yNaV-4ct9pXQuB" #1960s Space Angel
YOUTUBE_CHANNEL_ID_5085 = "PLKR-WUXdFW-tIMC_om6E4gRZynnyDl984" #Scifi Godzilla
YOUTUBE_CHANNEL_ID_5086 = "PLZs0gQed9tMSh045V4TSkbxwptHXpxd49" #Astro Boy
YOUTUBE_CHANNEL_ID_5087 = "PLQ00Dh3xOmnZvqq_WemhjBTOezuY-EhrU" #Scifi Mix
YOUTUBE_CHANNEL_ID_5088 = "PLHiJcdYpg_-2du2MQciAlfd47UuvZO3gM" #Comedy Cartoon Mix
YOUTUBE_CHANNEL_ID_5089 = "PLEAKW4PcnvxmrJxTJPgNSrSgnhRdMHaqd" #Classic Looney Cartoons
YOUTUBE_CHANNEL_ID_5090 = "PLcvAAt6aAUZole2agAJKaN1Y2yjlhq84K" #Comedy Cat & Keet
YOUTUBE_CHANNEL_ID_5091 = "PLF9Ksz48e9pP_uJr94if6ZXoDxmggT9SB" #Mighty Mouse
YOUTUBE_CHANNEL_ID_5092 = "PLZs0gQed9tMT2zhdJ9Fwx5AHlA5gYEaqE" #Mighty Mouse
YOUTUBE_CHANNEL_ID_5093 = "PL1q0YL7MtchCOZ5TMBtuOKSPlXLhjr9lW" #Underdog
YOUTUBE_CHANNEL_ID_5094 = "PL6Iw4ELd-WzXfweLJtlt5LtxllTUkZ53P" #Superhero cartoons
YOUTUBE_CHANNEL_ID_5095 = "PLLrV5xCMn4kB1hBeqRFuvY994bOs5Jmjw" #Superhero Toons
YOUTUBE_CHANNEL_ID_5096 = "PLcZkwR3bL1rudUN5dC3kmk-lXFvhVKL0x" #DC Super Hero Girls
YOUTUBE_CHANNEL_ID_5097 = "" #
YOUTUBE_CHANNEL_ID_5098 = "" #
YOUTUBE_CHANNEL_ID_5099 = "" #
YOUTUBE_CHANNEL_ID_5207 = "PL8833BA169D818131"                 #Ghostbusters
YOUTUBE_CHANNEL_ID_5208 = "PLJhIcqoOEkIHzRfW7JkToSanTq3_sVC9Y" #Halloween Specials (kids)
YOUTUBE_CHANNEL_ID_5209 = "PLJhIcqoOEkIF3IDCJKzeUrFz8DJVI99wf" #Christmas Specials (kids)
YOUTUBE_CHANNEL_ID_5210 = "PLJhIcqoOEkIGvRL_xHLR-rJ02ugIjIvIN" #Veggie Tales
YOUTUBE_CHANNEL_ID_5211 = "PLC5928B59A036F71F"                 #Casper The Friendly Ghost
YOUTUBE_CHANNEL_ID_5212 = "PLJhIcqoOEkIG8V0mD9R4UHEn2D_H0uYTw" #Postman Pat
YOUTUBE_CHANNEL_ID_5213 = "PLJhIcqoOEkIHf_U2Xm51ikdQStv5itLkG" #Animated Shows & Movies
YOUTUBE_CHANNEL_ID_5214 = "PLJhIcqoOEkIGK4UJc4ipDXAs5C5cExrUg" #Animated Shorts & Movies
YOUTUBE_CHANNEL_ID_5215 = "PLJhIcqoOEkIG7ZHKu_XPC1PVXqHs_ziP-" #Animated Shows & Movies
YOUTUBE_CHANNEL_ID_5216 = "" #
YOUTUBE_CHANNEL_ID_5217 = "PLLCcmBcBRcT9jhSlKI_ZN1GBLHIKrfmtq" #He-Man Episodes
YOUTUBE_CHANNEL_ID_5218 = "" #
YOUTUBE_CHANNEL_ID_5219 = "" #
YOUTUBE_CHANNEL_ID_5220 = "" #
YOUTUBE_CHANNEL_ID_5270 = "wearebusybeavers" #Busy Beavers
YOUTUBE_CHANNEL_ID_5271 = "PLuALSlPoVa23Ok2TFHCrftqkDKOnIpFLo" #Official Pat and Stan
YOUTUBE_CHANNEL_ID_5272 = "PLRU3FsQ1MS5KFsjh5Txh14b4PuGEn9MUK" #Tractor Tom
YOUTUBE_CHANNEL_ID_5273 = "PLHOR8x-IicVJDAmJWZmJ-IMu1x3lTAld5" #HUMF
YOUTUBE_CHANNEL_ID_5274 = "PLM7OLrgQDj4YIWPViSg4IudtwqluSJ60E" #Max & Ruby
YOUTUBE_CHANNEL_ID_5275 = "PLV3Gd8vEgOrjvlv718bZzcAf5DdcyGjHr" #Hoopla Kids Show
YOUTUBE_CHANNEL_ID_5276 = "UCwOS0K6uKOqoAWU7MUEtxaQ" #Cartoon Candy
YOUTUBE_CHANNEL_ID_5277 = "PL1jLb_9BOrCC2kd1wxZi2Bnvi2hkMTDCd" #Kids Channel
YOUTUBE_CHANNEL_ID_5278 = "PLaKLlbutuIs83m4PDnCkxgz_5hduThPsG" #TuTiTu TV
YOUTUBE_CHANNEL_ID_5279 = "PL-qhrpQ30cRzkr24PV9xbLxQXgCaNH0je" #Yo GABBA GABBA
YOUTUBE_CHANNEL_ID_5280 = "PL0VE_cI7-AYRx9Qbz5C0oQix0AO6YdCtw" #Little Baby Bum
YOUTUBE_CHANNEL_ID_5281 = "UCncFzSeWqySvOXEbQoEJsZg" #Little Bear
YOUTUBE_CHANNEL_ID_5282 = "" #
YOUTUBE_CHANNEL_ID_5283 = "PLpd15K7DiNG8mj-bcXKwvqmET6ZWIWGzS" #Bananas In Pyjamas
YOUTUBE_CHANNEL_ID_5284 = "PLhLlo5SXGT_0kedDOwvbTeMwp0Uz3Af4q" #Fifi and the Flowertots
YOUTUBE_CHANNEL_ID_5285 = "PLzcEpQYkRSQ1hBS_Caklp3a3NupYQxbqM" #Postman Pat
YOUTUBE_CHANNEL_ID_5286 = "PLKxKJVHwiseXLWkzfAOIVqZyUDNLnuplm" #Olivia The Pig
YOUTUBE_CHANNEL_ID_5287 = "PLT81qowKRHzRCE2M7wuj2Y56ZTPLq0DMD" #Little Charlie Bear
YOUTUBE_CHANNEL_ID_5288 = "PLGYOf7BkKBf0iifp9NGfwId1wZcd1WSJX" #VeggieTales
YOUTUBE_CHANNEL_ID_5289 = "PL-zGgztzqlybth6-PPi1d2T39srXc--8q" #Strawberry Shortcake
YOUTUBE_CHANNEL_ID_5290 = "PL3WuRw0nOgHPOgZ04JAzw_BfLzw0LHpLE" #Noddy In Toyland
YOUTUBE_CHANNEL_ID_5291 = "PL6um4JyGrH5oe9UGIlUUB2efBS_erzvL1" #Ben and Holly Little Kingdom
YOUTUBE_CHANNEL_ID_5292 = "PLdpyjDsvgMln1KZ7tqtKEMgCUMpRRLaip" #The Kids Club
YOUTUBE_CHANNEL_ID_5293 = "PLB6QoGOGkP7OSV0vkG53hxyX6oFwkwQ4O" #Giggle Bellies
YOUTUBE_CHANNEL_ID_5294 = "PLtgzvugo5sZdLGaHopCexqGPGiaZgBgl3" #Oh My Genius
YOUTUBE_CHANNEL_ID_5295 = "PLBlSpozHTVp0MTkOsHfYkqmM-XoFmS4is" #Fluffy Jet Toys
YOUTUBE_CHANNEL_ID_5296 = "" #
YOUTUBE_CHANNEL_ID_5297 = "" #
YOUTUBE_CHANNEL_ID_5298 = "" #
YOUTUBE_CHANNEL_ID_5299 = "" #
YOUTUBE_CHANNEL_ID_5300 = "PLcODclIgElxJXl4I3C2QgOmruKBybol9Y" #Anime Shorts N Movies
YOUTUBE_CHANNEL_ID_5301 = "PLKrpm9lxqdtyR8z1jz0M3ps_sgU9kJxfr" #Anime Movies English
YOUTUBE_CHANNEL_ID_5302 = "PLyKfjbPdkUJUYBMRFewZY5RCuVnqSHcbu" #Anime: Movies
YOUTUBE_CHANNEL_ID_5303 = "PLeJ4dpVCYxD6Yw0pO9ZnBvojgSX3BDioD" #Movies: Anime
YOUTUBE_CHANNEL_ID_5304 = "" #
YOUTUBE_CHANNEL_ID_5305 = "" #
YOUTUBE_CHANNEL_ID_5306 = "" #
YOUTUBE_CHANNEL_ID_5307 = "" #
YOUTUBE_CHANNEL_ID_5308 = "" #
YOUTUBE_CHANNEL_ID_5309 = "" #
YOUTUBE_CHANNEL_ID_5310 = "" #
YOUTUBE_CHANNEL_ID_5311 = "" #
YOUTUBE_CHANNEL_ID_5312 = "" #
YOUTUBE_CHANNEL_ID_5313 = "" #
YOUTUBE_CHANNEL_ID_5314 = "" #
YOUTUBE_CHANNEL_ID_5315 = "" #
YOUTUBE_CHANNEL_ID_5316 = "" #
YOUTUBE_CHANNEL_ID_5317 = "" #
YOUTUBE_CHANNEL_ID_5318 = "" #
YOUTUBE_CHANNEL_ID_5319 = "" #
YOUTUBE_CHANNEL_ID_5320 = "" #
YOUTUBE_CHANNEL_ID_5321 = "" #
YOUTUBE_CHANNEL_ID_5322 = "" #
YOUTUBE_CHANNEL_ID_5323 = "" #
YOUTUBE_CHANNEL_ID_5324 = "" #
YOUTUBE_CHANNEL_ID_5325 = "" #
YOUTUBE_CHANNEL_ID_5326 = "" #
YOUTUBE_CHANNEL_ID_5327 = "" #
YOUTUBE_CHANNEL_ID_5328 = "" #
YOUTUBE_CHANNEL_ID_5329 = "" #
YOUTUBE_CHANNEL_ID_5330 = "" #
YOUTUBE_CHANNEL_ID_5331 = "" #
YOUTUBE_CHANNEL_ID_5332 = "" #
YOUTUBE_CHANNEL_ID_5333 = "" #
YOUTUBE_CHANNEL_ID_5334 = "" #
YOUTUBE_CHANNEL_ID_5335 = "" #
YOUTUBE_CHANNEL_ID_5336 = "" #
YOUTUBE_CHANNEL_ID_5337 = "" #
YOUTUBE_CHANNEL_ID_5338 = "" #
YOUTUBE_CHANNEL_ID_5339 = "" #
YOUTUBE_CHANNEL_ID_5340 = "" #
YOUTUBE_CHANNEL_ID_5341 = "" #
YOUTUBE_CHANNEL_ID_5342 = "" #
YOUTUBE_CHANNEL_ID_5343 = "" #
YOUTUBE_CHANNEL_ID_5344 = "" #
YOUTUBE_CHANNEL_ID_5345 = "" #
YOUTUBE_CHANNEL_ID_5346 = "" #
YOUTUBE_CHANNEL_ID_5347 = "" #
YOUTUBE_CHANNEL_ID_5348 = "" #
YOUTUBE_CHANNEL_ID_5349 = "" #
YOUTUBE_CHANNEL_ID_5350 = "PLufIO1FTWFz9GObPdcbjqpOpc0PjBPyUz" #Star Trek Animated
YOUTUBE_CHANNEL_ID_5351 = "UCT2KZRq0t6BhQg0sGCYt9OQ"           #Spaceballs Animated
YOUTUBE_CHANNEL_ID_5352 = "WEP"                                #Voltron Channel
YOUTUBE_CHANNEL_ID_5353 = "PLiNS6whSC7LlVKYG_S1hU3MmRCyssdFRs" #Atomicron Episodes
YOUTUBE_CHANNEL_ID_5354 = "" #
YOUTUBE_CHANNEL_ID_5355 = "" #
YOUTUBE_CHANNEL_ID_5356 = "" #
YOUTUBE_CHANNEL_ID_5357 = "" #
YOUTUBE_CHANNEL_ID_5358 = "" #
YOUTUBE_CHANNEL_ID_5359 = "" #
YOUTUBE_CHANNEL_ID_5360 = "" #
YOUTUBE_CHANNEL_ID_5361 = "" #
YOUTUBE_CHANNEL_ID_5362 = "" #
YOUTUBE_CHANNEL_ID_5363 = "" #
YOUTUBE_CHANNEL_ID_5364 = "" #
YOUTUBE_CHANNEL_ID_5365 = "" #
YOUTUBE_CHANNEL_ID_5366 = "" #
YOUTUBE_CHANNEL_ID_5367 = "" #
YOUTUBE_CHANNEL_ID_5368 = "" #
YOUTUBE_CHANNEL_ID_5369 = "" #
YOUTUBE_CHANNEL_ID_5370 = "" #
YOUTUBE_CHANNEL_ID_5371 = "" #
YOUTUBE_CHANNEL_ID_5372 = "" #
YOUTUBE_CHANNEL_ID_5373 = "" #
YOUTUBE_CHANNEL_ID_5374 = "" #
YOUTUBE_CHANNEL_ID_5375 = "PLNw_hEO5pK1oilmenQgX3KuWZZ6xlG_5Y" #Super Hero Squad
YOUTUBE_CHANNEL_ID_5376 = "PLNw_hEO5pK1rdjEOr5_CsfOG2IF0k6RJj" #Ultimate Spider-Man
YOUTUBE_CHANNEL_ID_5377 = "PLNw_hEO5pK1oRPp3UP1zM8g58cqae-tZM" #Avengers Assemble
YOUTUBE_CHANNEL_ID_5378 = "PLNw_hEO5pK1oWX6Uymk8YBtNcmC64EZlY" #Guardians Of The Galaxy
YOUTUBE_CHANNEL_ID_5379 = "PLcrApfnvcfVziLpbjdtWlpJd7E9czrZR3" #DC Super Friends
YOUTUBE_CHANNEL_ID_5380 = "PLcrApfnvcfVx6cBCnVWcbW8wPZZZ6Pcza" #Batman Unlimited
YOUTUBE_CHANNEL_ID_5381 = "PLcrApfnvcfVzhReuqA7CrP9_-K1YWDReb" #Classic DC Cartoons
YOUTUBE_CHANNEL_ID_5382 = "UCUh6BtszC2-ubKiv0hLf6gQ"           #She-Ra Channel
YOUTUBE_CHANNEL_ID_5383 = "HeMan"                              #He Man Channel
YOUTUBE_CHANNEL_ID_5384 = "UCHpsEFbbXOSovRKp5Wvg5aA"           #Bravestar Channel
YOUTUBE_CHANNEL_ID_5385 = "UCpq_3STONuP2fuZUirJuBNA"           #Superman Animated
YOUTUBE_CHANNEL_ID_5386 = "UCJAWEVDvEJe1W299pWuTZUQ"           #Batman Animated Series
YOUTUBE_CHANNEL_ID_5387 = "PLiNS6whSC7LlhrRxmliMQPACnIe2lKdqd" #The Legend Of Zorro
YOUTUBE_CHANNEL_ID_5388 = "" #
YOUTUBE_CHANNEL_ID_5389 = "" #
YOUTUBE_CHANNEL_ID_5390 = "" #
YOUTUBE_CHANNEL_ID_5391 = "" #
YOUTUBE_CHANNEL_ID_5392 = "" #
YOUTUBE_CHANNEL_ID_5393 = "" #
YOUTUBE_CHANNEL_ID_5394 = "" #
YOUTUBE_CHANNEL_ID_5395 = "" #
YOUTUBE_CHANNEL_ID_5396 = "" #
YOUTUBE_CHANNEL_ID_5397 = "" #
YOUTUBE_CHANNEL_ID_5398 = "" #
YOUTUBE_CHANNEL_ID_5399 = "" #
YOUTUBE_CHANNEL_ID_5400 = "PLMDGujplXPMZcNVXJzAwkO6PuB2L1qBis" #Gawayn Full Episodes
YOUTUBE_CHANNEL_ID_5401 = "UCph-WGR0oCbJDpaWmNHb5zg"           #Larva TUBA Channel
YOUTUBE_CHANNEL_ID_5402 = "UCGRODP7wtTU_uyNZmu9cb7g"           #Spookiz Cartoon Channel
YOUTUBE_CHANNEL_ID_5403 = "UCHB-zOorX9lc7r6mMTdaFAA"           #Rev N Roll Channel
YOUTUBE_CHANNEL_ID_5404 = "UCmst562fALOY2cKb4IFgqEg"           #Boomerang UK Channel
YOUTUBE_CHANNEL_ID_5405 = "UCk5bIh544LgQ2_ecTQQ5wQg"           #KidsFlix Channel
YOUTUBE_CHANNEL_ID_5406 = "UCktaw9L-f65LzUUdjmCFkbQ"           #Disney XD Channel
YOUTUBE_CHANNEL_ID_5407 = "" #
YOUTUBE_CHANNEL_ID_5408 = "" #
YOUTUBE_CHANNEL_ID_5409 = "" #
YOUTUBE_CHANNEL_ID_5410 = "" #
YOUTUBE_CHANNEL_ID_5411 = "" #
YOUTUBE_CHANNEL_ID_5412 = "" #
YOUTUBE_CHANNEL_ID_5413 = "" #
YOUTUBE_CHANNEL_ID_5414 = "" #
YOUTUBE_CHANNEL_ID_5415 = "" #
YOUTUBE_CHANNEL_ID_5416 = "" #
YOUTUBE_CHANNEL_ID_5417 = "" #
YOUTUBE_CHANNEL_ID_5418 = "" #
YOUTUBE_CHANNEL_ID_5419 = "" #
YOUTUBE_CHANNEL_ID_5420 = "" #
YOUTUBE_CHANNEL_ID_5421 = "" #
YOUTUBE_CHANNEL_ID_5422 = "" #
YOUTUBE_CHANNEL_ID_5423 = "" #
YOUTUBE_CHANNEL_ID_5424 = "" #
YOUTUBE_CHANNEL_ID_5425 = "PLySo2SlSHPSPEowUi7aqAYr8UYPK7Dn_o" #Magi-Nation
YOUTUBE_CHANNEL_ID_5426 = "PLySo2SlSHPSNYc2kkPjAJHVK1ThT1Lb_P" #Legend Of Zelda
YOUTUBE_CHANNEL_ID_5427 = "PLySo2SlSHPSMlN0-AGtCSZUWiabfKeRmc" #Captain N Game Master
YOUTUBE_CHANNEL_ID_5428 = "PLySo2SlSHPSOZe6pNEA3ICnHoE0kBv8Vw" #Evolution Animated Series
YOUTUBE_CHANNEL_ID_5429 = "PLGsVaqfVidOwKdxkIkmJhyHWqrynazT78" #Robotboy Compilations
YOUTUBE_CHANNEL_ID_5430 = "PLmprnjY0aArOHlrP-fBs-bXBf0yuHmsxq" #Space Ranger Roger
YOUTUBE_CHANNEL_ID_5431 = "" #
YOUTUBE_CHANNEL_ID_5432 = "" #
YOUTUBE_CHANNEL_ID_5433 = "" #
YOUTUBE_CHANNEL_ID_5434 = "" #
YOUTUBE_CHANNEL_ID_5435 = "" #
YOUTUBE_CHANNEL_ID_5436 = "" #
YOUTUBE_CHANNEL_ID_5437 = "" #
YOUTUBE_CHANNEL_ID_5438 = "" #
YOUTUBE_CHANNEL_ID_5439 = "" #
YOUTUBE_CHANNEL_ID_5440 = "" #
YOUTUBE_CHANNEL_ID_5441 = "" #
YOUTUBE_CHANNEL_ID_5442 = "" #
YOUTUBE_CHANNEL_ID_5443 = "" #
YOUTUBE_CHANNEL_ID_5444 = "" #
YOUTUBE_CHANNEL_ID_5445 = "" #
YOUTUBE_CHANNEL_ID_5446 = "" #
YOUTUBE_CHANNEL_ID_5447 = "" #
YOUTUBE_CHANNEL_ID_5448 = "" #
YOUTUBE_CHANNEL_ID_5449 = "" #
YOUTUBE_CHANNEL_ID_5450 = "PLDg7FjaC1Jx9mFfwswQJRf5Be4I3hAlVR" #Inspector Gadget
YOUTUBE_CHANNEL_ID_5451 = "PLySo2SlSHPSOBOcRLpSsmr5CqvDRlUa-U" #Super Mario Brothers
YOUTUBE_CHANNEL_ID_5452 = "PLySo2SlSHPSOOGZM3_2Qun52hCaRNYW9y" #Sonic The Hedgehog
YOUTUBE_CHANNEL_ID_5453 = "UC1D26ByrbZVwuMgjVWmsOuw"           #Cartoon Box Channel
YOUTUBE_CHANNEL_ID_5454 = "PL01wXRlm9kws9NDWJpF1e_ZffofflqAci" #A New Kind Of Magic
YOUTUBE_CHANNEL_ID_5455 = "PinkPanthersShow"                   #Pink Panther Show
YOUTUBE_CHANNEL_ID_5456 = "FuggetAboutIt1"                     #Fugget About It Channel
YOUTUBE_CHANNEL_ID_5457 = "MondoMedia"                         #Mondo Media Channel
YOUTUBE_CHANNEL_ID_5458 = "UCM8cnfYuuj3uCB7d5C9EwCw"           #John Callahans Quads
YOUTUBE_CHANNEL_ID_5459 = "TVTVonline"                         #Transylvania Television
YOUTUBE_CHANNEL_ID_5460 = "UCtFE7k9pGHIrUqRLmzD8f4A"           #Rocky N Bullwinkle
YOUTUBE_CHANNEL_ID_5461 = "" #
YOUTUBE_CHANNEL_ID_5462 = "PLzO16T-7mKLZaDanYN9FoLwpy6Oeirpe5" #Anime: Full Movies
YOUTUBE_CHANNEL_ID_5463 = "PLsI4BZBK6_FdEUhSw4dNXZdCOrXKadpfK" #Anime: Assassin Classroom
YOUTUBE_CHANNEL_ID_5464 = "PLmgMZPhVhmRpZAPQS2I3JD7Sr8b7gGDxN" #Anime Movie Set
YOUTUBE_CHANNEL_ID_5465 = "PL2aoGe5t_a0IRRvENQlsWv9OIe8F7PH4U" #90s Anime Movies
YOUTUBE_CHANNEL_ID_5466 = "PLrlrSXaxetaYrbIIbNrlOs1Bl356T0qyl" #Anime: My Hero Academia
YOUTUBE_CHANNEL_ID_5467 = "PLcqSHtSo8SQ9xK5RO1oufrTKP0M3r5glA" #Anime: Devil Revived
YOUTUBE_CHANNEL_ID_5468 = "PL3JwyBd7p0ZI6wn7Fk2_GeII8_VYky3CO" #Anime Films N Shorts
YOUTUBE_CHANNEL_ID_5469 = "PL3u2z480BtrV7Kt4JoJ6pRWEG7-wPS7Eh" #Jungle Book English Dub
YOUTUBE_CHANNEL_ID_5470 = "PL5QucLB12NCahBP2fpvecK9ZDRcYfduDS" #Anime: Hikaru no Go
YOUTUBE_CHANNEL_ID_5471 = "PLKYsfT7yVchQ6a_BeJb1zkH9FnLvWO7_A" #Super Robot Monkey Team
YOUTUBE_CHANNEL_ID_5472 = "PLKNdQnCwL6jpmP1mk4gH1Pk8vCWpvnNwA" #Anime: English Dubbed
YOUTUBE_CHANNEL_ID_5473 = "PLA6KWDanCY6TPv4G2wS-W6Wc9VYwKQS3a" #English Dubbed Anime
YOUTUBE_CHANNEL_ID_5474 = "PLLmfPeDOnTawfw1m51RsM3pSBysRxrNte" #Legend Of Zorro
YOUTUBE_CHANNEL_ID_5475 = "" #
YOUTUBE_CHANNEL_ID_5476 = "" #
YOUTUBE_CHANNEL_ID_5477 = "" #
YOUTUBE_CHANNEL_ID_5478 = "" #
YOUTUBE_CHANNEL_ID_5479 = "UCd4axAUtfrZyJOoa3mLgQLg"           #Anime Theater Channel
YOUTUBE_CHANNEL_ID_5480 = "AquarionDubbed"                     #Aquarion Dub Channel
YOUTUBE_CHANNEL_ID_5481 = "UC1N-PKEIJBLy-jL49d3QG7A"           #Dragon Ball Channel
YOUTUBE_CHANNEL_ID_5482 = "UCVHPu5kk9Onnlp70L9RWsnw"           #Action Anime Channel
YOUTUBE_CHANNEL_ID_5483 = ""           #
YOUTUBE_CHANNEL_ID_5484 = "UCRepcWts1FjVheTSQN-OohQ"           #Anime For Life Channel
YOUTUBE_CHANNEL_ID_5485 = "lisamacdonald97"                    #Anime Sunday Channel
YOUTUBE_CHANNEL_ID_5486 = "UCJ_zhy2BwkgAFe4Gj_qIXpA"           #Tahanea Cynthia Go Anime
YOUTUBE_CHANNEL_ID_5487 = "UCJ2gftbil8-wwYQqKScLfSA"           #Boku wa Tomodachi Ga Sukunai
YOUTUBE_CHANNEL_ID_5488 = "UC6Y7KshMlk40FMziBgA0nSQ"           #Go To Anime 2.0 Channel
YOUTUBE_CHANNEL_ID_5489 = "nickleontiisanerd"                  #Chip Anime Channel
YOUTUBE_CHANNEL_ID_5490 = ""                      #
YOUTUBE_CHANNEL_ID_5491 = "UCjQVN_oY4ZHXIe2YjWW-wzA"           #Moon Tam Channel

YOUTUBE_CHANNEL_ID_5492 = "PLgeqscP3wk1c_Fm_zYWPjE7otjxwvPezj" #Yo-Kai Watch
YOUTUBE_CHANNEL_ID_5493 = "PLJ8JY5W78SUopDuvF_XrE4888xHZzyOmd" #Overlord
YOUTUBE_CHANNEL_ID_5494 = "PL6XlDb4l-GY9oZ0w-iwQvIveiOonHvdWb" #Sky Wizards Academy
YOUTUBE_CHANNEL_ID_5495 = "PLr8hezU-iC1WyMo4v0l5YYpuWs7sVAzUr" #Puzzle N Dragon X
YOUTUBE_CHANNEL_ID_5496 = "PL9652bz5iwUDnkDcED811HHBuZy0Yka3X" #Pokemon Generations
YOUTUBE_CHANNEL_ID_5497 = "PLG-quFi1sRjpUL4g1FHfjcHVTzcQYddJz" #Izetta The Last Witch
YOUTUBE_CHANNEL_ID_5498 = "UCU-UVjRY9MpJXMt6DFrlJPg" #Hunter X Hunter
YOUTUBE_CHANNEL_ID_5499 = "PLYhek8m436-vy7Bk_0dxHuiNpwr-yhoVx" #Aquarion Logos
YOUTUBE_CHANNEL_ID_5500 = "UCV2rp8vEBVysQcSDzqh_Btg" #Naruto Channel	

@route(mode='animate_heroes')
def Animate_Heroes():

	add_link_info('[B][COLORorange]== Ani-mate ==[/COLOR][/B]', mediapath+'animate.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Batman Unlimited[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5380+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic DC Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5381+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superman Animated[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5385+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Batman Animated Series[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5386+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Super Hero Squad[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5375+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ultimate Spider-Man[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5376+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Avengers Assemble[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5377+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Guardians Of The Galaxy[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5378+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DC Super Friends[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5379+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Legend Of Zelda[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5426+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Captain N Game Master[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5427+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Evolution Animated Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5428+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Robotboy Compilations[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5429+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Space Ranger Roger[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5430+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Inspector Gadget[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5450+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Magi-Nation[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5425+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sonic The Hedgehog[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5452+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]DC Super Hero Girls[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5096+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Justice League Animated[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5012+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Spiderman Animated 94-98[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5022+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Legend of Zorro Animated [/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5030+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Tick 1994-1996[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5018+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]X-men Animated Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5040+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Scifi: Space Angel[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5084+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Superhero Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5094+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sci-fi: Astro Boy[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5086+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Mighty Mouse Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5092+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Underdog Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5093+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Superhero Toons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5095+"/", folder=True,
		icon=mediapath+"animate_heroes.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'animate.png', fanart)
	
@route(mode='animate_comedy')
def Animate_Comedy():

	add_link_info('[B][COLORorange]== Ani-mate ==[/COLOR][/B]', mediapath+'animate.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Spaceballs Animated[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5351+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Inspector Gadget[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5450+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Super Mario Brothers[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5451+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sonic The Hedgehog[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5452+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cartoon Box Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5453+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]A New Kind Of Magic[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5454+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pink Panther Show[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_5455+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fugget About It Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_5456+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mondo Media Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_5457+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]John Callahans Quads[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5458+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Transylvania Television[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_5459+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rocky N Bullwinkle[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5460+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Tick 1994-1996[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5018+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mr Bean Animated Series S1[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5026+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mr Bean Animated Series S2[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5017+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mr Bean Cartoon World[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5031+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sponge Bob Square Pants[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5039+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Buzz Lightyear[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5035+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)		

	Add_Dir(
		name="[COLOR white][B]Cartoon Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5088+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Looney Toons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5089+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Comedy: Cat & Keet[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5090+"/", folder=True,
		icon=mediapath+"animate_comedy.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'animate.png', fanart)
	
@route(mode='animate_mixed')
def Animate_Mixed():

	add_link_info('[B][COLORorange]== Ani-mate ==[/COLOR][/B]', mediapath+'animate.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Favorites[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5049+"/", folder=True,
		icon=mediapath+"animate_mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Episode Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5048+"/", folder=True,
		icon=mediapath+"animate_mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Movies & TV[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5037+"/", folder=True,
		icon=mediapath+"animate_mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mixed Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5073+"/", folder=True,
		icon=mediapath+"animate_mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]70s Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5074+"/", folder=True,
		icon=mediapath+"animate_mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5075+"/", folder=True,
		icon=mediapath+"animate_mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Looney Tunes Webtoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5076+"/", folder=True,
		icon=mediapath+"animate_mixed.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'animate.png', fanart)
	
@route(mode='animate_kids')
def Animate_Kids():

	add_link_info('[B][COLORorange]== Ani-mate ==[/COLOR][/B]', mediapath+'animate.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Gawayn Full Episodes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5400+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Larva TUBA Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5401+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Spookiz Cartoon Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5402+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rev N Roll Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5403+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Boomerang UK Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5404+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]KidFlix Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5405+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Disney XD Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5406+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sponge Bob Square Pants[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5039+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Buzz Lightyear[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5035+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)		

	Add_Dir(
		name="[COLOR white][B]Sabrina Teenage Witch[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5019+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Angels Friends[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5058+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Jungle Book[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5060+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bob The Builder[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5041+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Simba The King Lion[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5054+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Grimms Fairy Tales[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5061+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Little Bear Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5055+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Vir: Robot Boy (Hindi)[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5052+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dinky Dog[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5051+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Car Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5057+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pocket Dragons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5059+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Booba Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5069+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Micky Mouse 1928-1934[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5071+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dinosaur Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5072+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]He-Man Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5217+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5215+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shows & Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5213+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shorts & Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5214+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Postman Pat Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5212+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Casper The Friendly Ghost[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5211+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Veggie Tales Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5210+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ghostbusters[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5207+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Halloween Specials[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5208+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Christmas Specials[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5209+"/", folder=True,
		icon=mediapath+"animate_kids.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'animate.png', fanart)
	
@route(mode='animate_cartoons')
def Animate_Cartoons():

	add_link_info('[B][COLORorange]== Ani-mate ==[/COLOR][/B]', mediapath+'animate.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Car Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5057+"/", folder=True,
		icon=mediapath+"animate_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pocket Dragons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5059+"/", folder=True,
		icon=mediapath+"animate_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sonic The Hedgehog[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5036+"/", folder=True,
		icon=mediapath+"animate_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sonic X Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5038+"/", folder=True,
		icon=mediapath+"animate_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]W.I.T.C.H. Animated Series S1[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5024+"/", folder=True,
		icon=mediapath+"animate_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]W.I.T.C.H. Animated Series S2[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5025+"/", folder=True,
		icon=mediapath+"animate_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cartoon Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5062+"/", folder=True,
		icon=mediapath+"animate_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Booba Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5069+"/", folder=True,
		icon=mediapath+"animate_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Micky Mouse 1928-1934[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5071+"/", folder=True,
		icon=mediapath+"animate_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dinosaur Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5072+"/", folder=True,
		icon=mediapath+"animate_cartoons.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'animate.png', fanart)
	
@route(mode='animate_action')
def Animate_Action():

	add_link_info('[B][COLORorange]== Ani-mate ==[/COLOR][/B]', mediapath+'animate.png', fanart)

	Add_Dir( 
		name="[COLOR white][B]She-Ra Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5382+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]He Man Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_5383+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Bravestar Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5384+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]The Legend Of Zorro[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5387+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Legend of Tarzan Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5053+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Gargoyles Animated Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5027+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Highlander Animated Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5020+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dungeons & Dragons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5029+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]DC Super Hero Girls[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5096+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Justice League Animated[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5012+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Legend of Zorro Animated [/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5030+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]X-men Animated Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5040+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Scifi: Space Angel[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5084+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sci-fi: Astro Boy[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5086+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ivanhoe Kings Knight[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5045+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Godzilla Animated Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5033+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kong Animated Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5056+"/", folder=True,
		icon=mediapath+"animate_action.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'animate.png', fanart)

@route(mode='animate_scifi')
def Animate_Scifi():

	add_link_info('[B][COLORorange]== Ani-mate ==[/COLOR][/B]', mediapath+'animate.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Guardians Of The Galaxy[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5378+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Star Trek Animated[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5350+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Spaceballs Animated[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5351+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Voltron Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_5352+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Atomicron Episodes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5353+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mega Man Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5021+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Chaotic Animated Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5043+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Heavy Gear Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5044+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ReBoot Animated Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5046+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Buzz Lightyear Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5035+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sci-fi: Martin Mystery[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5083+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sci-fi: Godzilla[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5085+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Scifi: Space Angel[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5084+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sci-fi: Astro Boy[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5086+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sci-fi: More Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5087+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sci-fi Shorts & CGI[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5081+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sci-fi Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5080+"/", folder=True,
		icon=mediapath+"animate_scifi.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'animate.png', fanart)

@route(mode='animate_movies')
def Animate_Movies():

	add_link_info('[B][COLORorange]== Ani-mate ==[/COLOR][/B]', mediapath+'animate.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Anime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5063+"/", folder=True,
		icon=mediapath+"animate_movies.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Cartoon Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5064+"/", folder=True,
		icon=mediapath+"animate_movies.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cartoon & Anime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5065+"/", folder=True,
		icon=mediapath+"animate_movies.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]More Anime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5066+"/", folder=True,
		icon=mediapath+"animate_movies.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Christmas Cartoon Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5077+"/", folder=True,
		icon=mediapath+"animate_movies.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Old Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5078+"/", folder=True,
		icon=mediapath+"animate_movies.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5079+"/", folder=True,
		icon=mediapath+"animate_movies.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime Films N Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5468+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]90s Anime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5465+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'animate.png', fanart)

@route(mode='animate_anime')
def Animate_Anime():

	add_link_info('[B][COLORorange]== Ani-mate ==[/COLOR][/B]', mediapath+'animate.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Anime Theater Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5479+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Aquarion Dub Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_5480+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dragon Ball Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5481+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5302+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies: Anime[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5303+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Action Anime Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5482+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime For Life Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5484+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime Sunday Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_5485+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Tahanea Cynthia Go Anime[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5486+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Boku wa Tomodachi Ga Sukunai[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5487+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Go To Anime 2.0 Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5488+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Chip Anime Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_5489+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Moon Tam Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5491+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: Full Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5462+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: Assassin Classroom[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5463+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime Movie Set[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5464+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: My Hero Academia[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5466+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: Devil Revived[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5467+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime Films N Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5468+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]90s Anime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5465+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Jungle Book English Dub[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5469+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: Hikaru no Go[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5470+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Super Robot Monkey Team[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5471+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: English Dubbed[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5472+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]English Dubbed Anime[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5473+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Legend Of Zorro[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5474+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Naruto[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5500+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Aquarion Logos[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5499+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hunter X Hunter[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5498+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Izetta The Last Witch[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5497+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pokemon Generations[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5496+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Puzzle N Dragon X[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5495+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sky Wizards Academy[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5494+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Overlord[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5493+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Yo-Kai Watch[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5492+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: 80s And 90s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5002+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Anime: Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5003+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Anime: Old School[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5004+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: Espanol[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5005+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Anime: Monster[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5006+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]More Espanol[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5007+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: Classic[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5008+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime Shorts N Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5300+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime Movies English[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5301+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies & Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5010+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]More Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5013+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Anime: Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5014+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Anime: Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5011+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: Episodes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5015+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: Movies N Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5023+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: Violent[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5001+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dubbed Movies N OVA[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5067+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime 80s, 90s, 2k[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5068+"/", folder=True,
		icon=mediapath+"animate_anime.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'animate.png', fanart)

@route(mode='animate_toddlers')
def Animate_Toddlers():

	add_link_info('[B][COLORorange]== ANI-MATE ==[/COLOR][/B]', mediapath+'animate.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Busy Beavers[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_5270+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Official Pat & Stan[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5271+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Tractor Tom[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5272+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]HUMF Official[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5273+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Max & Ruby[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5274+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hoopla Kids Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5275+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cartoon Candy[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5276+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]TuTiTu TV[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5278+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Yo Gabba Gabba[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5279+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Little Baby Bum[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5280+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Little Bear[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_5281+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Oh My Genius[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5294+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bananas In Pyjamas[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5283+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fifi & The Flowertots[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5284+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Postman Pat[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5285+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Olivia The Pig[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5286+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Little Charlie Bear[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5287+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]VeggieTales Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5288+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Strawberry Shortcake[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5289+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Noddy In Toyland[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5290+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ben & Holly Little Kingdom[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5291+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Kids Club[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5292+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Giggle Bellies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5293+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Fluffy Jet Toys[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5295+"/", folder=True,
		icon=mediapath+"animate_toddlers.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'animate.png', fanart)

#xbmcplugin.endOfDirectory(plugin_handle)
