"""
    Free Live TV Add-on
    Developed by mhancoc7

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import urllib, urllib2, sys, re, os, string, random, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

dlg = xbmcgui.Dialog()
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
plugin_path = xbmcaddon.Addon(id=addon_id).getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(plugin_path, 'icon.png'))
fanart = xbmc.translatePath(os.path.join(plugin_path, 'fanart.jpg'))

YOUTUBE_CHANNEL_ID_1070 = "" #
YOUTUBE_CHANNEL_ID_1071 = "" #
YOUTUBE_CHANNEL_ID_1072 = "" #
YOUTUBE_CHANNEL_ID_1073 = "" #
YOUTUBE_CHANNEL_ID_1074 = "" #
YOUTUBE_CHANNEL_ID_1075 = "Dj7BHCpX4Ho&t=1299s" #Def Leppard Story
YOUTUBE_CHANNEL_ID_1076 = "3p4MZJsexEs" #Bohemian Rhapsody
YOUTUBE_CHANNEL_ID_1077 = "tgbNymZ7vqY" #Muppets Bohemian Rhapsody
YOUTUBE_CHANNEL_ID_1078 = "UX1cdPqW5M8" #shuffle_bass_boost
YOUTUBE_CHANNEL_ID_1079 = "lF-PO47lr84" #dance_party_dj
YOUTUBE_CHANNEL_ID_1080 = "taD9hqwCb1o" #good_life_radio
YOUTUBE_CHANNEL_ID_1081 = "7ZKX2fPHKNo" #fallout_radio
YOUTUBE_CHANNEL_ID_1082 = "dGfdGZ8cH-o" #doom_metal
YOUTUBE_CHANNEL_ID_1083 = "Wl2mrlhE5Ww" #tropical_house
YOUTUBE_CHANNEL_ID_1084 = "HS7ulzLL034" #nature_tv
YOUTUBE_CHANNEL_ID_1085 = "GVC5adzPpiE" #gaming_radio
YOUTUBE_CHANNEL_ID_1086 = "J20u_NrRI-s" #Sad_boys_radio
YOUTUBE_CHANNEL_ID_1087 = "FCL3VN780aI" #club_dj
YOUTUBE_CHANNEL_ID_1088 = "yMcMg6FaFhE" #dj_club_music
YOUTUBE_CHANNEL_ID_1089 = "eosLoIMzW7E" #best_gaming_mix
YOUTUBE_CHANNEL_ID_1090 = "wvMs5Wz54bw" #best_shuffle_dance
YOUTUBE_CHANNEL_ID_1091 = "Xmu8nWKykUw" #popular_song_remix
YOUTUBE_CHANNEL_ID_1092 = "fqG-cT-LmcY" #ultimate_game_music
YOUTUBE_CHANNEL_ID_1093 = "KvRVky0r7YM" #progressive_house_focus
YOUTUBE_CHANNEL_ID_1094 = "5u15qvfxLNM" #uplifting_trance
YOUTUBE_CHANNEL_ID_1095 = "Bszm6XDdygY" #best_electro_house
YOUTUBE_CHANNEL_ID_1096 = "xkETGNqmpaA" #epic_music
YOUTUBE_CHANNEL_ID_1097 = "" #
YOUTUBE_CHANNEL_ID_1098 = "oZzQC8NVTeM" #ncs_electronic
YOUTUBE_CHANNEL_ID_1099 = "gmv54pfxk0Q" #chill_music
YOUTUBE_CHANNEL_ID_1100 = "7EuRBI1kH80" #relaxing_piano
YOUTUBE_CHANNEL_ID_1101 = "3v8oEGE6QxE" #house_electro
YOUTUBE_CHANNEL_ID_1102 = "OLomWmp9fLk" #lil_peep_radio
YOUTUBE_CHANNEL_ID_1103 = "io85zAxiA0E" #lounge_jazz_radio
YOUTUBE_CHANNEL_ID_1104 = "7nZBrHfeWEA" #spring_jazz
YOUTUBE_CHANNEL_ID_1105 = "KC3sfZBmn-o" #beats_to_study
YOUTUBE_CHANNEL_ID_1106 = "L1gAOua_3f4" #rap_radio
YOUTUBE_CHANNEL_ID_1107 = "yv-xvmjpGM4" #best_hiphop
YOUTUBE_CHANNEL_ID_1108 = "t3p8bmei7Dc" #electro_swing
YOUTUBE_CHANNEL_ID_1109 = "IPTrlTv0GL8" #r_b_chill
YOUTUBE_CHANNEL_ID_1110 = "mRTu0V8wWYc" #psychedelic_techno
YOUTUBE_CHANNEL_ID_1111 = "Ppnogeufi-4" #trap_music_radio
YOUTUBE_CHANNEL_ID_1112 = "d8Oc90QevaI" #progressive_house
YOUTUBE_CHANNEL_ID_1113 = "g-pqmuYPHPs" #jazz_hiphop
YOUTUBE_CHANNEL_ID_1114 = "C6_ql03n-vQ" #vocal_trance
YOUTUBE_CHANNEL_ID_1115 = "dDlcWA3Rac8" #psychedelic_trance
YOUTUBE_CHANNEL_ID_1116 = "2atQnvunGCo" #lofi_hiphop_mix
YOUTUBE_CHANNEL_ID_1117 = "Vyumt7LZL-8" #nightcore_radio
YOUTUBE_CHANNEL_ID_1118 = "4-paKHO_YfQ" #rnb_soul
YOUTUBE_CHANNEL_ID_1119 = "fr_FZ4_qW9c" #deep_sleep
YOUTUBE_CHANNEL_ID_1120 = "g5yDFbpee8E" #na_flute_water
YOUTUBE_CHANNEL_ID_1121 = "NAzwWDX1PMU" #hiphop_beats_chill
YOUTUBE_CHANNEL_ID_1122 = "X0vK_57vQ7s" #coral_reef
YOUTUBE_CHANNEL_ID_1123 = "hEP2UiFqqMw" #bestof_ncs
YOUTUBE_CHANNEL_ID_1124 = "o4MG9PiJucY" #gentle_night_rain
YOUTUBE_CHANNEL_ID_1125 = "PtYe4GwOlNs" #deep_house_radio
YOUTUBE_CHANNEL_ID_1126 = "3SakCDX_fGA" #relaxing_jazz
YOUTUBE_CHANNEL_ID_1127 = "OlP_FYgSEtM" #fenomen_pop
YOUTUBE_CHANNEL_ID_1128 = "Fm1Z80ltba0" #relaxing_sleep_music
YOUTUBE_CHANNEL_ID_1129 = "I6sj-2GRXVQ" #jazz_bossa_nova
YOUTUBE_CHANNEL_ID_1130 = "IVYOZfWF1cY" #morning_jazz
YOUTUBE_CHANNEL_ID_1131 = "oeR_srcejrQ" #video_game_music
YOUTUBE_CHANNEL_ID_1132 = "kdtkyYid7YA" #best_deep_house
YOUTUBE_CHANNEL_ID_1133 = "tNkZsRW7h2c" #space_ambient
YOUTUBE_CHANNEL_ID_1134 = "5qky3L2Q6G4" #deep_house_relax
YOUTUBE_CHANNEL_ID_1135 = "IvaB9hBBcOA" #sleeping_music
YOUTUBE_CHANNEL_ID_1136 = "j7kAlEPTql4" #relaxing_deep_sleep
YOUTUBE_CHANNEL_ID_1137 = "fEvM-OUbaKs" #chillout_lounge_jazz
YOUTUBE_CHANNEL_ID_1138 = "05689ErDUdM" #rap_radio_music
YOUTUBE_CHANNEL_ID_1139 = "4Tx7_s696sI" #beats_to_party
YOUTUBE_CHANNEL_ID_1140 = "" #
YOUTUBE_CHANNEL_ID_1141 = "" #
YOUTUBE_CHANNEL_ID_1142 = "" #
YOUTUBE_CHANNEL_ID_1143 = "" #
YOUTUBE_CHANNEL_ID_1144 = "" #
YOUTUBE_CHANNEL_ID_1145 = "" #
YOUTUBE_CHANNEL_ID_1146 = "" #
YOUTUBE_CHANNEL_ID_1147 = "" #
YOUTUBE_CHANNEL_ID_1148 = "" #
YOUTUBE_CHANNEL_ID_1149 = "" #
YOUTUBE_CHANNEL_ID_1150 = "" #
YOUTUBE_CHANNEL_ID_1151 = "" #
YOUTUBE_CHANNEL_ID_1152 = "" #
YOUTUBE_CHANNEL_ID_1153 = "" #
YOUTUBE_CHANNEL_ID_1154 = "" #
YOUTUBE_CHANNEL_ID_1155 = "" #
YOUTUBE_CHANNEL_ID_1156 = "" #
YOUTUBE_CHANNEL_ID_1157 = "" #
YOUTUBE_CHANNEL_ID_1158 = "" #
YOUTUBE_CHANNEL_ID_1159 = "" #
YOUTUBE_CHANNEL_ID_1160 = "" #
YOUTUBE_CHANNEL_ID_1161 = "" #
YOUTUBE_CHANNEL_ID_1162 = "" #
YOUTUBE_CHANNEL_ID_1163 = "" #
YOUTUBE_CHANNEL_ID_1164 = "" #
YOUTUBE_CHANNEL_ID_1165 = "" #
YOUTUBE_CHANNEL_ID_1166 = "" #
YOUTUBE_CHANNEL_ID_1167 = "" #
YOUTUBE_CHANNEL_ID_1168 = "" #
YOUTUBE_CHANNEL_ID_1169 = "" #
YOUTUBE_CHANNEL_ID_1170 = "" #
YOUTUBE_CHANNEL_ID_1171 = "" #

YOUTUBE_CHANNEL_ID_1200 = "Dj7BHCpX4Ho" #Def Leppard Story
YOUTUBE_CHANNEL_ID_1201 = "3p4MZJsexEs" #Bohemian Rhapsody: Queen
YOUTUBE_CHANNEL_ID_1202 = "tgbNymZ7vqY" #Muppets Bohemian Rhapsody
YOUTUBE_CHANNEL_ID_1203 = "uRBNhZUujVY" #Foreigner Story Doc
YOUTUBE_CHANNEL_ID_1204 = "SLY7yI1xV-M" #Happy Day: Sister Act
YOUTUBE_CHANNEL_ID_1205 = "lhLVTnzqJj4" #Gun n Roses: Band That Time Forgot Doc
YOUTUBE_CHANNEL_ID_1206 = "pmmN7_gH9vc" #Bon Jovi When We Were Beautiful Doc
YOUTUBE_CHANNEL_ID_1207 = "EPOIS5taqA8" #Betty Davis Eyes
YOUTUBE_CHANNEL_ID_1208 = "o-6v4H4BtWI" #Hold Your Head Up: Argent
YOUTUBE_CHANNEL_ID_1209 = "nOcoGotfabc" #Deep Purple The History Doc
YOUTUBE_CHANNEL_ID_1210 = "5qq_qnLHf74" #Blues Story Doc
YOUTUBE_CHANNEL_ID_1211 = "yhOeTZIyZqI" #Grand Funk Railroad Doc
YOUTUBE_CHANNEL_ID_1212 = "jyzL6D-5znY" #Girl Groups Doc
YOUTUBE_CHANNEL_ID_1213 = "dWwEi4SNf1M" #Wanna Know What Love Is: Foreigner
YOUTUBE_CHANNEL_ID_1214 = "ekomXrzOF3A" #Livin On A Prayer: Bon Jovi
YOUTUBE_CHANNEL_ID_1215 = "-10Gy6xc-WM" #Can't Fight This Feeling: Reo Speedwagon
YOUTUBE_CHANNEL_ID_1216 = "rtopccRfyUU" #Alone: Heart
YOUTUBE_CHANNEL_ID_1217 = "6DeDzsCGbsQ" #With Or Without You: U2
YOUTUBE_CHANNEL_ID_1218 = "LTseTg48568" #Comfortably Numb: Pink Floyd
YOUTUBE_CHANNEL_ID_1219 = "HyWajWueH2w" #Final Countdown: Europe
YOUTUBE_CHANNEL_ID_1220 = "zthQPe41w24" #Dream On: Aerosmith
YOUTUBE_CHANNEL_ID_1221 = "7tvhmq6_IKs" #Keep On Lovin You: Reo Speedwagon
YOUTUBE_CHANNEL_ID_1222 = "JcqhvPNiJzo" #Money For Nothing: Dire Straits
YOUTUBE_CHANNEL_ID_1223 = "VmAeuJ_gW1Q" #Highway Star: Deep Purple
YOUTUBE_CHANNEL_ID_1224 = "T-dRPKC_7-Y" #Dont You (Forget About Me): Simple Minds
YOUTUBE_CHANNEL_ID_1225 = "sKW9kWAIdI0" #Since You Been Gone: Rainbow
YOUTUBE_CHANNEL_ID_1226 = "5HSP2JnAvb0" #Hysteria: Def Leppard
YOUTUBE_CHANNEL_ID_1227 = "9o4kvBI5A98" #Dont Want To Miss A Thing: Aerosmith
YOUTUBE_CHANNEL_ID_1228 = "C9U5HGYe0Mk" #Home Sweet Home: Motley Crue
YOUTUBE_CHANNEL_ID_1229 = "j-eVamWhUBw" #Separate Ways: Journey
YOUTUBE_CHANNEL_ID_1230 = "Ozmoe6hSBzo" #Don't Stop Believin: (Dan Lucas) The Voice
YOUTUBE_CHANNEL_ID_1231 = "RBq_THTWNM4" #Crazy On You: Heart
YOUTUBE_CHANNEL_ID_1232 = "ivPEKaBHjYA" #Try (Truth About Love): Pink
YOUTUBE_CHANNEL_ID_1233 = "rqOwtJqaxfw" #Say You Will: Foreigner
YOUTUBE_CHANNEL_ID_1234 = "pxAveEQOoNQ" #You Give Love A Bad Name: Bon Jovi
YOUTUBE_CHANNEL_ID_1235 = "nxiOBhaGWMo" #Alone: (Dan Lucas) The Voice
YOUTUBE_CHANNEL_ID_1236 = "9oG8faoL-Zk" #Whiter Shade Of Pale: Geff Harrison The Voice
YOUTUBE_CHANNEL_ID_1237 = "HzTlB-TjAzM" #Thrill Is Gone: BB King
YOUTUBE_CHANNEL_ID_1238 = "treNBRm1Ruc" #Smoke On The Water: The Voice
YOUTUBE_CHANNEL_ID_1239 = "QTxrwYzl6f8" #Still Loving You: The Voice
YOUTUBE_CHANNEL_ID_1240 = "H6oGuXenlNo" #Without You: Mariah Carey
YOUTUBE_CHANNEL_ID_1241 = "uVx9CaavEPA" #Alone: Floortje Smit The Voice
YOUTUBE_CHANNEL_ID_1242 = "Mqfwbf3X8SA" #Simple Man: Lynyrd Skynyrd
YOUTUBE_CHANNEL_ID_1243 = "XKRI8CcpC9M" #I Will Always Love You: Whitney Houston
YOUTUBE_CHANNEL_ID_1244 = "z2WDDxFXJ9s" #Feels Like The First Time: Foreigner
YOUTUBE_CHANNEL_ID_1245 = "4XvI__yHNow" #Dust In The Wind: Kansas
YOUTUBE_CHANNEL_ID_1246 = "oEGL7j2LN84" #Time: Pink Floyd
YOUTUBE_CHANNEL_ID_1247 = "TvnYmWpD_T8" #Purple Rain: Prince
YOUTUBE_CHANNEL_ID_1248 = "HlEuo9aR7Qo" #Sweet Child O Mine: Guns N Roses
YOUTUBE_CHANNEL_ID_1249 = "yYkL5igsG4k" #Hotel California: Eagles
YOUTUBE_CHANNEL_ID_1250 = "APznhptgsb8" #What About Love: Heart
YOUTUBE_CHANNEL_ID_1251 = "nZt49yGvdeY" #Go Your Own Way: Fleetwood Mac
YOUTUBE_CHANNEL_ID_1252 = "oL1JyDTq3Qc" #Little Help From My Friends: Joe Cocker
YOUTUBE_CHANNEL_ID_1253 = "dlc6xCPx60U" #Cant You See: Marshall Tucker Band
YOUTUBE_CHANNEL_ID_1254 = "qSIS0o7vtPE" #How Many More Times: Led Zeppelin
YOUTUBE_CHANNEL_ID_1255 = "jZ6DBG54c3Y" #Bohemian Rhaposy: The Voice
YOUTUBE_CHANNEL_ID_1256 = "2HuiH-0R6a0" #Dont Look Back: Boston
YOUTUBE_CHANNEL_ID_1257 = "uR4if4ble1A" #Lady: Styx
YOUTUBE_CHANNEL_ID_1258 = "_fzJGxpcenc" #Best Of Times: Styx
YOUTUBE_CHANNEL_ID_1259 = "mAVPYq8fc3k" #Pitch Perfect 1: Finale
YOUTUBE_CHANNEL_ID_1260 = "6RsgmjeAQ14" #Pitch Perfect 2: Finale
YOUTUBE_CHANNEL_ID_1261 = "foV6LGohzBI" #Pitch Perfect 3: Freedom
YOUTUBE_CHANNEL_ID_1262 = "yBg5cnoNyAE" #Tumblin Dice: Linda Ronstadt
YOUTUBE_CHANNEL_ID_1263 = "oP7kExN8LFA" #School Of Rock
YOUTUBE_CHANNEL_ID_1264 = "NqqyWI9LDeY" #Once Bitten: 3 Speed
YOUTUBE_CHANNEL_ID_1265 = "ar3wkC8U6LA" #Staying Alive: Airplane
YOUTUBE_CHANNEL_ID_1266 = "DtVBCG6ThDk" #Rocket Man: Elton John
YOUTUBE_CHANNEL_ID_1267 = "XujEruAWcR4" #Tiny Dancer: Elton John
YOUTUBE_CHANNEL_ID_1268 = "kBYHwH1Vb-c" #The Chain: Fleetwood Mac
YOUTUBE_CHANNEL_ID_1269 = "-FyjEnoIgTM" #Verace On The Floor: Bruno Mars
YOUTUBE_CHANNEL_ID_1270 = "Ob7vObnFUJc" #Love On Top: Beyonce
YOUTUBE_CHANNEL_ID_1271 = "p1JPKLa-Ofc" #Drunk In Love: Explicit Beyonce
YOUTUBE_CHANNEL_ID_1272 = "ViwtNLUqkMY" #Crazy In Love: Beyonce
YOUTUBE_CHANNEL_ID_1273 = "VBmMU_iwe6U" #Run The World: Beyonce
YOUTUBE_CHANNEL_ID_1274 = "0RyInjfgNc4" #Love On The Brain: Rhianna
YOUTUBE_CHANNEL_ID_1275 = "lWA2pjMjpBs" #Diamonds: Rhianna
YOUTUBE_CHANNEL_ID_1276 = "EBt_88nxG4c" #Beautiful Trauma: Pink
YOUTUBE_CHANNEL_ID_1277 = "eocCPDxKq1o" #Please Dont Leave Me: Pink
YOUTUBE_CHANNEL_ID_1278 = "_Yhyp-_hX2s" #Lose Yourself:Eminem
YOUTUBE_CHANNEL_ID_1279 = "OUeaAOIAbXs" #In The Club: 50 Cent
YOUTUBE_CHANNEL_ID_1280 = "3tOKYFR4Rzg" #Hells Bells: AC/DC
YOUTUBE_CHANNEL_ID_1281 = "zakKvbIQ28o" #You Shook Me All Night Long: AC/DC
YOUTUBE_CHANNEL_ID_1282 = "gEPmA3USJdI" #Highway To Hell: AC/DC
YOUTUBE_CHANNEL_ID_1283 = "Qccnc693ETw" #Shadows Of The Night: Pat Benatar
YOUTUBE_CHANNEL_ID_1284 = "h7XhpOrrkAM" #Best Of The Worst: Charm City Devils
YOUTUBE_CHANNEL_ID_1285 = "gZxP3bMn0as" #The Man Ill Never Be: Boston
YOUTUBE_CHANNEL_ID_1286 = "d5PqVeex4QU" #Dreams: Van Halen
YOUTUBE_CHANNEL_ID_1287 = "kIPWrpD1OWc" #When It's Love: Van Halen
YOUTUBE_CHANNEL_ID_1288 = "_kVYAkK0bkY" #Photograph: Def Leppard
YOUTUBE_CHANNEL_ID_1289 = "X6x0NWRh7WQ" #Best Of Both Worlds: Van Halen
YOUTUBE_CHANNEL_ID_1290 = "wB7cYGokbx0" #Why Can't This Be Love: Van Halen
YOUTUBE_CHANNEL_ID_1291 = "x5_yOzK8T5Q" #Hunger City: Cherry Bombs
YOUTUBE_CHANNEL_ID_1292 = "WbsDPbr8qoM" #Second Chance: Shinedown
YOUTUBE_CHANNEL_ID_1293 = "MLeIyy2ipps" #45: Shinedown
YOUTUBE_CHANNEL_ID_1294 = "TTA2buWlNyM" #Remember When: Alan Jackson
YOUTUBE_CHANNEL_ID_1295 = "VGWZrO5U9ek" #Craving You: Thomas Rhett
YOUTUBE_CHANNEL_ID_1296 = "4zAThXFOy2c" #Tennessee Whiskey Chris Stapleton
YOUTUBE_CHANNEL_ID_1297 = "Y3EpArAtGJQ" #Alone With You: Jake Owen
YOUTUBE_CHANNEL_ID_1298 = "7HX4SfnVlP4" #Country Girl: Luke Bryan
YOUTUBE_CHANNEL_ID_1299 = "7iDwzIB6Pn0" #Where I Come From: Montgomery Gentry
YOUTUBE_CHANNEL_ID_1300 = "LxQBMxvGJVA" #Whiskey River: Willie Nelson

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def get_setting(setting):
    return addon.getSetting(setting)

def set_setting(setting, string):
    return addon.setSetting(setting, string)

def get_string(string_id):
    return addon.getLocalizedString(string_id)

def addLink(name, url, zmode, iconimage, fanart):
        liz=xbmcgui.ListItem(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={"Title": name})		
        liz.setProperty('fanart_image', fanart)
        liz.setProperty('IsPlayable', 'true')
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&zmode="+str(zmode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)		
        return ok		

def add_link_info(name, iconimage, fanart):
	u = sys.argv[0] + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'false') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz) 

def addDirMain(name,url,zmode,iconimage,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&zmode="+str(zmode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def regex_get_all(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r

