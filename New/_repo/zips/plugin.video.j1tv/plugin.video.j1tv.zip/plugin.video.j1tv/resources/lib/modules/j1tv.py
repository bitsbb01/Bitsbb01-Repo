# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

from resources.lib.modules.channels import *
from resources.lib.modules.common import *

import urllib

params = get_params()
mode = None

debug        = Addon_Setting(setting='debug')       
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.j1tv')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'
path   = xbmcaddon.Addon().getAddonInfo('path').decode("utf-8")

BASE  = "plugin://plugin.video.youtube/playlist/"
cBASE = "plugin://plugin.video.youtube/channel/"
uBASE = "plugin://plugin.video.youtube/user/"

YOUTUBE_CHANNEL_ID_1 = "PLqrLEr7tAISqbmrtMKxKww_X7snpV9Raj"
YOUTUBE_CHANNEL_ID_2 = "PLqrLEr7tAISodaD8uxSrBy4prXDAK3qUG"
YOUTUBE_CHANNEL_ID_3 = "PLqrLEr7tAISo2t4A3tCb0G0uU5mJtvPd7" 
YOUTUBE_CHANNEL_ID_4 = "PLqrLEr7tAISrN3h28-yVBvNImTMfXfmBL" #tv
YOUTUBE_CHANNEL_ID_5 = "PLqrLEr7tAISpmpzgx9DGGdTV21N8oM9WA" #cartoon
YOUTUBE_CHANNEL_ID_6 = "PLqrLEr7tAISrvCOKUw0HIcuRWx-mWlHM5" #soaps
YOUTUBE_CHANNEL_ID_7 = "PLqrLEr7tAISogp_I2qKcG_U024UQRlIqa" #music
YOUTUBE_CHANNEL_ID_8 = "PLqrLEr7tAISqdL2KEXF3pa991f8YcfmnU" #music
YOUTUBE_CHANNEL_ID_9 = "PLqrLEr7tAISr_qX8637ibD4q3fFdNa0Ux" #music
YOUTUBE_CHANNEL_ID_10 = "PLqrLEr7tAISqtGZ-SKqypMXOl6VQrbigT" #music
YOUTUBE_CHANNEL_ID_11 = "PLqrLEr7tAISpB98eG-DTsKcB65anYHOkC" #music
YOUTUBE_CHANNEL_ID_12 = "PLmGKOvYxah51aZsVO16ZunI_-5k6f55Nz" #Classic TV & Movie Drama
YOUTUBE_CHANNEL_ID_13 = "PLX9_I-EOJPdGFAVAwQj4J7hg8q3m4AW5x" #Classic War Movies
YOUTUBE_CHANNEL_ID_14 = "PL1yPx49iVsPblR8taQR5o5b0FcCJoToJv" #Hollywood Classics
YOUTUBE_CHANNEL_ID_15 = "PLhNKDzMMjN8w9AloWcE7Z6ulQibM9A7Tm" #classic Mystery Movies
YOUTUBE_CHANNEL_ID_16 = "PLajqNV0-qkKdGiFNzmK5BA16MujBJ0bvv" #Classic Film Noir/Crime
YOUTUBE_CHANNEL_ID_17 = "PLyJXkvwe3Tj7qMsJdI79Wzg2-MPNhNEqn" #Classic Comedy Movies
YOUTUBE_CHANNEL_ID_18 = "PLSeZ6qt37vqyLGXbHeS4Ko4tfZ4qsT1ZN" #Classic Horror ***
YOUTUBE_CHANNEL_ID_19 = "PLzcEZ5FfjhGL0c4Wh8XSEF0vasxeGTWeq" #classic horror some deletes
YOUTUBE_CHANNEL_ID_20 = "PLprCz0PxKdOdl8OBeNAFyweZHztTb_XAf" #Classic Movie and shows
YOUTUBE_CHANNEL_ID_21 = "PLprCz0PxKdOdl8OBeNAFyweZHztTb_XAf" #Classic Horror
YOUTUBE_CHANNEL_ID_22 = "PLqrLEr7tAISqiV5cqxhRvEMgR9Y4Q-apy" #comedy
YOUTUBE_CHANNEL_ID_23 = "PLRk8KBuNEEmUWIBjIXp_7t4M1iMhuZuJB" #Classic Scifi
YOUTUBE_CHANNEL_ID_24 = "PLi4lYGGXHIkODAkKFIXtLZpAjMptl-xSl" #docs
YOUTUBE_CHANNEL_ID_25 = "PLLY_ynX8paGH3D_04pyqibRdEyZxAELf_" #26-horror
YOUTUBE_CHANNEL_ID_26 = "PLRH1M0THHElrjY2u17Db1yxEko1XJdRmW" #Christian
YOUTUBE_CHANNEL_ID_27 = "PLeSK8oZavDZksbefTHmqNde2-mTfudNFQ" #scifi
YOUTUBE_CHANNEL_ID_28 = "PLU-EAetueZUSl2zwzjcefqC2zUaFxVrc1" #horror 267
YOUTUBE_CHANNEL_ID_29 = "PL5AiS_uLSTnUFu0rr8Yw7RVYu-WlZ7wVU" #scifi test for deletes
YOUTUBE_CHANNEL_ID_30 = "PLMos4PviivCwyf2CZfPR8r9xR3Gegwwph" #horror scifi mix test deletes
YOUTUBE_CHANNEL_ID_31 = "PLsrovtzkHBQWc6pW5PbLKj5ejeidJGMD_" #cheesy sci-fi
YOUTUBE_CHANNEL_ID_32 = "" #
YOUTUBE_CHANNEL_ID_33 = "PLeagipoZmyfnIxkk9qKN-ewkuDeI-JP0i" #Great Classic Movies
YOUTUBE_CHANNEL_ID_34 = "PLajqNV0-qkKdfaARIBraH6VtFPVMXqaZd" #classic grindhouse movies
YOUTUBE_CHANNEL_ID_35 = "PLKUihZ3LvFaOyX9b4zHwHTIORyAvEe5cv" #Old Fun Horror Movies
YOUTUBE_CHANNEL_ID_36 = "" #
YOUTUBE_CHANNEL_ID_37 = "PLgTLZSbwbEZycajt3dETO-OWMGMlbDusz" #Comedy movies
YOUTUBE_CHANNEL_ID_38 = "PL8Nn95jd6kYWh5cF2pSMtbGCOlkrBccrZ" #Classic action movies
YOUTUBE_CHANNEL_ID_39 = "PLkzvgsq3ySHBduUI5DSAwpJylNKkGYjqg" #Ghoulish Grin Films
YOUTUBE_CHANNEL_ID_40 = "PLKrpm9lxqdtyR8z1jz0M3ps_sgU9kJxfr" #Anime delete test
YOUTUBE_CHANNEL_ID_41 = "PLsZQnDqnebk6N7EchSMbmLXkGTFguhUba" #Popcorn Flix Drama
YOUTUBE_CHANNEL_ID_42 = "PLgTLZSbwbEZyhiPgeiO7pdwZQoeMl8dDD" #Kisstube Westerns
YOUTUBE_CHANNEL_ID_43 = "PLVuKsHxUDogz6EVwLDQvGxEqHzPNRYHE1" #Hallmark romance delete test
YOUTUBE_CHANNEL_ID_44 = "PL9lDxmOVB4z5WAuY3U6vz6ugrJdrAcEe2" #Crime Mystery
YOUTUBE_CHANNEL_ID_45 = "PL79F09C65ABCEF855" #Movie mix
YOUTUBE_CHANNEL_ID_46 = "PL66gYQOTwdMtEmP_YN4aQiSDBDMqxmtHj" #More Sports docs
YOUTUBE_CHANNEL_ID_47 = "" #
YOUTUBE_CHANNEL_ID_48 = "PL9lDxmOVB4z5WAuY3U6vz6ugrJdrAcEe2" #Mystery, Crime, Detectives
YOUTUBE_CHANNEL_ID_49 = "PL8F18E48510403329" #Cellardoor Old Movie Mix
YOUTUBE_CHANNEL_ID_50 = "PLKLyNt670pENW70Io1rHsWWyBtetmnDxo" #Lifetime Movies
YOUTUBE_CHANNEL_ID_51 = "PLv7MWTL-Arz429W0pO2C3v5WX-xr2T8KJ" #Monster Movies
YOUTUBE_CHANNEL_ID_52 = "PL74839542356C41F1" #Hammer Horror & British Horror
YOUTUBE_CHANNEL_ID_53 = "PLyJXkvwe3Tj7qMsJdI79Wzg2-MPNhNEqn" #Romance & Comedy
YOUTUBE_CHANNEL_ID_54 = "PLDySQNnzfMCqoBxquMEhCOi0GUEB1RbCf" #Maverick Movie Mix
YOUTUBE_CHANNEL_ID_55 = "PLKnoifHxcT0b16B_2eR0l61igOsZHR7rp" #Rock Concerts
YOUTUBE_CHANNEL_ID_56 = "PLR8X0-qEtOCf8aeA-6bEBHNNwZv0GqvyZ" #All Genre Concerts
YOUTUBE_CHANNEL_ID_57 = "PLKnoifHxcT0ZnVgYQMBuuv5-Pkarydyyu" #Soul/Funk/R&B
YOUTUBE_CHANNEL_ID_58 = "PLHrguy3J2ka2NrIba_vzXMw6ZCOSeJagd" #Metal Rock
YOUTUBE_CHANNEL_ID_59 = "PLFCF55651BB105A0A" #Christian Music
YOUTUBE_CHANNEL_ID_60 = "PLdTy4tnpIn-PuUJaziWbheSLwnpdKrPF8" #Mix Genre Concerts
YOUTUBE_CHANNEL_ID_61 = "PLDVZNJR18KqCU-kRgqv-fhiPXZdg1XbBV" #History Channel Docs
YOUTUBE_CHANNEL_ID_62 = "PLxJhVCslYrSZO2vGm4QFkSUv5Z6ZS6pKW" #Mixed Docs
YOUTUBE_CHANNEL_ID_63 = "PL5o3ll3G4acxgDMSO7JXvDsosQ-UDPL6n" #Nature Docs
YOUTUBE_CHANNEL_ID_64 = "PLlHanBMNk-DKQzkktkFKGvJR_9gSRDhBr" #PBS Nova
YOUTUBE_CHANNEL_ID_65 = "PL_jFbqOSEqaLIYGS0Oz8jTlrB8PaHiwdp" #Animal Docs
YOUTUBE_CHANNEL_ID_66 = "PL9lDxmOVB4z4g2aeA9Em8lSK3TS-QBn0X" #True Crime
YOUTUBE_CHANNEL_ID_67 = "PL_FvdirKjxxv2ErAABDGJf23ah7kjvq4j" #Action Movies
YOUTUBE_CHANNEL_ID_68 = "PLgIpO1mP2xbOb22z3BRJHjOVAO6VgMi7R" #Action Car Movies
YOUTUBE_CHANNEL_ID_69 = "PL_FvdirKjxxta1fabzOXkBdpXmDYjf7cE" #Action Heroes
YOUTUBE_CHANNEL_ID_70 = "PL_FvdirKjxxs9PUud4-E7a_j5ezZ8yI_h" #Action Adventure
YOUTUBE_CHANNEL_ID_71 = "PLfS4i_GXOfPzestgSDJlG2PWwCs1TTLmZ" #LFL FULL Games
YOUTUBE_CHANNEL_ID_72 = "PL3XNTf2rB1vdiT4mdT63RULzfZ96T5YSw" #WWE Full Matches
YOUTUBE_CHANNEL_ID_73 = "PLv0QwOQCR8PDNq8DjYWz1lWhQUM7elS23" #Sports Movies
YOUTUBE_CHANNEL_ID_74 = "PLCkP5LViwv1hpdmDR0WzOcCvOzMmAerUL" #Wrestling Docs
YOUTUBE_CHANNEL_ID_75 = "PLNNR5FiyIxqbO93WhkgS8yed0iq68IHUQ" #UK Football Docs
YOUTUBE_CHANNEL_ID_76 = "PLf0oK3K9_SbEaPZqDBWxNq_YTIpDkXVwn" #Wrestling Docs
YOUTUBE_CHANNEL_ID_77 = "PLajqNV0-qkKdVtKsaiiZoOI4ATsJMi0p8" #Drama & War
YOUTUBE_CHANNEL_ID_78 = "PLGKblFQXqJaed-4W_rZ-lYFTEbH667hIo" #Drama
YOUTUBE_CHANNEL_ID_79 = "" #
YOUTUBE_CHANNEL_ID_80 = "PLDVZNJR18KqCU-kRgqv-fhiPXZdg1XbBV" #History Channel Docs
YOUTUBE_CHANNEL_ID_81 = "PLwyjca9cepxXmDlcN-DGsacoByThOdDls" #Mixed Docs
YOUTUBE_CHANNEL_ID_82 = "PLxJhVCslYrSZO2vGm4QFkSUv5Z6ZS6pKW" #Mixed Docs
YOUTUBE_CHANNEL_ID_83 = "PLB8MxfrLz2uocbT0hilg-9IsukX8wzfs4" #Mixed docs
YOUTUBE_CHANNEL_ID_84 = "PLvzGQITHlYYQWLzqQrv2b_2nRsCiz8bPm" #mixed docs
YOUTUBE_CHANNEL_ID_85 = "PLi4lYGGXHIkODAkKFIXtLZpAjMptl-xSl" #docs"
YOUTUBE_CHANNEL_ID_86 = "PLudVd7B9fN4q_YvZdbI_Z0mW_-Hh_LNrd" #Bio and music
YOUTUBE_CHANNEL_ID_87 = "" #
YOUTUBE_CHANNEL_ID_90 = "" #
YOUTUBE_CHANNEL_ID_91= "PLc9pOkgwR7R-6j_zWe9SQoZ0Ys9a572XR" #Mystery dos
YOUTUBE_CHANNEL_ID_92 = "PLJloLxwk_dPWKVNFTjajasPVIA-m1SP_r" #Mystery docs
YOUTUBE_CHANNEL_ID_93 = "PLcJSkbOhx_uiEaWF-zicqw3ri3J2QwY3i" #mystery docs
YOUTUBE_CHANNEL_ID_94 = "PLFpHQFR1whr9tedK5KP_igREFo8gwiE_6" #History's Mysteries
YOUTUBE_CHANNEL_ID_95 = "PLpf-o-gGms2AzvlUFaIulsrTZeuyL-6KD" #Mysterious Universe
YOUTUBE_CHANNEL_ID_96 = "PLDlNWvEmxHt642snFwTBs7M7Mzlziz8_C" #mystery docs ?
YOUTUBE_CHANNEL_ID_97 = "PLaNb7ob8C17ihtq7FwjUo9DOgqc1dVwT1" #mystery Bigfoot DELETES
YOUTUBE_CHANNEL_ID_98 = "PLaNb7ob8C17hjCLZl6hhVAY27MmBk_VmB" #mystery YETI
YOUTUBE_CHANNEL_ID_99 = "PL5E-2871Km0KplJRTpZn2NFeftnyRBR_A" #Mystery Weird or What
YOUTUBE_CHANNEL_ID_100 = "PLmTCZd4l3_-LXf-vBtkPhMq_B684sEqpH" #Mystery ghost ships and planes
YOUTUBE_CHANNEL_ID_101 = "PLzyVSegZOEI20AnMHpxYFS6yO5PHJr8gS" #mystery Stonehenge
YOUTUBE_CHANNEL_ID_102 = ""
YOUTUBE_CHANNEL_ID_103 = "PL8RSSkx8XVhu2xEhkL70-KLSHvmheYJ1i" #BBC crime docs
YOUTUBE_CHANNEL_ID_104 = "" #
YOUTUBE_CHANNEL_ID_105 = "PLtUeiZkcnkGybHUkD47XK7cta2rAOoNeI" #true crime docs
YOUTUBE_CHANNEL_ID_106 = "PL9lDxmOVB4z4g2aeA9Em8lSK3TS-QBn0X" #True Crime
YOUTUBE_CHANNEL_ID_107 = "PL8RSSkx8XVhuw6o5Ub9EdPUC0fghUMNsG" #Crime Docs
YOUTUBE_CHANNEL_ID_108 = "PLwz_DR_zjAVS6vgZ_80qSdndtyLh6cWNw" #Scandal
YOUTUBE_CHANNEL_ID_109 = ""
YOUTUBE_CHANNEL_ID_120 = "PLOvXkB5eFXm7lfggMnEO1TWzENy-0YhVP" #BBC mucic docs
YOUTUBE_CHANNEL_ID_121 = "" #
YOUTUBE_CHANNEL_ID_122 = "PL4upTjMb8fhYI5EY8bMSjafg9lC3vdUat" #Music Documentaries
YOUTUBE_CHANNEL_ID_123 = "PL3EFF4269AE644C28" #                PUNK music docs
YOUTUBE_CHANNEL_ID_124 = "PL84C83DBD88AD79E4" #                Hip Hop Docs
YOUTUBE_CHANNEL_ID_125 = "PL7jBOGah2-gzn2F7eTjGmsZN0fAPPc7wj" #Music Documentary
YOUTUBE_CHANNEL_ID_126 = "" #
YOUTUBE_CHANNEL_ID_127 = "" #
YOUTUBE_CHANNEL_ID_128 = "PLc1UsvXySVzhVkzxExNRBXZaQnZu20aEn" #Scary ghosts
YOUTUBE_CHANNEL_ID_129 = "PLpooHGBZ6yMmvXHUeQPeur_7vZ62NhmvD" #Scary docs
YOUTUBE_CHANNEL_ID_130 = "PLiwntN9Su5aRb8jG_KIw4UBrIpThPyHG0" #Scary docs ?
YOUTUBE_CHANNEL_ID_131 = "PLys46vgBa-4Bo-9XpYAATTnE2bZRd2mIH" #Witches, Curses, Voodoo
YOUTUBE_CHANNEL_ID_132 = "" #
YOUTUBE_CHANNEL_ID_133 = "PLMspNGyJw9_Tf1o4fSbuoe4Eovd3TjuXE" #Paranormal Docs
YOUTUBE_CHANNEL_ID_134 = "PLuCbFdfb15v0Vqn6nYf_xvvT1Te78COCa" #Paranormal Documentary
YOUTUBE_CHANNEL_ID_135 = "" #
YOUTUBE_CHANNEL_ID_136 = "PLhbMPzuyVCsB6rUPkE1kSTXt1QU0bIQ0f" #History docs
YOUTUBE_CHANNEL_ID_137 = "PL1vvakpxxAMlFo_SetgXcM7d3_MquN7se" #US history docs
YOUTUBE_CHANNEL_ID_138 = "PLILW8M17u_i0qBq4yEaUCg7EbneS8vT-m" #history docs
YOUTUBE_CHANNEL_ID_139 = "PLqWhJis-3TAwXKaJRyuKsdopGfMGcBEGk" #Ancient Egypt history docs
YOUTUBE_CHANNEL_ID_140 = "PLi8yb8Db9KzXU-fgwRtRAFjCzkwYvMeZL" #Roman empire history docs
YOUTUBE_CHANNEL_ID_141 = "PLL0TlHLkEmS-u7mHFEXbRQRVfGxXo7SEH" #history docs DELETEs
YOUTUBE_CHANNEL_ID_142 = "PLgTLZSbwbEZyhiPgeiO7pdwZQoeMl8dDD" #
YOUTUBE_CHANNEL_ID_143 = "PLVuKsHxUDogz6EVwLDQvGxEqHzPNRYHE1" #
YOUTUBE_CHANNEL_ID_144 = "" #
YOUTUBE_CHANNEL_ID_145 = "PL3OtDBB37OBjqge_LtrPprNgbeJmm-dsM" #UFOs and Aliens
YOUTUBE_CHANNEL_ID_146 = "PLsF582eWHNYAZufl8jU5u_vZcVwY-beDY" #Documentary: Aliens
YOUTUBE_CHANNEL_ID_147 = "PLRuizgs-y58d5AvDgxJNowsBoTHye-o0P" #ufo whistleblower
YOUTUBE_CHANNEL_ID_148 = "PLCFXlTrYVj1yUoTN_yNXHAs8v-MWTxeBW" #UFO doc movies
YOUTUBE_CHANNEL_ID_149 = "PLRI6bdg_VSI6XqK8YuXi0zEiNn3TNwnyn" #All UFOs
YOUTUBE_CHANNEL_ID_150 = "PLNaowfrjhS-kd8kVlmvSKydEZDOaTM_Yl" #ufo docs
YOUTUBE_CHANNEL_ID_151 = "" #
YOUTUBE_CHANNEL_ID_152 = "PL57quI9usf_sQPz1FlN008V0C-lgZ9QwC" #Science and tech
YOUTUBE_CHANNEL_ID_153 = "PLBcB_11vvDSI-IXD3uoGUXXfY0q4qZERv" #Dark Matter
YOUTUBE_CHANNEL_ID_154 = "PLAATyGCAVBXoESlhhWw0wgI8fXmWwEPiq" #space science
YOUTUBE_CHANNEL_ID_155 = "PLL2UakaxvMQ8SaeQ40oqFG_qIoHRQ3vnN" #space docs
YOUTUBE_CHANNEL_ID_156 = "PLJh1uIdYTLtzSvD2dLbcSvGJ5T4GQIhvM" #How the Universe works
YOUTUBE_CHANNEL_ID_157 = "PLtBSwZ5T8aR_hjrKeKg-jRt4BRDXxsQ32" #Astronomy & docs
YOUTUBE_CHANNEL_ID_158 = "PLyi2qH1vXPtEGBp1eKLCo9-RMxRWSeC9z" #The Universe
YOUTUBE_CHANNEL_ID_159 = "PLtbKV3u_fpiQ1U_AcCq_TkhWROpDvIWtz" #Science docs
YOUTUBE_CHANNEL_ID_160 = "" #
YOUTUBE_CHANNEL_ID_161 = "PLLl4BwK4Yv1GME_1QKkkEiodfnGd_3xum" #Nature mt st helen
YOUTUBE_CHANNEL_ID_162 = "PLqy1FsRXN8wznAmc3hEMFVdgDob3dOqG6" #Nature, amazon
YOUTUBE_CHANNEL_ID_163 = "PL5o3ll3G4acxgDMSO7JXvDsosQ-UDPL6n" #Nature Docs
YOUTUBE_CHANNEL_ID_164 = "PLlHanBMNk-DKQzkktkFKGvJR_9gSRDhBr" #PBS Nova
YOUTUBE_CHANNEL_ID_165 = "PL_jFbqOSEqaLIYGS0Oz8jTlrB8PaHiwdp" #Animal Docs
YOUTUBE_CHANNEL_ID_166 = "PL6aq1PBlrtR5D4xslD4VBos7zk0GSTuBb" #Wild Series Docs
YOUTUBE_CHANNEL_ID_167 = "PLvGQIC1rtlFvT_yx7HDngMqlWXGI4tKDw" #Nat Geo Wild
YOUTUBE_CHANNEL_ID_168 = "PLCWZ2IlVVw5DDAqZx-lStle-oJfazmelm" #Animal Documentary
YOUTUBE_CHANNEL_ID_169 = "" #
YOUTUBE_CHANNEL_ID_170 = "PL394E56A0B632C016"                 #Rugby Sports
YOUTUBE_CHANNEL_ID_171 = "PLItvZTYiHnTaVEjKYLB5BLuLnamqQx2W-" #ESPN-Sports Docs
YOUTUBE_CHANNEL_ID_172 = "PLyL-JKAxg5w8_OXDbV5zghtIhiAiQWxyX" #NHL docs
YOUTUBE_CHANNEL_ID_173 = "PLq-isVVF3foenhVLcdsGj1ww63hXKrso8" #Baseball docs
YOUTUBE_CHANNEL_ID_174 = "PLCkP5LViwv1hpdmDR0WzOcCvOzMmAerUL" #Wrestling Docs
YOUTUBE_CHANNEL_ID_175 = "PLNNR5FiyIxqbO93WhkgS8yed0iq68IHUQ" #UK Football Docs
YOUTUBE_CHANNEL_ID_176 = "PLf0oK3K9_SbEaPZqDBWxNq_YTIpDkXVwn" #Wrestling Docs
YOUTUBE_CHANNEL_ID_177 = "PLE9D0DCBA6AF072E0" #Sports docs and movies
YOUTUBE_CHANNEL_ID_178 = "PLEvvOXV5cPRK0g0-0shgK0WRtUTry-FeZ" #Docs Sports
YOUTUBE_CHANNEL_ID_179 = "PLhnyYq6bsiSJbiyO_jeewHB3D_5TFBipJ" #Mixed Sports Docs
YOUTUBE_CHANNEL_ID_180 = "PLFHLBLrXahtba_VDAfS1KtaXP1sVhIkxq" #Anime Movies
YOUTUBE_CHANNEL_ID_181 = "PLEvOxmwPB8EFoJpI4FlzZH9GHeh1wqalk" #Dubbed Japanese
YOUTUBE_CHANNEL_ID_182 = "PLQ1h4vDpyXDMm_G5v0VBmqtnpgsmwKuKC" #80s Cartoon Movies
YOUTUBE_CHANNEL_ID_183 = "PLy6nRkX3CzyL4l6BAWjHSRwmXWvWgNdGU" #Anime 80s,90,2k
YOUTUBE_CHANNEL_ID_184 = "PLc4SFpl1YyvuwwT9RFeEZbzfKHsdDX1V5" #Cartoon & Anime Movies
YOUTUBE_CHANNEL_ID_185 = "PLKrpm9lxqdtyR8z1jz0M3ps_sgU9kJxfr" #Anime delete test
YOUTUBE_CHANNEL_ID_186 = "PLRQAisQ_6Be4x4J2zVdEuITH5lXDpPIaQ" #Anime Movies
YOUTUBE_CHANNEL_ID_187 = "" #
YOUTUBE_CHANNEL_ID_188 = "PLMoqN2xEQkkc9b_57p8WLxXbvES74XDhm" #John Wayne
YOUTUBE_CHANNEL_ID_189 = "PLttOfW_IF8ou8o_oW44XQ2fwZUWHpVopx" #English Westerns
YOUTUBE_CHANNEL_ID_190 = "PLttOfW_IF8oujCyF9SFhk9tkiSn4tBRDW" #More Westerns (296)
YOUTUBE_CHANNEL_ID_191 = "PLttOfW_IF8otgW8iqYhHcdtlU9HMt7BMM" #Westerns: More
YOUTUBE_CHANNEL_ID_192 = "PLttOfW_IF8ou_WTDOId6S2ay7Vkqc1aKd" #Westerns (401)
YOUTUBE_CHANNEL_ID_193 = "PLttOfW_IF8oudzC4YAqlrHjF2E2_mOX9c" #Spaghetti Westerns
YOUTUBE_CHANNEL_ID_194 = "" #
YOUTUBE_CHANNEL_ID_195 = "" #
YOUTUBE_CHANNEL_ID_196 = "" #
YOUTUBE_CHANNEL_ID_197 = "PLO6BFV6fgGwshi6dyglSREMxzpCsbI00W" #Kings Of Horror: Occult
YOUTUBE_CHANNEL_ID_198 = "PLO6BFV6fgGwt52dMGnLiUvezcI2Nl_UVR" #Kings Of Horror: Paranormal
YOUTUBE_CHANNEL_ID_199 = "PLO6BFV6fgGwsnq-D4Ywepm4Iqo_0H1ZAt" #Kings of Horror Cult Classics
YOUTUBE_CHANNEL_ID_200 = "" #
YOUTUBE_CHANNEL_ID_201 = "" #
YOUTUBE_CHANNEL_ID_202 = "PLO6BFV6fgGwt5x5KOWp0dBF-2moeUAfXT" #Kings Of Horror: Zombies
YOUTUBE_CHANNEL_ID_203 = "" #
YOUTUBE_CHANNEL_ID_204 = "PLO6BFV6fgGwtdn2Cit6wNTFjr4smKUfFp" #Kings Of Horror: Monster
YOUTUBE_CHANNEL_ID_205 = "" #
YOUTUBE_CHANNEL_ID_206 = "" #
YOUTUBE_CHANNEL_ID_207 = "PL8833BA169D818131"                 #Ghostbusters
YOUTUBE_CHANNEL_ID_208 = "PLJhIcqoOEkIHzRfW7JkToSanTq3_sVC9Y" #Halloween Specials (kids)
YOUTUBE_CHANNEL_ID_209 = "PLJhIcqoOEkIF3IDCJKzeUrFz8DJVI99wf" #Christmas Specials (kids)
YOUTUBE_CHANNEL_ID_210 = "PLJhIcqoOEkIGvRL_xHLR-rJ02ugIjIvIN" #Veggie Tales
YOUTUBE_CHANNEL_ID_211 = "PLC5928B59A036F71F"                 #Casper The Friendly Ghost
YOUTUBE_CHANNEL_ID_212 = "PLJhIcqoOEkIG8V0mD9R4UHEn2D_H0uYTw" #Postman Pat
YOUTUBE_CHANNEL_ID_213 = "PLJhIcqoOEkIHf_U2Xm51ikdQStv5itLkG" #Animated Shows & Movies
YOUTUBE_CHANNEL_ID_214 = "PLJhIcqoOEkIGK4UJc4ipDXAs5C5cExrUg" #Animated Shorts & Movies
YOUTUBE_CHANNEL_ID_215 = "PLJhIcqoOEkIG7ZHKu_XPC1PVXqHs_ziP-" #Animated Shows & Movies
YOUTUBE_CHANNEL_ID_216 = "PLTBUMMNbY7qGk1EPSnb-ylGXKB-bW_dV-" #Invader Zim
YOUTUBE_CHANNEL_ID_217 = "PLLCcmBcBRcT9jhSlKI_ZN1GBLHIKrfmtq" #He-Man Episodes
YOUTUBE_CHANNEL_ID_218 = "PLNw_hEO5pK1oWX6Uymk8YBtNcmC64EZlY" #
YOUTUBE_CHANNEL_ID_219 = "PLNw_hEO5pK1oilmenQgX3KuWZZ6xlG_5Y" #
YOUTUBE_CHANNEL_ID_220 = "PLNw_hEO5pK1rdjEOr5_CsfOG2IF0k6RJj" #
YOUTUBE_CHANNEL_ID_221 = "PLNw_hEO5pK1oRPp3UP1zM8g58cqae-tZM" #
YOUTUBE_CHANNEL_ID_222 = "" #
YOUTUBE_CHANNEL_ID_223 = "PLAPGcD5LGrp6oKuxwa8GlXNSFBrZXNZik" #Twilight Zone 2002
YOUTUBE_CHANNEL_ID_224 = "PL2J5vJE5wP76sr7UZXADB0NupTOkeOmrH" #Murder She Wrote
YOUTUBE_CHANNEL_ID_225 = "PL5q8VRGX_yLIDj-WwthUSxp4KO02E08zz" #Dragnet
YOUTUBE_CHANNEL_ID_226 = "PLQ52K4zUTvHZTA0yQE1xBIy90qwVc1heV" #Tales Of The Crypt
YOUTUBE_CHANNEL_ID_227 = "PLmHgXUJMN1TVtqyVXJ4D3ozPxgwpV-UpQ" #Sherlock Holmes
YOUTUBE_CHANNEL_ID_228 = "PLC1EDzqtkrh9qeOtJCDt4Tr1QCCt4Fat4" #Mr Bean
YOUTUBE_CHANNEL_ID_229 = "PLgNgFgeTm0piyrBYD_7R3aGFTX2OAznWx" #Hanna Montana
YOUTUBE_CHANNEL_ID_230 = "PLOZzM8Kp5jhrsRi4n7KDHLZNL8owoM7Mp" #Western TV Shows
YOUTUBE_CHANNEL_ID_231 = "PLfJt-7qbuNtMFHMG_k2py2ABxrdnsEHIQ" #The Rebel
YOUTUBE_CHANNEL_ID_232 = "PL1V2SSERycssvC_FFdtBA16Qhiityw_ii" #Beverly Hillbillies
YOUTUBE_CHANNEL_ID_233 = "PL5q8VRGX_yLKVGbvIA6H18WTQmWS3TdH4" #New Detectives
YOUTUBE_CHANNEL_ID_234 = "PLeagipoZmyfnGP2cUhKrGU-6nv7CrtoE7" #Robin Hood 2006
YOUTUBE_CHANNEL_ID_235 = "PLmHgXUJMN1TXCZbl3w_RYofN_XMCRDtdy" #The Lucky Show
YOUTUBE_CHANNEL_ID_236 = "PLAPGcD5LGrp6WZOZyH1y3dkxi2eTxXi74" #Blake 7
YOUTUBE_CHANNEL_ID_237 = "PLd4rjD_RVZHEn0GxzchcjIdBBYTjsWv-X" #Classic Mr Bean
YOUTUBE_CHANNEL_ID_238 = "PL-QrWtkF-hBXqQslPleMFyAzjP7W7rF3u" #Classic BBC Mystery
YOUTUBE_CHANNEL_ID_239 = "PLB4401F8B2A9A304E"                 #Supercar
YOUTUBE_CHANNEL_ID_240 = "PL98x8JlHx_53N__G9_FFi3kcFJmgsHzkY" #Wagon Train
YOUTUBE_CHANNEL_ID_241 = "" #
YOUTUBE_CHANNEL_ID_242 = "" #
YOUTUBE_CHANNEL_ID_243 = "" #
YOUTUBE_CHANNEL_ID_244 = "" #
YOUTUBE_CHANNEL_ID_245 = "PLZeX9OgnzaHTfuoHY1Iz-SVEmOjF8Ryqp" #Medabots
YOUTUBE_CHANNEL_ID_246 = "PLoZfc2ixKLaGVrxuIP9j3eMVkDTeVA_Hz" #Clutch Cargo
YOUTUBE_CHANNEL_ID_247 = "PL2olSkgdlnHRytv2YEMltf04-QjNgbDuI" #King Of The Hill
YOUTUBE_CHANNEL_ID_248 = "PLNw_hEO5pK1oWX6Uymk8YBtNcmC64EZlY" #Guardians Of The Galaxy
YOUTUBE_CHANNEL_ID_249 = "PLNw_hEO5pK1oilmenQgX3KuWZZ6xlG_5Y" #Super Hero Squad
YOUTUBE_CHANNEL_ID_250 = "PLNw_hEO5pK1rdjEOr5_CsfOG2IF0k6RJj" #Ultimate Spider-man
YOUTUBE_CHANNEL_ID_251 = "PLNw_hEO5pK1oRPp3UP1zM8g58cqae-tZM" #Avengers Assemble" #
YOUTUBE_CHANNEL_ID_252 = "PLmgflcERua_0WknstC140kI8NFw3FqKNx" #Animated Toon Shows
YOUTUBE_CHANNEL_ID_253 = "PLqcNVz8UuCsJ0yJ5Td4bxbVHejncVncIj" #Inspector Gadget
YOUTUBE_CHANNEL_ID_254 = "" #
YOUTUBE_CHANNEL_ID_255 = "PLfuvnXufZmWLwwxtSXtDhNeFQeDXNjcYu" #Ancient Aliens
YOUTUBE_CHANNEL_ID_256 = "" #
YOUTUBE_CHANNEL_ID_257 = "" #
YOUTUBE_CHANNEL_ID_258 = "PLKhPstAakbEdzU-e3UwOglKg7w-Bjvj2C" #Bassmaster
YOUTUBE_CHANNEL_ID_259 = "PLXOUT0qRzAKFKd9O9KYchkp0_ZgxT3zoJ" #Wrestling Pay Per Views
YOUTUBE_CHANNEL_ID_260 = "PL0PTdhK8s-5QxWhL4o9cK5xZDzdfoZx6c" #Robson Green Fishing
YOUTUBE_CHANNEL_ID_261 = "" #
YOUTUBE_CHANNEL_ID_262 = "" #
YOUTUBE_CHANNEL_ID_263 = "" #
YOUTUBE_CHANNEL_ID_264 = "" #
YOUTUBE_CHANNEL_ID_265 = "" #
YOUTUBE_CHANNEL_ID_266 = "" #
YOUTUBE_CHANNEL_ID_267 = "" #
YOUTUBE_CHANNEL_ID_268 = "" #
YOUTUBE_CHANNEL_ID_269 = "" #
YOUTUBE_CHANNEL_ID_270 = "PLXVKxY66GuC5_nZvuk-O_1bpau4AvvA5a" #Busy Beavers
YOUTUBE_CHANNEL_ID_271 = "PLuALSlPoVa23Ok2TFHCrftqkDKOnIpFLo" #Official Pat and Stan
YOUTUBE_CHANNEL_ID_272 = "PLRU3FsQ1MS5KFsjh5Txh14b4PuGEn9MUK" #Tractor Tom
YOUTUBE_CHANNEL_ID_273 = "PLHOR8x-IicVJDAmJWZmJ-IMu1x3lTAld5" #HUMF
YOUTUBE_CHANNEL_ID_274 = "PLM7OLrgQDj4YIWPViSg4IudtwqluSJ60E" #Max & Ruby
YOUTUBE_CHANNEL_ID_275 = "PLV3Gd8vEgOrjvlv718bZzcAf5DdcyGjHr" #Hoopla Kids Show
YOUTUBE_CHANNEL_ID_276 = "PLf0AiNfdKYFs4fH9IqLUUvvA34lzz77L_" #Cartoon Candy
YOUTUBE_CHANNEL_ID_277 = "PL1jLb_9BOrCC2kd1wxZi2Bnvi2hkMTDCd" #Kids Channel
YOUTUBE_CHANNEL_ID_278 = "PLaKLlbutuIs83m4PDnCkxgz_5hduThPsG" #TuTiTu TV
YOUTUBE_CHANNEL_ID_279 = "PL-qhrpQ30cRzkr24PV9xbLxQXgCaNH0je" #Yo GABBA GABBA
YOUTUBE_CHANNEL_ID_280 = "PL0VE_cI7-AYRx9Qbz5C0oQix0AO6YdCtw" #Little Baby Bum
YOUTUBE_CHANNEL_ID_281 = "PL7Qz1g4_PhOvI85xi3ltYdFlOzZ9QqrRR" #Little Bear
YOUTUBE_CHANNEL_ID_282 = "" #
YOUTUBE_CHANNEL_ID_283 = "PLpd15K7DiNG8mj-bcXKwvqmET6ZWIWGzS" #Bananas In Pyjamas
YOUTUBE_CHANNEL_ID_284 = "PLhLlo5SXGT_0kedDOwvbTeMwp0Uz3Af4q" #Fifi and the Flowertots
YOUTUBE_CHANNEL_ID_285 = "PLzcEpQYkRSQ1hBS_Caklp3a3NupYQxbqM" #Postman Pat
YOUTUBE_CHANNEL_ID_286 = "PLKxKJVHwiseXLWkzfAOIVqZyUDNLnuplm" #Olivia The Pig
YOUTUBE_CHANNEL_ID_287 = "PLT81qowKRHzRCE2M7wuj2Y56ZTPLq0DMD" #Little Charlie Bear
YOUTUBE_CHANNEL_ID_288 = "PLGYOf7BkKBf0iifp9NGfwId1wZcd1WSJX" #VeggieTales
YOUTUBE_CHANNEL_ID_289 = "PL-zGgztzqlybth6-PPi1d2T39srXc--8q" #Strawberry Shortcake
YOUTUBE_CHANNEL_ID_290 = "PL3WuRw0nOgHPOgZ04JAzw_BfLzw0LHpLE" #Noddy In Toyland
YOUTUBE_CHANNEL_ID_291 = "PL6um4JyGrH5oe9UGIlUUB2efBS_erzvL1" #Ben and Holly Little Kingdom
YOUTUBE_CHANNEL_ID_292 = "PLdpyjDsvgMln1KZ7tqtKEMgCUMpRRLaip" #The Kids Club
YOUTUBE_CHANNEL_ID_293 = "PLB6QoGOGkP7OSV0vkG53hxyX6oFwkwQ4O" #Giggle Bellies
YOUTUBE_CHANNEL_ID_294 = "PLtgzvugo5sZdLGaHopCexqGPGiaZgBgl3" #Oh My Genius
YOUTUBE_CHANNEL_ID_295 = "PLBlSpozHTVp0MTkOsHfYkqmM-XoFmS4is" #Fluffy Jet Toys
YOUTUBE_CHANNEL_ID_296 = "" #
YOUTUBE_CHANNEL_ID_297 = "" #
YOUTUBE_CHANNEL_ID_298 = "" #
YOUTUBE_CHANNEL_ID_299 = "" #
YOUTUBE_CHANNEL_ID_300 = "" #
YOUTUBE_CHANNEL_ID_301 = "" #
YOUTUBE_CHANNEL_ID_302 = "" #
YOUTUBE_CHANNEL_ID_303 = "" #
YOUTUBE_CHANNEL_ID_304 = "" #
YOUTUBE_CHANNEL_ID_305 = "" #
YOUTUBE_CHANNEL_ID_306 = "" #
YOUTUBE_CHANNEL_ID_307 = "" #
YOUTUBE_CHANNEL_ID_308 = "" #
YOUTUBE_CHANNEL_ID_309 = "" #
YOUTUBE_CHANNEL_ID_310 = "" #

	
@route(mode='action')
def Action():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir( 
		name="[COLOR white][B]Action Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_67+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Action Hero Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_69+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Action Adventure Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_70+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Action Car Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_68+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Classic Action Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_38+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Westerns from Kisstube[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_42+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

@route(mode='animation')
def Animation():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Anime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_180+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dubbed Japanese[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_181+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]80s Cartoon Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_182+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime 80s,90,2k[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_183+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cartoon & Anime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_184+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Inspector Gadget[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_253+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Avengers Assemble[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_251+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ultimate Spider-Man[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_250+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Super Hero Squad[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_249+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Guardians Of The Galaxy[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_248+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]King Of The Hill[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_247+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Medabots Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_245+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Clutch Cargo[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_246+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Toon Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_252+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]He-Man Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_217+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Invader Zim[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_216+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_215+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shows & Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_213+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shorts & Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_214+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Postman Pat Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_212+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Casper The Friendly Ghost[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_211+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Veggie Tales Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_210+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Halloween Specials[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_208+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Christmas Specials[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_209+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)
		
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)
	
@route(mode='classic')
def Classic():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Cellardoor Old Movie Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_49+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Comedy Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_17+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hollywood Classics[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_14+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_18+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_18+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Mystery Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_15+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Sci-fi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_23+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Movie Greats[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_33+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Drama by Popcorn Flix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_41+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Grindhouse Classics[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_34+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Westerns from Kisstube[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_42+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)		

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

@route(mode='comedy')
def Comedy():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Comedy Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_17+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Comedy Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_37+"/", folder=True,
		icon=mediapath+"comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hallmark Romance Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_43+"/", folder=True,
		icon=mediapath+"comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Romance & Comedy Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_53+"/", folder=True,
		icon=mediapath+"comedy.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

@route(mode='crime')
def Crime():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Film Noir/Crime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_16+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Crime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_44+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mystery Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_15+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Film Noir Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_16+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mystery, Crime, Detectives[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_48+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]True Crime Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_66+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

@route(mode='docs')
def Docs():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Ancient Aliens[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_255+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_24+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Nature Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_63+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PBS Nova Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_64+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animal Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_65+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]History's Mysteries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_94+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Mysterious Universe[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_95+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]Yeti Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_98+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Weird Or What Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_99+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]Ghost Ships & Planes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_100+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Stonehenge Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_101+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]True Crime Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_66+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]BBC Crime Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_103+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]BBC Music Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_120+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ghostly Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_128+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Witches, Curses, Voodoo[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_131+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Paranormal Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_134+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]US History docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_137+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]History docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_136+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Universe[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_158+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Science and Tech[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_152+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Nat Geo Wild[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_167+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sports Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_178+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UFOs and Aliens[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_145+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)		
		
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

@route(mode='drama')
def Drama():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Drama by Popcorn Flix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_41+"/", folder=True,
		icon=mediapath+"drama.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Drama & Mystery Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_78+"/", folder=True,
		icon=mediapath+"drama.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Drama & War Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_77+"/", folder=True,
		icon=mediapath+"drama.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic War Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_13+"/", folder=True,
		icon=mediapath+"drama.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Movie & TV Drama[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_12+"/", folder=True,
		icon=mediapath+"drama.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

@route(mode='family')
def Family():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Christian Movies & Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_26+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lifetime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_50+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Westerns from Kisstube[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_42+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hallmark Romance Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_43+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

@route(mode='horror')
def Horror():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_18+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hammer & British Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_52+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]More Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_28+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ghoulish Grin Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_39+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Monster Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_51+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Old Fun Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_35+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Horror/Scifi Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_30+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Kings Of Horror: Occult[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_197+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kings Of Horror: Paranormal[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_198+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kings Of Horror: Cult Classics[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_199+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kings Of Horror: Zombies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_202+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kings Of Horror: Monster[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_204+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)
		
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

@route(mode='movie_mix')
def Movie_Mix():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Maverick Movie Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_54+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Movie Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_45+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Romance & Comedy Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_53+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mystery, Crime, Detectives[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_48+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

@route(mode='music')
def Music():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Christian Music Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_59+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Rock Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_55+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Music Concert Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_56+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Metal Rock Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_58+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mixed Genre Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_60+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]BBC Music Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_120+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

	
@route(mode='scifi')
def Scifi():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Cheesy Scifi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_31+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Sci-fi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_23+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]More Classic Scifi[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_29+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Monster Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_51+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Science Fiction Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_27+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

@route(mode='sports')
def Sports():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Wrestling Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_74+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Wrestling Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_76+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Sports Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_73+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Baseball Docs & Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_72+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Sports Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_46+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UK Football Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_75+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Sports Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_178+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mixed Sports Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_179+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]LFL Full Length Games[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_71+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Robson Green Fishing[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_260+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Wrestling PVR[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_259+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bassmaster Docs & Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_258+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

@route(mode='toddlers')
def Toddlers():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Busy Beavers[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_270+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Official Pat & Stan[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_271+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Tractor Tom[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_272+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]HUMF Official[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_273+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Max & Ruby[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_274+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hoopla Kids Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_275+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cartoon Candy[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_276+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]TuTiTu TV[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_278+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Yo Gabba Gabba[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_279+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Little Baby Bum[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_280+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Little Bear[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_281+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Oh My Genius[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_294+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bananas In Pyjamas[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_283+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fifi & The Flowertots[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_284+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Postman Pat[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_285+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Olivia The Pig[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_286+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Little Charlie Bear[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_287+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]VeggieTales Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_288+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Strawberry Shortcake[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_289+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Noddy In Toyland[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_290+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ben & Holly Little Kingdom[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_291+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Kids Club[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_292+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Giggle Bellies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_293+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Fluffy Jet Toys[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_295+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)
@route(mode='tv')
def Tv():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Twilight Zone (2002)[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_223+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Murder She Wrote[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_224+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Dragnet Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_225+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Tales Of The Crypt[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_226+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Sherlock Holmes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_227+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Mr Bean Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_228+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hanna Montana[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_229+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Western TV Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_230+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]The Rebel[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_231+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Beverly Hillbillies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_232+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]New Detectives[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_233+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Robin Hood (2006)[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_234+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Lucky Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_235+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Blake 7 Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_236+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Classic Mr Bean[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_237+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic BBC Mystery[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_238+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Supercar Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_239+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Wagon Train[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_240+"/", folder=True,
		icon=mediapath+"tvshows.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)
	
@route(mode='western')
def Western():

	add_link_info('[B][COLORorange]== J1TV ==[/COLOR][/B]', mediapath+'icon.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Westerns: John Wayne[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_188+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]English Westerns[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_189+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Western Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_190+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Westerns[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_191+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Westerns: More[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_192+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Spaghetti Westerns[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_193+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'icon.png', fanart)

#xbmcplugin.endOfDirectory(plugin_handle)
