# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

from resources.lib.modules.common import *
from resources.lib.modules.tromaGenres import *
from resources.lib.modules.troma import *

params = get_params()
mode = None

debug        = Addon_Setting(setting='debug')       
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.j1tv')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/media/'))
path   = xbmcaddon.Addon().getAddonInfo('path').decode("utf-8")

BASE  = "plugin://plugin.video.youtube/playlist/"
cBASE = "plugin://plugin.video.youtube/channel/"
uBASE = "plugin://plugin.video.youtube/user/"


YOUTUBE_CHANNEL_ID_19000 = "3COBeoWejmA" #Cannibal: The Musical
YOUTUBE_CHANNEL_ID_19001 = "pTLqTfKmNcw" #Dark Nature
YOUTUBE_CHANNEL_ID_19002 = "j_JQeA6PiwA" #Def By Temptation
YOUTUBE_CHANNEL_ID_19003 = "v16PtO2_edY" #Jessicka Rabid
YOUTUBE_CHANNEL_ID_19004 = "FE5HNZFtimc" #Klown Kamp Massacre
YOUTUBE_CHANNEL_ID_19005 = "-klB80q7n4k" #Combat Shock
YOUTUBE_CHANNEL_ID_19006 = "GJIecm0BLKI" #Decampitated
YOUTUBE_CHANNEL_ID_19007 = "vjEjOfncCFM" #Troma: Purge
YOUTUBE_CHANNEL_ID_19008 = "BzoAiiBeW8A" #Banana Motherf*ck*r
YOUTUBE_CHANNEL_ID_19009 = "4KOpWZHHz9Q" #Killing Twice
YOUTUBE_CHANNEL_ID_19010 = "GWf_tydTTnA" #Ghosts Of The Heartland
YOUTUBE_CHANNEL_ID_19011 = "ziaLG_o3sjs" #Witchcraft 5: Dance With The Devil
YOUTUBE_CHANNEL_ID_19012 = "0Tpzi6O5f-g" #Troma: Hemo
YOUTUBE_CHANNEL_ID_19013 = "2PdM8fci4iM" #Another Space Daze
YOUTUBE_CHANNEL_ID_19014 = "9f2wEzp9aOA" #Time Barbarians
YOUTUBE_CHANNEL_ID_19015 = "RCZ38Kjx2LU" #Go To Hell
YOUTUBE_CHANNEL_ID_19016 = "BHSncd9HQzM" #LA Maniac
YOUTUBE_CHANNEL_ID_19017 = "UR4h8-xN-qU" #Loony In The Woods
YOUTUBE_CHANNEL_ID_19018 = "X04S4amaaoo" #Blood Sisters Of Lesbian Sin
YOUTUBE_CHANNEL_ID_19019 = "GoNpbChQ6bo" #Connect 5
YOUTUBE_CHANNEL_ID_19020 = "t2zP5Wvc-mY" #Open 24-7
YOUTUBE_CHANNEL_ID_19021 = "hxGVs01M9EE" #Blood Junkie
YOUTUBE_CHANNEL_ID_19022 = "j8yBz3xIzkY" #Viewer Discretion Advised
YOUTUBE_CHANNEL_ID_19023 = "7fw9a96Ei0k" #A Nymphoid Barbarian In Dinosaur Hell
YOUTUBE_CHANNEL_ID_19024 = "DcQDGfZqTwM" #Bride Of Killer Nerd
YOUTUBE_CHANNEL_ID_19025 = "H8VNwTLCv1k" #Troma: Ellie
YOUTUBE_CHANNEL_ID_19026 = "0f39OWEqJ24" #Eye Of The Stranger
YOUTUBE_CHANNEL_ID_19027 = "h-Htv8y7xSA" #Troma: Fag Hag
YOUTUBE_CHANNEL_ID_19028 = "N0Dt9i9IUNg" #Fatty Drives The Bus
YOUTUBE_CHANNEL_ID_19029 = "zTWRgFCyons" #Ferocious Female Freedom Fighters
YOUTUBE_CHANNEL_ID_19030 = "DfW0CArg6UY" #Flesh Eaters From Outer Space
YOUTUBE_CHANNEL_ID_19031 = "aPJ4d4-joCk" #Frightmare
YOUTUBE_CHANNEL_ID_19032 = "QlmtF3oe1HM" #Graduation Day
YOUTUBE_CHANNEL_ID_19033 = "pdL4nK4iJUM" #Nocturne: Night Of The Vampire
YOUTUBE_CHANNEL_ID_19034 = "5fLmxV9bXr4" #Troma: Bigfoot

YOUTUBE_CHANNEL_ID_19035 = "nxiOBhaGWMo" #Hot Summer In Barefoot County
YOUTUBE_CHANNEL_ID_19036 = "7VVwuFv2UEI" #Troma: Buttcrack
YOUTUBE_CHANNEL_ID_19037 = "geJ2O9v-9Xc" #Farts Of Darkness
YOUTUBE_CHANNEL_ID_19038 = "HcmCl5esI78" #Wizards Of The Demon Sword
YOUTUBE_CHANNEL_ID_19039 = "scWyknOtfbs" #Jurassic Women
YOUTUBE_CHANNEL_ID_19040 = "9TEVgyiQpZE" #Macabre Pair Of Shorts
YOUTUBE_CHANNEL_ID_19041 = "J3xzZGu2maY" #Horror Of The Hungry Humongous Hungan
YOUTUBE_CHANNEL_ID_19042 = "4VI7ntoJNEk" #Blood Hook
YOUTUBE_CHANNEL_ID_19043 = "kBjqK7syeU4" #Zombiegeddon
YOUTUBE_CHANNEL_ID_19044 = "yfDzF2oN7Tc" #Tromas War
YOUTUBE_CHANNEL_ID_19045 = "zM-sr-hSiV8" #When Nature Calls
YOUTUBE_CHANNEL_ID_19046 = "zlMl-SUGBjI" #Beyond Evil
YOUTUBE_CHANNEL_ID_19047 = "dau1jqsdhl4" #Beware Children At Play
YOUTUBE_CHANNEL_ID_19048 = "FKLJ5zwUE80" #Troma: Grim
YOUTUBE_CHANNEL_ID_19049 = "ZTHO5zNXKG4" #The Last Horror Film
YOUTUBE_CHANNEL_ID_19050 = "aWt8z9mdf50" #Apocalypse Soon
YOUTUBE_CHANNEL_ID_19051 = "z1L87pKMKzE" #Rock & Roll Space Patrol
YOUTUBE_CHANNEL_ID_19052 = "VJj9B00EMek" #Dr. Hackenstein
YOUTUBE_CHANNEL_ID_19053 = "W4UfRN1angQ" #Battle Of Loves Return
YOUTUBE_CHANNEL_ID_19054 = "FEUE1dbwqRI" #Killer Yacht Party
YOUTUBE_CHANNEL_ID_19055 = "zNKPAibmS-M" #Luther The Geek
YOUTUBE_CHANNEL_ID_19056 = "ijKfFvdt0L0" #Where Evil Lives
YOUTUBE_CHANNEL_ID_19057 = "ZuROkQC3fy4" #All The Love You Cannes
YOUTUBE_CHANNEL_ID_19058 = "IjvMU0Bt46I" #A Tale Of Two Sisters
YOUTUBE_CHANNEL_ID_19059 = "mJkRQHX3brw" #Igor And The Lunatics
YOUTUBE_CHANNEL_ID_19060 = "r5tQmyY8SRA" #Heavy Mental
YOUTUBE_CHANNEL_ID_19061 = "KktVoWlsj1E" #Troma: Lollilove
YOUTUBE_CHANNEL_ID_19062 = "eleqXRSnUmY" #Madigans Millions
YOUTUBE_CHANNEL_ID_19063 = "6Zor9h7bfy8" #Actium Maximus: War Of The Alien Dinosaurs
YOUTUBE_CHANNEL_ID_19064 = "iCorDG3OHuU" #Troma: Bugged
YOUTUBE_CHANNEL_ID_19065 = "UYwhQVlXQQ8" #Attack Of The Tromaggot
YOUTUBE_CHANNEL_ID_19066 = "BzoAiiBeW8A" #Hollowgate
YOUTUBE_CHANNEL_ID_19067 = "bsUVbzVYxGY" #LA Crackdown
YOUTUBE_CHANNEL_ID_19068 = "41p61Q4ILbc" #Wiseguys VS Zombies
YOUTUBE_CHANNEL_ID_19069 = "zS2EgumLXXE" #Big Gus Whats The Fuss
YOUTUBE_CHANNEL_ID_19070 = "gjGpkHo5WAk" #Troma: Bloodspit
YOUTUBE_CHANNEL_ID_19071 = "h69YxXz2Xks" #Video Demons Do Psychotown
YOUTUBE_CHANNEL_ID_19072 = "VirQxX9QGHw" #Doggie Tails
YOUTUBE_CHANNEL_ID_19073 = "Eay9cz3kXCI" #I Was A Teenage TV Terrorist
YOUTUBE_CHANNEL_ID_19074 = "CMZcmdL6Pzc" #Baconhead
YOUTUBE_CHANNEL_ID_19075 = "TEfHuo2MdKU" #The Wedding Party
YOUTUBE_CHANNEL_ID_19076 = "lU1UFx8-92o" #Back Road Diner
YOUTUBE_CHANNEL_ID_19077 = "oJ0KDTujx7U" #The Evolved Part 1
YOUTUBE_CHANNEL_ID_19078 = "t-W9TXDOpy0" #Viral Assasins
YOUTUBE_CHANNEL_ID_19079 = "OlPP0-6qqVU" #Splendor And Wisdom
YOUTUBE_CHANNEL_ID_19080 = "0DsS0pdS-Dk" #The Butchers
YOUTUBE_CHANNEL_ID_19081 = "7Tyz2u1Amys" #Troma: Jefftowne
YOUTUBE_CHANNEL_ID_19082 = "SlIZJqRSV-I" #Space Zombie Bingo
YOUTUBE_CHANNEL_ID_19083 = "jnVtQb0NrgY" #They Call Me Macho Woman
YOUTUBE_CHANNEL_ID_19084 = "5ZLWzTzz0jY" #Star Worms II: Attack Of The Pleasure Pods
YOUTUBE_CHANNEL_ID_19085 = "CWssk2UTPJo" #Troma: Pep Squad
YOUTUBE_CHANNEL_ID_19086 = "57F44ECk-iM" #Invasion Of The Space Preachers
YOUTUBE_CHANNEL_ID_19087 = "ZPlMd9FOSmI" #Nerds Of A Feather
YOUTUBE_CHANNEL_ID_19088 = "8z6tbBrOoDI" #Nightmare Weekend
YOUTUBE_CHANNEL_ID_19089 = "pXuZXp_U0WQ" #Redneck Zombies
YOUTUBE_CHANNEL_ID_19090 = "CjSdZT1zufI" #Nightbeast
YOUTUBE_CHANNEL_ID_19091 = "9nsEqT1EQ04" #Demented Death Farm Massacre
YOUTUBE_CHANNEL_ID_19092 = "yjoZrJYEUxw" #Mommys Epitaph
YOUTUBE_CHANNEL_ID_19093 = "JPrCEiVewyU" #Zombie Werewolves Attack
YOUTUBE_CHANNEL_ID_19094 = "JLoRFWyLkdQ" #Contra Conspiracy
YOUTUBE_CHANNEL_ID_19095 = "XbWUKNzcT0s" #White Zombie
YOUTUBE_CHANNEL_ID_19096 = "_92S7ClYuCM" #Secret Of The Magic Mushrooms
YOUTUBE_CHANNEL_ID_19097 = "FyBlE3jOMQw" #Fear Town USA
YOUTUBE_CHANNEL_ID_19098 = "LBYcmNSv1RQ" #Toxic Avenger II
YOUTUBE_CHANNEL_ID_19099 = "PV3UUt-0RBM" #Toxic Avenger III

YOUTUBE_CHANNEL_ID_19100 = "4roVT6QK-OY" #Toxic Avenger IV
YOUTUBE_CHANNEL_ID_19101 = "TyrzsAfr8dE" #Toxic Avenger
YOUTUBE_CHANNEL_ID_19102 = "_hhSnjzYvMw" #Class Of Nuke Em High
YOUTUBE_CHANNEL_ID_19103 = "B3Bmy3I4O9I" #Frog Monster From Hell
YOUTUBE_CHANNEL_ID_19104 = "KxsapeIRS7c" #Plutonium Baby
YOUTUBE_CHANNEL_ID_19105 = "7IiAsW1rG8U" #Dragon Fury
YOUTUBE_CHANNEL_ID_19106 = "1HGUVVFGEzQ" #Sucker The Vampire
YOUTUBE_CHANNEL_ID_19107 = "sc3u2rb0Sjg" #Stuck On You
YOUTUBE_CHANNEL_ID_19108 = "HY8Ln05PZmw" #Coons, Night Of The Bandits Of The Night
YOUTUBE_CHANNEL_ID_19109 = "-2s1TlGSWjY" #Class Of Nuke Em High II
YOUTUBE_CHANNEL_ID_19110 = "AB_ll3X6-x4" #Class Of Nuke Em High III
YOUTUBE_CHANNEL_ID_19111 = "uUYdbSIFtCQ" #Video Vixens
YOUTUBE_CHANNEL_ID_19112 = "GbT6aQfketQ" #Poultrygeist, Night Of The Chicken Dead
YOUTUBE_CHANNEL_ID_19113 = "tBjXnIQefGU" #Squeeze Play
YOUTUBE_CHANNEL_ID_19114 = "3iFi8EcDg7o" #Blood Boobs N Beast
YOUTUBE_CHANNEL_ID_19115 = "XJlpqk_uXtQ" #Mothers Day
YOUTUBE_CHANNEL_ID_19116 = "33GzdFK7fuY" #State Of Mind
YOUTUBE_CHANNEL_ID_19117 = "RnVODVhu7VY" #Dead Dudes In The House
YOUTUBE_CHANNEL_ID_19118 = "gUX9tUZDcW8" #The First Turn-On
YOUTUBE_CHANNEL_ID_19119 = "1NO1f0gnNAY" #Chosen One, Legend Of Raven
YOUTUBE_CHANNEL_ID_19120 = "CnWOnBaVtow" #Surf Nazis Must Die
YOUTUBE_CHANNEL_ID_19121 = "zkQMwAt5jw4" #Deadly Daphnes Revenge
YOUTUBE_CHANNEL_ID_19122 = "pjmyfBcwyqQ" #Rockabilly Vampire
YOUTUBE_CHANNEL_ID_19123 = "9y8aXXCsz8k" #Theres Nothing Out There
YOUTUBE_CHANNEL_ID_19124 = "8U46TvpLymg" #Troma: Body Parts
YOUTUBE_CHANNEL_ID_19125 = "X1PYsHD7KCs" #Alien Blood
YOUTUBE_CHANNEL_ID_19126 = "My3TrFAuhWE" #Reel Horror
YOUTUBE_CHANNEL_ID_19127 = "uq53OobwoAs" #Doomsday County
YOUTUBE_CHANNEL_ID_19128 = "f6xh1vXuJ3g" #Mr Bricks, A Heavy Metal Musical
YOUTUBE_CHANNEL_ID_19129 = "kexYPMWIfwE" #Rabid Grannies
YOUTUBE_CHANNEL_ID_19130 = "DFo4TvgyUFg" #The Media Madman
YOUTUBE_CHANNEL_ID_19131 = "VJPA1BvDHe8" #Curse Of The Cannibal Confederates
YOUTUBE_CHANNEL_ID_19132 = "mekP8mvJSuU" #Psycho Sleepover
YOUTUBE_CHANNEL_ID_19133 = "w5smqiQ6deE" #Troma: Badmouth
YOUTUBE_CHANNEL_ID_19134 = "Df3Nmp0Rv9A" #Troma: Cybernator
YOUTUBE_CHANNEL_ID_19135 = "dHwBeSGRzwA" #Teenape VS The Monster Nazi Apocalypse
YOUTUBE_CHANNEL_ID_19136 = "GxYq_MrdNLY" #Seduction Of A Nerd
YOUTUBE_CHANNEL_ID_19137 = "e77iWeB-m_k" #The Seduction Of Dr. Fugazzi
YOUTUBE_CHANNEL_ID_19138 = "XrBpISZgKyQ" #Sgt. Kabukiman N.Y.P.D.
YOUTUBE_CHANNEL_ID_19139 = "-Luz8MVpBzY" #The Ruining
YOUTUBE_CHANNEL_ID_19140 = "LsRTAzwOOiY" #Maniac Nurses Find Ecstacy
YOUTUBE_CHANNEL_ID_19141 = "3HR2FdLGRy8" #Superstarlet A.D.
YOUTUBE_CHANNEL_ID_19142 = "2K-UbThK5_I" #The Children
YOUTUBE_CHANNEL_ID_19143 = "bLHFhAiYYlE" #Stuff Stephanie In The Incinerator
YOUTUBE_CHANNEL_ID_19144 = "_hhSnjzYvMw" #Class Of Nuke Em High
YOUTUBE_CHANNEL_ID_19145 = "dsMxWHbHYaI" #Troma: Cry Uncle
YOUTUBE_CHANNEL_ID_19146 = "-C7u8pCZ6H8" #Preacherman
YOUTUBE_CHANNEL_ID_19147 = "WuNLXe0yxkM" #Meat For Satans Icebox
YOUTUBE_CHANNEL_ID_19148 = "DF0Ax8bXzpE" #Crazy Animal
YOUTUBE_CHANNEL_ID_19149 = "Cl_oJWxB9tc" #Pot Zombies
YOUTUBE_CHANNEL_ID_19150 = "YxOKAIeGmSI" #Troma: Foreplay
YOUTUBE_CHANNEL_ID_19151 = "m5thLt_b4n4" #Waitress
YOUTUBE_CHANNEL_ID_19152 = "RAqzHfF0ZDQ" #Drawing Blood
YOUTUBE_CHANNEL_ID_19153 = "E9AbugGmQ1c" #Troma: Tainted
YOUTUBE_CHANNEL_ID_19154 = "ZWwukWsLnP8" #Getting Lucky
YOUTUBE_CHANNEL_ID_19155 = "O49rj8q7CvU" #Blood Oath
YOUTUBE_CHANNEL_ID_19156 = "0qHmbNxa6As" #Fortress Of Amerikkka
YOUTUBE_CHANNEL_ID_19157 = "CX7uc_t4YJw" #Slaughter Party
YOUTUBE_CHANNEL_ID_19158 = "3mmHtmHEBz0" #Story Of A Junkie
YOUTUBE_CHANNEL_ID_19159 = "jZD_BY7941o" #Troma: Belcebu
YOUTUBE_CHANNEL_ID_19160 = "G4thooe-7sg" #Witchcraft 4: The Virgin Heart
YOUTUBE_CHANNEL_ID_19161 = "KjqcJIDWWSY" #Legend Of The Chupacabra
YOUTUBE_CHANNEL_ID_19162 = "S8Z4NFGTt2A" #The Stabilizer
YOUTUBE_CHANNEL_ID_19163 = "Umow8M7kay0" #Fertilize The Blaspheming Bombshell
YOUTUBE_CHANNEL_ID_19164 = "a1W6di81b94" #Savage Abduction
YOUTUBE_CHANNEL_ID_19165 = "n-WjwHSHhHA" #The Hall Monitor
YOUTUBE_CHANNEL_ID_19166 = "lfo3BVmCk6A" #Troma: Large
YOUTUBE_CHANNEL_ID_19167 = "ZeOFRKwCee4" #Theatre Of The Deranged II
YOUTUBE_CHANNEL_ID_19168 = "sLUE_Fz5SNY" #Vegas In Space
YOUTUBE_CHANNEL_ID_19169 = "A77UnQ0eYc8" #Zombie Island Massacre
YOUTUBE_CHANNEL_ID_19170 = "Rx16cmCbiL0" #Special Needs
YOUTUBE_CHANNEL_ID_19171 = "8YHX1s16AEo" #Dead Eyes Open
YOUTUBE_CHANNEL_ID_19172 = "fbu-zYPC6tM" #Outlaw Prophet
YOUTUBE_CHANNEL_ID_19173 = "-XWF9WpsRgo" #Witchcraft
YOUTUBE_CHANNEL_ID_19174 = "6-79Rd0J2Vg" #Witchcraft 2: The Temptress
YOUTUBE_CHANNEL_ID_19175 = "UEIgDXmMfOg" #Witchcraft 3: The Kiss Of Death
YOUTUBE_CHANNEL_ID_19176 = "" #
YOUTUBE_CHANNEL_ID_19177 = "" #
YOUTUBE_CHANNEL_ID_19178 = "" #
YOUTUBE_CHANNEL_ID_19179 = "" #
YOUTUBE_CHANNEL_ID_19180 = "" #
YOUTUBE_CHANNEL_ID_19181 = "" #
YOUTUBE_CHANNEL_ID_19182 = "" #
YOUTUBE_CHANNEL_ID_19183 = "" #
YOUTUBE_CHANNEL_ID_19184 = "" #
YOUTUBE_CHANNEL_ID_19185 = "" #
YOUTUBE_CHANNEL_ID_19186 = "" #
YOUTUBE_CHANNEL_ID_19187 = "" #
YOUTUBE_CHANNEL_ID_19188 = "" #
YOUTUBE_CHANNEL_ID_19189 = "" #
YOUTUBE_CHANNEL_ID_19190 = "" #
YOUTUBE_CHANNEL_ID_19191 = "" #
YOUTUBE_CHANNEL_ID_19192 = "" #
YOUTUBE_CHANNEL_ID_19193 = "" #
YOUTUBE_CHANNEL_ID_19194 = "" #
YOUTUBE_CHANNEL_ID_19195 = "" #
YOUTUBE_CHANNEL_ID_19196 = "" #
YOUTUBE_CHANNEL_ID_19197 = "" #
YOUTUBE_CHANNEL_ID_19198 = "" #
YOUTUBE_CHANNEL_ID_19199 = "" #

YOUTUBE_CHANNEL_ID_19200 = "PLLnfvt0Tjwhqv4b1FNHEgqWywb2OstZcl" #Toxic Crusaders Series
YOUTUBE_CHANNEL_ID_19201 = "PLLnfvt0TjwhpraIWaZL7UliPf0RwtvUVX" #Tromazing Shorts
YOUTUBE_CHANNEL_ID_19202 = "PLLnfvt0TjwhoiZb0V9hlGK_wmEwTGTn6T" #Your Own Filmmaking
YOUTUBE_CHANNEL_ID_19203 = "PLLnfvt0TjwhrpRf7KUbfE6zSAwZ0rlPkZ" #Tromas Buried Treasure
YOUTUBE_CHANNEL_ID_19204 = "PLLnfvt0TjwhoE2krddNjkpI0S_TYo3sk0" #Uncle LLoydies Diary
YOUTUBE_CHANNEL_ID_19205 = "" #

	
def add_link_info(name, iconimage, fanart):
	u = sys.argv[0] + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'false') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz) 

def addDirMain(name,url,zmode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&zmode="+str(zmode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def regex_get_all(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r


def get_setting(setting):
    return addon.getSetting(setting)


def set_setting(setting, string):
    return addon.setSetting(setting, string)


def get_string(string_id):
    return addon.getLocalizedString(string_id)

#xbmcplugin.endOfDirectory(plugin_handle)
