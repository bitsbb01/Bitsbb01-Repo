# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

from resources.lib.modules.channels import *
from resources.lib.modules.common import *

params = get_params()
mode = None

debug        = Addon_Setting(setting='debug')       
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
artAddon     = 'script.j1.artwork'

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.j1tv')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'
path   = xbmcaddon.Addon().getAddonInfo('path').decode("utf-8")

BASE  = "plugin://plugin.video.youtube/playlist/"
cBASE = "plugin://plugin.video.youtube/channel/"
uBASE = "plugin://plugin.video.youtube/user/"

YOUTUBE_CHANNEL_ID_6001 = ""
YOUTUBE_CHANNEL_ID_6002 = "PLKmEfdT1xY8K-dRlMWN5XA_uNqcJcqE49" #Poly Pockets
YOUTUBE_CHANNEL_ID_6003 = "PLqrLEr7tAISpmpzgx9DGGdTV21N8oM9WA" #Cartoons
YOUTUBE_CHANNEL_ID_6004 = "PLKmEfdT1xY8JOf4thg2S5bgwEn8eyDxGL" #Pocoyo
YOUTUBE_CHANNEL_ID_6005 = "PLKmEfdT1xY8JiiUlP-n2GZfmVLtMiW3qx" #Looney Toons Cartoons
YOUTUBE_CHANNEL_ID_6006 = "PLKmEfdT1xY8K2zEWLHOjzXqE8GODNkx-J" #Oggy-and-The-Cockroaches-Cartoon
YOUTUBE_CHANNEL_ID_6007 = "PLKmEfdT1xY8IA2EQ7FWfbr63xvh6x4u9R" #Oddbods
YOUTUBE_CHANNEL_ID_6008 = "PLKmEfdT1xY8Jd_51b4jpNaPLBTwxb3khU" #Mr. Bean
YOUTUBE_CHANNEL_ID_6009 = "PLZeX9OgnzaHTfuoHY1Iz-SVEmOjF8Ryqp" #Medabots
YOUTUBE_CHANNEL_ID_6010 = "PLoZfc2ixKLaGVrxuIP9j3eMVkDTeVA_Hz" #Clutch Cargo
YOUTUBE_CHANNEL_ID_6011 = "PLKRTSabSJj40Dx4kTlmxlywmq-er4rJON" #Sofia The First
YOUTUBE_CHANNEL_ID_6012 = "PL0oL4hnu6SPp8UOy19tKxpLx6fc-tn_Nf" #Doc McStuffins
YOUTUBE_CHANNEL_ID_6013 = "PLB4401F8B2A9A304E"                 #Supercar
YOUTUBE_CHANNEL_ID_6014 = "PLgNgFgeTm0piyrBYD_7R3aGFTX2OAznWx" #Hanna Montana
YOUTUBE_CHANNEL_ID_6015 = "PLKmEfdT1xY8JOMM11coDgNSVbidhGbFBE" #He-Man
YOUTUBE_CHANNEL_ID_6016 = "PLKmEfdT1xY8JMiBxxUkYyf2bkcj9DvbGm" #Classic Cartoons
YOUTUBE_CHANNEL_ID_6017 = "" #
YOUTUBE_CHANNEL_ID_6018 = "PLqcNVz8UuCsJ0yJ5Td4bxbVHejncVncIj" #Inspector Gadget
YOUTUBE_CHANNEL_ID_6019 = "PLNw_hEO5pK1oWX6Uymk8YBtNcmC64EZlY" #Guardians Of The Galaxy
YOUTUBE_CHANNEL_ID_6020 = "PLNw_hEO5pK1oilmenQgX3KuWZZ6xlG_5Y" #Super Hero Squad
YOUTUBE_CHANNEL_ID_6021 = "PLNw_hEO5pK1rdjEOr5_CsfOG2IF0k6RJj" #Ultimate Spider-man
YOUTUBE_CHANNEL_ID_6022 = "PLNw_hEO5pK1oRPp3UP1zM8g58cqae-tZM" #Avengers Assemble
YOUTUBE_CHANNEL_ID_6023 = "PLmgflcERua_0WknstC140kI8NFw3FqKNx" #Animated Toon Shows
YOUTUBE_CHANNEL_ID_6024 = "" #
YOUTUBE_CHANNEL_ID_6025 = "wearebusybeavers"                   #Busy Beavers
YOUTUBE_CHANNEL_ID_6026 = "eonefamily"                         #Official Pat and Stan
YOUTUBE_CHANNEL_ID_6027 = "UCzJfZozRYkKPbQP9xbGyFfA"           #Tractor Tom
YOUTUBE_CHANNEL_ID_6028 = "theofficialhumf"                    #HUMF Channel
YOUTUBE_CHANNEL_ID_6029 = "PLM7OLrgQDj4YIWPViSg4IudtwqluSJ60E" #Max & Ruby
YOUTUBE_CHANNEL_ID_6030 = "TreehouseDirect"                    #Treehouse Direct
YOUTUBE_CHANNEL_ID_6031 = "FluffyJetProductions"               #Fluffy Jet Toys
YOUTUBE_CHANNEL_ID_6032 = "ohmygenius"                         #Oh My Genius
YOUTUBE_CHANNEL_ID_6033 = "tutitutv"                           #TuTiTu TV
YOUTUBE_CHANNEL_ID_6034 = "UCxezak0GpjlCenFGbJ2mpog"           #Yo GABBA GABBA
YOUTUBE_CHANNEL_ID_6035 = "LittleBabyBum"                      #Little Baby Bum
YOUTUBE_CHANNEL_ID_6036 = "UCncFzSeWqySvOXEbQoEJsZg"           #Little Bear
YOUTUBE_CHANNEL_ID_6037 = "PLQ1h4vDpyXDMm_G5v0VBmqtnpgsmwKuKC" #80s Cartoon Movies
YOUTUBE_CHANNEL_ID_6038 = "TheGiggleBellies"                   #Giggle Bellies
YOUTUBE_CHANNEL_ID_6039 = "UC0j36_NCIX_eSc1nXfNGXVQ"           #Fifi and the Flowertots
YOUTUBE_CHANNEL_ID_6040 = "PostmanPatSDS"                      #Postman Pat Channel
YOUTUBE_CHANNEL_ID_6041 = "UCKe-7-MbrHXAUB3hYTa6pkw"           #Olivia The Pig
YOUTUBE_CHANNEL_ID_6042 = "UCydekQV_GkprQFYMdgc8e6A"           #Little Charlie Bear
YOUTUBE_CHANNEL_ID_6043 = "BigIdeaInc"                         #VeggieTales
YOUTUBE_CHANNEL_ID_6044 = "StrawberryAGP"                      #Strawberry Shortcake
YOUTUBE_CHANNEL_ID_6045 = "UCO0vPDAqN7BTK9kNAeP3sKw"           #Noddy In Toyland
YOUTUBE_CHANNEL_ID_6046 = "" #
YOUTUBE_CHANNEL_ID_6047 = "" #
YOUTUBE_CHANNEL_ID_6048 = "" #
YOUTUBE_CHANNEL_ID_6049 = "" #
YOUTUBE_CHANNEL_ID_6050 = "" #
YOUTUBE_CHANNEL_ID_6051 = "" #

YOUTUBE_CHANNEL_ID_6052 = "PLEAKW4PcnvxmrJxTJPgNSrSgnhRdMHaqd" #Classic Looney Cartoons
YOUTUBE_CHANNEL_ID_6053 = "PLJhIcqoOEkIHzRfW7JkToSanTq3_sVC9Y" #Halloween Specials (kids)
YOUTUBE_CHANNEL_ID_6054 = "PLJhIcqoOEkIF3IDCJKzeUrFz8DJVI99wf" #Christmas Specials (kids)
YOUTUBE_CHANNEL_ID_6055 = "PLJhIcqoOEkIGvRL_xHLR-rJ02ugIjIvIN" #Veggie Tales
YOUTUBE_CHANNEL_ID_6056 = "PLC5928B59A036F71F"                 #Casper The Friendly Ghost
YOUTUBE_CHANNEL_ID_6057 = "PLJhIcqoOEkIG8V0mD9R4UHEn2D_H0uYTw" #Postman Pat
YOUTUBE_CHANNEL_ID_6058 = "PLJhIcqoOEkIHf_U2Xm51ikdQStv5itLkG" #Animated Shows & Movies
YOUTUBE_CHANNEL_ID_6059 = "PLJhIcqoOEkIGK4UJc4ipDXAs5C5cExrUg" #Animated Shorts & Movies
YOUTUBE_CHANNEL_ID_6060 = "PLJhIcqoOEkIG7ZHKu_XPC1PVXqHs_ziP-" #Animated Shows & Movies
YOUTUBE_CHANNEL_ID_6061 = "PLTBUMMNbY7qGk1EPSnb-ylGXKB-bW_dV-" #Invader Zim
YOUTUBE_CHANNEL_ID_6062 = "PLHiJcdYpg_-2du2MQciAlfd47UuvZO3gM" #Comedy Cartoon Mix
YOUTUBE_CHANNEL_ID_6063 = "PLcvAAt6aAUZole2agAJKaN1Y2yjlhq84K" #Comedy Cat & Keet
YOUTUBE_CHANNEL_ID_6064 = "PLoWXPRbBO29vBJ3rhYaDoz31fSA2m1khy" #Laurel And Hardy Cartoons
YOUTUBE_CHANNEL_ID_6065 = "PLZs0gQed9tMRPi0Ku_pOY2uen-YWP_F2c" #Abbott And Costello Cartoons
YOUTUBE_CHANNEL_ID_6066 = "PL68n5T5A7u8xBOlf88vMf6JUL_bARDASw" #Three Stooges Cartoons
YOUTUBE_CHANNEL_ID_6067 = "PLHerjfWGX0CXEroqenrJKAHileuAXjNm5" #Animated Films For Kids
YOUTUBE_CHANNEL_ID_6068 = "PLnvRhxFi1ULlC-QlVfG9O2EXWfuE9NV9N" #Christian Animated Films
YOUTUBE_CHANNEL_ID_6069 = "PLx7-gNQjGj-gkFZIR2h1QCgCB2PnwVETo" #Animated Short Films
YOUTUBE_CHANNEL_ID_6070 = "PLGqvTZeKNUpxPtMYkBiRUGm-KRI-3rHnp" #Kids Easter Movies
YOUTUBE_CHANNEL_ID_6071 = "" #
YOUTUBE_CHANNEL_ID_6072 = "PL6zkp8SzkZFquYojnprCmeB8LKW3I7nQ9" #Roy Rodgers
YOUTUBE_CHANNEL_ID_6073 = "PL-j_2gv0LMKDyUPuNwQUHk0ZqSI0UkYtb" #Lone Ranger
YOUTUBE_CHANNEL_ID_6074 = "PLMoqN2xEQkkc9b_57p8WLxXbvES74XDhm" #John Wayne
YOUTUBE_CHANNEL_ID_6075 = "PLLnN6aZ9EH9Fn9AItggnY7J1DoBsgN7Fg" #The Rifleman
YOUTUBE_CHANNEL_ID_6076 = "PLvu2oOrWFl_NuIqDgQQoIHzcx_jPlZUUy" #Gunsmoke
YOUTUBE_CHANNEL_ID_6077 = "PLeagipoZmyfkmUp154BZS1kjUSAoVpwA2" #My Friend Flicka
YOUTUBE_CHANNEL_ID_6078 = "PLeagipoZmyfkEDtcktgmwAnrzGcRfFsMX" #Annie Oakley
YOUTUBE_CHANNEL_ID_6079 = "PLjkUwl9vY2dzjULzxzkK6Tnf5TSegLI8t" #Animated Lone Ranger
YOUTUBE_CHANNEL_ID_6080 = "PL6fJmjt84zZh47AdFiZLlAscqFz2gZLIK" #Disneys Zorro
YOUTUBE_CHANNEL_ID_6081 = "" #
YOUTUBE_CHANNEL_ID_6082 = "PLkLimRXN6NKwOybbWpLUuYZfJZxxgLj-D" #Justice League animated s1,s2
YOUTUBE_CHANNEL_ID_6083 = "PL_PQ0mKZqubuLQIAibuVmMfoh-OY1v2gD" #Godzilla The Series
YOUTUBE_CHANNEL_ID_6084 = "PLj9r_42NzuMT7C1k6z7yNaV-4ct9pXQuB" #1960s Space Angel
YOUTUBE_CHANNEL_ID_6085 = "PLKR-WUXdFW-tIMC_om6E4gRZynnyDl984" #Scifi Godzilla
YOUTUBE_CHANNEL_ID_6086 = "PLZs0gQed9tMSh045V4TSkbxwptHXpxd49" #Astro Boy
YOUTUBE_CHANNEL_ID_6087 = "" #
YOUTUBE_CHANNEL_ID_6088 = "PL8833BA169D818131"                 #Ghostbusters
YOUTUBE_CHANNEL_ID_6089 = "PLNQ-3rd6vA8k0Ruic25d5B6LwWDUjFcdE" #Buzz Lightyear Series (kids)
YOUTUBE_CHANNEL_ID_6090 = "PLySo2SlSHPSOOGZM3_2Qun52hCaRNYW9y" #Sonic the Hedgehog
YOUTUBE_CHANNEL_ID_6091 = "PLF9Ksz48e9pP_uJr94if6ZXoDxmggT9SB" #Mighty Mouse
YOUTUBE_CHANNEL_ID_6092 = "PLZs0gQed9tMT2zhdJ9Fwx5AHlA5gYEaqE" #Mighty Mouse
YOUTUBE_CHANNEL_ID_6093 = "PLMxZf2wp46f6V29Hbjn2hlmr4adeLPYgO" #Underdog
YOUTUBE_CHANNEL_ID_6094 = "PL6Iw4ELd-WzXfweLJtlt5LtxllTUkZ53P" #Superhero cartoons
YOUTUBE_CHANNEL_ID_6095 = "PLLrV5xCMn4kB1hBeqRFuvY994bOs5Jmjw" #Superhero Toons
YOUTUBE_CHANNEL_ID_6096 = "PLcZkwR3bL1rudUN5dC3kmk-lXFvhVKL0x" #DC Super Hero Girls
YOUTUBE_CHANNEL_ID_6097 = "PLETNNpXVJcZolVXkkujAOUlKbE-nkPROg" #Spawn Animated series
YOUTUBE_CHANNEL_ID_6098 = "PLuI7BiC5LyGZnYLDQ1gvCNyHX-nUm-tR-" #The Tick 1994-1996
YOUTUBE_CHANNEL_ID_6099 = "PL6fJmjt84zZgXis8FBu51yi98pL6VGDyE" #Mega Man 1994-1995
YOUTUBE_CHANNEL_ID_6100 = "PLq9lcAuzj6eHpGG5UvfHID8pG_tO3PSel" #Spiderman Animated Series 1994-1998
YOUTUBE_CHANNEL_ID_6101 = "PLIEbITAtGBeZIhsSNHSXd628UW68WWaeA" #Gargoyles Complete Animated Series
YOUTUBE_CHANNEL_ID_6102 = "PLNXCO7Z2kJDQtBXn9Xp7NZk7ksxaL53ja" #Legend of Zorro Animated Series
YOUTUBE_CHANNEL_ID_6103 = "" #
YOUTUBE_CHANNEL_ID_6104 = "PLLCcmBcBRcT9jhSlKI_ZN1GBLHIKrfmtq" #He-Man Episodes
YOUTUBE_CHANNEL_ID_6105 = "PLZyrems8ZnTaB1J7Y9oUDStxeEqgdCMC5" #X-men Animated Series
YOUTUBE_CHANNEL_ID_6106 = "PL6fJmjt84zZh1caGDR_YO66Li0IYjZRuA" #Legend of Tarzan Complete Series
YOUTUBE_CHANNEL_ID_6107 = "" #
YOUTUBE_CHANNEL_ID_6108 = "PLr_eMY8BNSHJK185dgiwyVjPP-lDqyty0" #I Dream Of Jeannie
YOUTUBE_CHANNEL_ID_6109 = "" #
YOUTUBE_CHANNEL_ID_6110 = "PLdeiBYnf0YBmnqBPCtO4mmjjP9vgQihwj" #My Favorite Martian Shows
YOUTUBE_CHANNEL_ID_6111 = "PL-imZ7QaYSSW659T3E-E1PS3cS4tnQz88" #Mork And Mindy Shows
YOUTUBE_CHANNEL_ID_6112 = "PL1V2SSERycssvC_FFdtBA16Qhiityw_ii" #Beverly Hillbillies
YOUTUBE_CHANNEL_ID_6113 = "PL7IIy_GbHHsSiVHnMNoGBZpEM2Yu4nc9r" #Dinosaurs Show
YOUTUBE_CHANNEL_ID_6114 = "PL-MmOFsNa4hca1fKDP6AcakP_J7J3n0Zb" #The Monkees Show
YOUTUBE_CHANNEL_ID_6115 = "PLEO4kyx_D0ojf3QgDpuuNwOHD9goK9obp" #Soupy Sales Show
YOUTUBE_CHANNEL_ID_6116 = "" #
YOUTUBE_CHANNEL_ID_6117 = "PLgHVXu5q5u5_9HYGBRXoZAItYqzFYuxZu" #The Three Stooges Show
YOUTUBE_CHANNEL_ID_6118 = "PLIqkENqCFrAxJCQKZKzHaYuvLF3H2utMG" #Abbott And Costello Show
YOUTUBE_CHANNEL_ID_6119 = "PLoWXPRbBO29vBJ3rhYaDoz31fSA2m1khy" #Laurel And Hardy Show
YOUTUBE_CHANNEL_ID_6120 = "" #
YOUTUBE_CHANNEL_ID_6121 = "" #
YOUTUBE_CHANNEL_ID_6122 = "" #
YOUTUBE_CHANNEL_ID_6123 = "" #
YOUTUBE_CHANNEL_ID_6124 = "" #
YOUTUBE_CHANNEL_ID_6125 = "" #
YOUTUBE_CHANNEL_ID_6126 = "UCkOxf5c1enax60y6wfB-Y6g"           #Fun Science For Kids
YOUTUBE_CHANNEL_ID_6127 = "PL25EqZUGaqcBp3MoHd4XwRr9xaiUsYuDh" #Science Docs 4 Kids
YOUTUBE_CHANNEL_ID_6128 = "PLiODxcTRLJnlEyZCD_BxB14sxpHIT0Q_H" #Learn Color With Dinosaurs
YOUTUBE_CHANNEL_ID_6129 = "PLIGCoPnpopNGUK6uUIIqmXS4C7995w4PJ" #First Knowledge About Life
YOUTUBE_CHANNEL_ID_6130 = "PLZQSY1Bbq9go8Uq80G1h_QWlGUcwh5mj9" #Dinosaur Documentary
YOUTUBE_CHANNEL_ID_6131 = "PLN_bW4ujjzkBRenjd4SDI5pL20HWger1D" #Documentary For Kids
YOUTUBE_CHANNEL_ID_6132 = "PLbXsuFCpX9EP5C8WyRzzG_sZYkX0ocjvD" #Snake: Animals For Children
YOUTUBE_CHANNEL_ID_6133 = "PLQlnTldJs0ZSjGHk8lsyV4Sdrs73wUv3Y" #Amazing Animals: Mammals
YOUTUBE_CHANNEL_ID_6134 = "PLm3P5C19OaGDcusqTrEOfh54b-bgWMyL4" #Kids Documentaries
YOUTUBE_CHANNEL_ID_6135 = "PLl1SWXhLagg9QYdFGx4rm2lhfxVab2N-O" #Planets For Kids
YOUTUBE_CHANNEL_ID_6136 = "PL_kniSK82zNIqPss6W7WnMyzKzqZbeSXD" #Cow Video For Children
YOUTUBE_CHANNEL_ID_6137 = "PLqdFn0Pb5DGJgxSpycikGTD8l4KQPiFUz" #Legends For Kids
YOUTUBE_CHANNEL_ID_6138 = "PLBb2wfVZWdBVg0HiHDWAPUdEFHNnWWAyd" #Kids: Anthropology, Archeology
YOUTUBE_CHANNEL_ID_6139 = "PLA9ewJ_ZNp7db-H124jKLTXzS2_qj8DRM" #Animal Planet: Lions
YOUTUBE_CHANNEL_ID_6140 = "PLQZxwynttskdDMlS4GImArJoJSkXLBFbc" #Universe Documentary
YOUTUBE_CHANNEL_ID_6141 = "PLnNj5Rsoa7cOOM4aUwzVcLm1GpqEd2o_l" #All About Animals For Kids
YOUTUBE_CHANNEL_ID_6142 = "PLMY7xvEDQSw6-7-iuEC2BzLUV3GQDkgde" #Education And Scientific
YOUTUBE_CHANNEL_ID_6143 = "PLqek2hmoyW1rq_uz8OV-XdwEBKr7wnaZ9" #Animal Sounds For Kids
YOUTUBE_CHANNEL_ID_6144 = "PLIivJP-g3EeQoCnJaXpzmewZJL-81khl1" #Australian Animals For Kids
YOUTUBE_CHANNEL_ID_6145 = "PLY3_aDj7uSnyXiR6LlLfRc0xIdCbZgPE-" #Paleantology For Kids
YOUTUBE_CHANNEL_ID_6146 = "PLfiOjUK3Asw4W6ZZsPVt3B9h1irdv4HQM" #Insects And Bugs For Kids
YOUTUBE_CHANNEL_ID_6147 = "PLTnArU6yP-75DA9lDwlqFjwHAV-xz__5c" #How To Draw A Bunny
YOUTUBE_CHANNEL_ID_6148 = "" #
YOUTUBE_CHANNEL_ID_6149 = "" #
YOUTUBE_CHANNEL_ID_6150 = "" #
YOUTUBE_CHANNEL_ID_6151 = "" #
YOUTUBE_CHANNEL_ID_6152 = "" #
YOUTUBE_CHANNEL_ID_6153 = "" #
YOUTUBE_CHANNEL_ID_6154 = "" #
YOUTUBE_CHANNEL_ID_6155 = "" #
YOUTUBE_CHANNEL_ID_6156 = "" #
YOUTUBE_CHANNEL_ID_6157 = "" #
YOUTUBE_CHANNEL_ID_6158 = "" #
YOUTUBE_CHANNEL_ID_6159 = "PLvj7K6jc8bjkV-Ny8MlvBh2fvI3C1tedb" #Kid Friendly Shorts
YOUTUBE_CHANNEL_ID_6160 = "PLU3DX663d_ao_XMXn3c4x6elPHAifY3K1" #Kids CGI Shorts
YOUTUBE_CHANNEL_ID_6161 = "" #
YOUTUBE_CHANNEL_ID_6162 = "PLi0oSDlYUoSzcN1Vb2aqr_gOCaE9kIQZI" #Animated Short Films
YOUTUBE_CHANNEL_ID_6163 = "PLLaMoprZv-FMYfaQq0IoRWNkoD_CsWll0" #Kid Friendly Animation Shorts
YOUTUBE_CHANNEL_ID_6164 = "PLLaMoprZv-FN6q4LdufynW-FFNZXylt4r" #Funny Animated Short Film
YOUTUBE_CHANNEL_ID_6165 = "" #
YOUTUBE_CHANNEL_ID_6166 = "" #
YOUTUBE_CHANNEL_ID_6167 = "" #
YOUTUBE_CHANNEL_ID_6168 = "" #
YOUTUBE_CHANNEL_ID_6169 = "" #
YOUTUBE_CHANNEL_ID_6170 = "" #
YOUTUBE_CHANNEL_ID_6171 = "" #

YOUTUBE_CHANNEL_ID_6210 = "PLBDSSmeWrStaomELhrftB8-gEbkuspqro" #Kids Party Music
YOUTUBE_CHANNEL_ID_6211 = "PLC5ZgnSBVcSLI3rYKWv6BRkJt0Zr9FGqV" #Cartoon Music Video
YOUTUBE_CHANNEL_ID_6212 = "PLOba6OKTJnLbDvwBBEwO1EaVsiICn8Svw" #Ultimate Disney Music
YOUTUBE_CHANNEL_ID_6213 = "PLONnQ-KywMA2ZA0YiZLXlY21z7XB5WZwy" #Kids Christian Songs
YOUTUBE_CHANNEL_ID_6214 = "PLogBXxHVJONCvMfEdN-aZHmzMomFr-nrS" #Kids Party Songs
YOUTUBE_CHANNEL_ID_6215 = "PLreSGRSRdKzaOcWunkPjfGACyQfoW8wmE" #Light Music For Kids
YOUTUBE_CHANNEL_ID_6216 = "PLuVZl03cIZ-i5JhcMZFRVXBBNkfS8U2Zo" #Soundtracks For Kids
YOUTUBE_CHANNEL_ID_6217 = "PLI-is5tEGAnSAlFFQ3fEWvQistH_KDPRV" #Kids Christmas Carols
YOUTUBE_CHANNEL_ID_6218 = "PLzvnG5xqjB97RFNH31qtLgOJpBKdiAlpa" #Kids Playtime Music
YOUTUBE_CHANNEL_ID_6219 = "PL_UCDs2ps_70UZpM2BTpCqIj3dYO3wqZw" #Kids Dance Party

YOUTUBE_CHANNEL_ID_6258 = "" #
YOUTUBE_CHANNEL_ID_6259 = "" #
YOUTUBE_CHANNEL_ID_6260 = "UCCYhvWD88Mbd2M14GqpPM9A"           #Cloud 5 Family Channel
YOUTUBE_CHANNEL_ID_6261 = "UCl-9IOhYF1yrAhPNf0hiung"           #Flix4families Channel
YOUTUBE_CHANNEL_ID_6262 = "PLCubmEMDSuQmluaYIZDXotdVmo6fDhkJb" #Family Films
YOUTUBE_CHANNEL_ID_6263 = "PLQZEwWV6kFd5W45_ZjNSh5uwrwx8CG6px" #Family Movies
YOUTUBE_CHANNEL_ID_6264 = "PLYDFQvqBzaxXbpCgN70dUX9uflYIb3p4y" #Christmas Classic Movies
YOUTUBE_CHANNEL_ID_6265 = "PL8PpfUGi1Iojrls92BF2crZ75Rvjq2t0t" #Family Movies And Shows
YOUTUBE_CHANNEL_ID_6266 = "PLwdhwq4ldnGPeuYOL9RVnKvguWfU-9n83" #Family Shows
YOUTUBE_CHANNEL_ID_6267 = "PLFmtz7CLN36lnk3qTpBe-ivi3xVmi7ian" #Children And Family Shows
YOUTUBE_CHANNEL_ID_6268 = "PLeagipoZmyflrcEm6XChXJzW8WTlrT-WH" #Family Friendly Movies
YOUTUBE_CHANNEL_ID_6269 = "PLeLlr9BUN8wNOd5o0LvBbpfaK-ZxCGtt-" #Classic Christmas Movies
YOUTUBE_CHANNEL_ID_6270 = "PLFmtz7CLN36lnk3qTpBe-ivi3xVmi7ian" #Children And Family
YOUTUBE_CHANNEL_ID_6271 = "PLsZQnDqnebk6HK71JAkgigKthwe9XvEbz" #Popcornflix Family Movies
YOUTUBE_CHANNEL_ID_6272 = "" #
YOUTUBE_CHANNEL_ID_6273 = "" #
YOUTUBE_CHANNEL_ID_6274 = "" #
YOUTUBE_CHANNEL_ID_6275 = "" #
YOUTUBE_CHANNEL_ID_6276 = "" #
YOUTUBE_CHANNEL_ID_6277 = "" #
YOUTUBE_CHANNEL_ID_6278 = "" #
YOUTUBE_CHANNEL_ID_6279 = "" #
YOUTUBE_CHANNEL_ID_6280 = "" #
YOUTUBE_CHANNEL_ID_6281 = "" #
YOUTUBE_CHANNEL_ID_6282 = "officialfranklin"                     #Official Franklin Channel
YOUTUBE_CHANNEL_ID_6283 = "UCXBW4CrtmED-tbK6Hn7SM7w"             #Dinocore TUBA Channel
YOUTUBE_CHANNEL_ID_6284 = "UCknQp_ATYj_o4_uPS3hDcTw"             #Little Kids Channel
YOUTUBE_CHANNEL_ID_6285 = "SockeyeMedia"                         #Mother Goose Club Playhouse
YOUTUBE_CHANNEL_ID_6286 = "kidszootube"                          #Fort Wayne Childrens Zoo
YOUTUBE_CHANNEL_ID_6287 = "UCzuOe5qccLzP9CQtRnFVB4w"             #McQueen Family Channel
YOUTUBE_CHANNEL_ID_6288 = "UCYmgUdthtWRCB88nqbLRDtw"             #Playtime With Twinkle
YOUTUBE_CHANNEL_ID_6289 = "UCk4yvGr6PTBjE5rgPTmjB4Q"             #Car Patrol Of Car City
YOUTUBE_CHANNEL_ID_6290 = "ChildrenGamesTV"                      #Kids Club Channel
YOUTUBE_CHANNEL_ID_6291 = "UCEPsNDUhUm-7yZhUjQQNqwQ"             #Kid Time Story Time
YOUTUBE_CHANNEL_ID_6292 = "KidsClassroom"                        #Kids Classroom Channel
YOUTUBE_CHANNEL_ID_6293 = "thekydstv"                            #The Kids Channel
YOUTUBE_CHANNEL_ID_6294 = "hooplakidz"                           #Hoopla Kids Official
YOUTUBE_CHANNEL_ID_6295 = "UC5KoD4naFFHdtt4Ecl-QD4g"             #Kids Space Official
YOUTUBE_CHANNEL_ID_6296 = "UCpQfF_qehNal4D7KpakObuA"             #DuckDuck Kids Channel
YOUTUBE_CHANNEL_ID_6297 = "UCh8kC270hiLbnjEMHEJ5ggA"             #Duda&Dada Official
YOUTUBE_CHANNEL_ID_6298 = "UCelg4wUoZziBy4D04eXgflQ"             #Annie & Ben Channel
YOUTUBE_CHANNEL_ID_6299 = "UCXVzf9SjKvF_t8GpFnVjOYQ"             #Flashback TV Kids
YOUTUBE_CHANNEL_ID_6300 = "UCUcaQ0qwS5bS1U-vGHFFUIQ"             #Flora Kids Channel
YOUTUBE_CHANNEL_ID_6301 = "UCpS-2ZXtKzq1a-APap3FKrw"             #Story Zoo Channel
YOUTUBE_CHANNEL_ID_6302 = "vids4kidstv"                          #Vids 4 Kids Channel
YOUTUBE_CHANNEL_ID_6303 = "UC49lY9F3iV3m2pe1xVaxfwg"             #WildBrain Happy Kids
YOUTUBE_CHANNEL_ID_6304 = "UCPCVFz4N7YCU24a60q1oq1A"             #Kids Show Club Channel
YOUTUBE_CHANNEL_ID_6305 = "UCNLdqhBwGzscezZwsdcm0SA"             #Superhero Kids Channel
YOUTUBE_CHANNEL_ID_6306 = "chotoonz"                             #Chotoonz TV Channel
YOUTUBE_CHANNEL_ID_6307 = "multfilm"                             #Kedoo ToonzTV Channel
YOUTUBE_CHANNEL_ID_6308 = "UCcVhzF_9HZdZpYkrQQKhtyQ"             #VHS Museum Of Cartoons
YOUTUBE_CHANNEL_ID_6309 = "MagicPetsSongs4Kids"                  #Morphle TV Channel
YOUTUBE_CHANNEL_ID_6310 = "MonsterHigh"                          #Monster High Channel
YOUTUBE_CHANNEL_ID_6311 = "firemansamchannel"                    #Fireman Sam Channel
YOUTUBE_CHANNEL_ID_6312 = "HOTWHEELS"                            #Hot Wheels Channel
YOUTUBE_CHANNEL_ID_6313 = "OfficialPawPatrol"                    #Paw Patrol Channel
YOUTUBE_CHANNEL_ID_6314 = "theofficialpeppa"                     #Peppa Pig Channel
YOUTUBE_CHANNEL_ID_6315 = "UC6zhI71atP7YLoZyIyCIGNw"             #Dave N Ava Channel
YOUTUBE_CHANNEL_ID_6316 = "UCB2aeGGPNj7l5Z71bYNqX-Q"             #Woody Woodpecker Channel
YOUTUBE_CHANNEL_ID_6317 = "UCPM69g6gEGR7hd3hs2p89og"             #Hoopla Kidz Toons Channel
YOUTUBE_CHANNEL_ID_6318 = "gbadgi"                               #CodeName Kids Next Door
YOUTUBE_CHANNEL_ID_6319 = "theofficialbenholly"                  #Ben N Holly Little Kingdom
YOUTUBE_CHANNEL_ID_6320 = "UC9Rrqn5sjdZkReS1lkT-USg"             #Oddbods Cartoon Channel
YOUTUBE_CHANNEL_ID_6321 = "Larva2011ani"                         #Larva TUBA Channel
YOUTUBE_CHANNEL_ID_6322 = "bananasinpyjamas"                     #Bananas In Pyjamas Channel
YOUTUBE_CHANNEL_ID_6323 = "mrbeancartoonworld"                   #Mr. Bean Cartoon World
YOUTUBE_CHANNEL_ID_6324 = "UCInXezQxpWgrd7uPKeA6gPQ"             #Powerpuff Girls Channel
YOUTUBE_CHANNEL_ID_6325 = "" #
YOUTUBE_CHANNEL_ID_6326 = "nickelodeonjuniorfr"                  #Nick Jr. Kids Channel
YOUTUBE_CHANNEL_ID_6327 = "cartoonnetwork"                       #Cartoon Network Channel
YOUTUBE_CHANNEL_ID_6328 = "UCZ6jURNr1WQZCNHF0ao-c0g"             #Universal Kids Channel
YOUTUBE_CHANNEL_ID_6329 = "UCrNnk0wFBnCS1awGjq_ijGQ"             #PBS Kids Channel
YOUTUBE_CHANNEL_ID_6330 = "UCMt032tr4fOP9NTffiU_oJw"             #DC Kids Official Channel
YOUTUBE_CHANNEL_ID_6331 = "UC9trsD1jCTXXtN3xIOIU8gg"             #WB Kids Official Channel
YOUTUBE_CHANNEL_ID_6332 = "kidscbc"                              #CBC Kids Channel
YOUTUBE_CHANNEL_ID_6333 = "MarvelUK"                             #Marvel UK Channel
YOUTUBE_CHANNEL_ID_6334 = "MARVEL"                               #Marvel Entertainment
YOUTUBE_CHANNEL_ID_6335 = "disneyjunior"                         #Disney Junior Channel
YOUTUBE_CHANNEL_ID_6336 = "cbeebiesgrownups"                     #CBeebies Channel
YOUTUBE_CHANNEL_ID_6337 = "" #
YOUTUBE_CHANNEL_ID_6338 = "" #
YOUTUBE_CHANNEL_ID_6339 = "" #
YOUTUBE_CHANNEL_ID_6340 = "" #
YOUTUBE_CHANNEL_ID_6341 = "" #
YOUTUBE_CHANNEL_ID_6342 = "" #
YOUTUBE_CHANNEL_ID_6343 = "" #
YOUTUBE_CHANNEL_ID_6344 = "" #
YOUTUBE_CHANNEL_ID_6345 = "" #
YOUTUBE_CHANNEL_ID_6346 = "" #
YOUTUBE_CHANNEL_ID_6347 = "" #
YOUTUBE_CHANNEL_ID_6348 = "" #
YOUTUBE_CHANNEL_ID_6349 = "" #
YOUTUBE_CHANNEL_ID_6350 = "hrlmglobetrotters"                    #Harlem Globetrotters
YOUTUBE_CHANNEL_ID_6351 = "" #


@route(mode='kidzclub_animation')
def Kidzclub_Animation():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Halloween Specials[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6053+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Christmas Specials[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6054+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Toon Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6023+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Shows And Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6058+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Shorts And Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6059+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Shows And Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6060+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]80s Cartoon Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6037+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Films For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6067+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Christian Animated Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6068+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Short Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6069+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Easter Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6070+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Comedy Cartoon Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6062+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Looney Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6052+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superhero Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6094+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superhero Toons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6095+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6003+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kid Friendly Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6159+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids CGI Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6160+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animated Short Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6162+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Funny Animated Short Film[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6164+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kid Friendly Animation Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6163+"/", folder=True,
		icon=mediapath+"kidzclub_animation.png", fanart=fanart)
		
	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)

@route(mode='kidzclub_docs')
def Kidzclub_Docs():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Fun Science For Kids[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6126+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Science Docs For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6127+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Learn Color With Dinosaurs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6128+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]First Knowledge About Life[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6129+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dinosaur Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6130+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Documentary For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6131+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Snake: Animals For Children[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6132+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Amazing Animals: Mammals[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6133+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]Kids Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6134+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Planets For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6135+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]Cow Video For Children[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6136+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Legends For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6137+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Kids: Anthropology, Archeology[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6138+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Animal Planet: Lions[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6139+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Universe Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6140+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All About Animals For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6141+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Education And Scientific[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6142+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animal Sounds For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6143+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Australian Animals For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6144+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Paleantology For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6145+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Insects And Bugs For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6146+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]How To Draw A Bunny[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6147+"/", folder=True,
		icon=mediapath+"kidzclub_docs.png", fanart=fanart)
		
	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)

@route(mode='kidzclub_family')
def Kidzclub_Family():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Fort Wayne Childrens Zoo[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6286+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cloud 5 Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6260+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Flix4families Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6261+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Family Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6262+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Family Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6263+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Christmas Classic Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6264+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Family Movies And Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6265+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Family Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6266+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Children And Family Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6267+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Family Friendly Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6268+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Christmas Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6269+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Children And Family[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6270+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Popcornflix Family Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6271+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Vids 4 Kids Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6302+"/", folder=True,
		icon=mediapath+"kidzclub_family.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)

@route(mode='kidzclub_comedy')
def Kidzclub_Comedy():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Laurel And Hardy[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6119+"/", folder=True,
		icon=mediapath+"kidzclub_comedy.png", fanart=fanart)
	Add_Dir(
		name="[COLOR white][B]Abbott And Costello[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6118+"/", folder=True,
		icon=mediapath+"kidzclub_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Three Stooges[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6117+"/", folder=True,
		icon=mediapath+"kidzclub_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Soupy Sales Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6115+"/", folder=True,
		icon=mediapath+"kidzclub_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Monkees[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6114+"/", folder=True,
		icon=mediapath+"kidzclub_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dinosaurs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6113+"/", folder=True,
		icon=mediapath+"kidzclub_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Beverly Hillbillies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6112+"/", folder=True,
		icon=mediapath+"kidzclub_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mork And Mindy[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6111+"/", folder=True,
		icon=mediapath+"kidzclub_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]My Favorite Martian[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6110+"/", folder=True,
		icon=mediapath+"kidzclub_comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]I Dream Of Jeannie[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6108+"/", folder=True,
		icon=mediapath+"kidzclub_comedy.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)

@route(mode='kidzclub_cartoons')
def Kidzclub_Cartoons():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	Add_Dir(
		name="[COLOR white][B]VHS Museum Of Cartoons[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6308+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mr. Bean Cartoon World[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6323+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Looney Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6052+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Casper The Friendly Ghost[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6056+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Comedy Cartoon Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6062+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6016+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Looney Toons Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6005+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6003+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superhero cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6094+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superhero Toons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6095+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mighty Mouse[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6091+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Mighty Mouse[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6092+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Abbott And Costello[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6065+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Three Stooges[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6066+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Oggy And The Cockroaches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6006+"/", folder=True,
		icon=mediapath+"kidzclub_cartoons.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)
	
@route(mode='kidzclub_heroes')
def Kidzclub_Heroes():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	Add_Dir( 
		name="[COLOR white][B]DC Super Hero Girls[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6096+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Justice League Animated[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6082+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Spiderman Animated 94-98[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6100+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Legend of Zorro Animated [/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6102+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Tick 1994-1996[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6098+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]X-men Animated Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6105+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Scifi: Space Angel[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6084+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Superhero Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6094+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sci-fi: Astro Boy[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6086+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Mighty Mouse Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6092+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Underdog Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6093+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Superhero Toons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6095+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Godzilla The Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6083+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Ghostbusters[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6088+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Buzz Lightyear[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6089+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Sonic The Hedgehog[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6090+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Spawn Animated[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6097+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mega Man[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6099+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Gargoyles Animated[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6101+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]He-Man Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6104+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Legend Of Tarzan[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6106+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Superhero Kids[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6305+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Powerpuff Girls[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6324+"/", folder=True,
		icon=mediapath+"kidzclub_heroes.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)

@route(mode='kidzclub_channels')
def Kidzclub_Channels():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Larva TUBA Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6321+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)
	Add_Dir(
		name="[COLOR white][B]Oddbods Cartoon Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6320+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]CodeName Kids Next Door[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6318+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Woody Woodpecker Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6316+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dave N Ava Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6315+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Paw Patrol Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6313+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hot Wheels Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6312+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fireman Sam Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6311+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Monster High Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6310+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Morphle TV Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6309+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kedoo ToonzTV Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6307+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Chotoonz TV Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6306+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Show Club Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6304+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WildBrain Happy Kids[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6303+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Flora Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6300+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Flashback TV Kids[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6299+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Annie & Ben Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6298+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Duda&Dada Official[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6297+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DuckDuck Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6296+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Space Official[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6295+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]The Kids Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6293+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Kid Time Story Time[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6291+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Car Patrol Of Car City[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6289+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]McQueen Family Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6287+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dinocore TUBA Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6283+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Official Franklin Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6282+"/", folder=True,
		icon=mediapath+"kidzclub_channels.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)

@route(mode='kidzclub_toddlers')
def Kidzclub_Toddlers():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Busy Beavers Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6025+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Treehouse Direct Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6030+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Little Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6284+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mother Goose Playhouse[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6285+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Peppa Pig Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6314+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Story Zoo Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6301+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Classroom Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6292+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Playtime With Twinkle[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6288+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Official Pat & Stan[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6026+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Tractor Tom[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6027+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]HUMF Official[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6028+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Max & Ruby[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6029+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hoopla Kids Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6294+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hoopla Kidz Toons[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6317+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]TuTiTu TV[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6033+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Yo Gabba Gabba[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6034+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Little Baby Bum[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6035+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Little Bear[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6036+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Oh My Genius[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6032+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bananas In Pyjamas[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6322+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fifi & The Flowertots[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6039+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Postman Pat Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6040+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Olivia The Pig[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6041+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Little Charlie Bear[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6042+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]VeggieTales Shows[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6043+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Strawberry Shortcake[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6044+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Noddy In Toyland[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6045+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ben & Holly Little Kingdom[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6319+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Kids Club[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6290+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Giggle Bellies[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6038+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Fluffy Jet Toys[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6031+"/", folder=True,
		icon=mediapath+"kidzclub_toddlers.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)

@route(mode='kidzclub_music')
def Kidzclub_Music():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Party Music[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6210+"/", folder=True,
		icon=mediapath+"kidzclub_music.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Cartoon Music Video[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6211+"/", folder=True,
		icon=mediapath+"kidzclub_music.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Ultimate Disney Music[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6212+"/", folder=True,
		icon=mediapath+"kidzclub_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Christian Songs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6213+"/", folder=True,
		icon=mediapath+"kidzclub_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Party Songs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6214+"/", folder=True,
		icon=mediapath+"kidzclub_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Light Music For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6215+"/", folder=True,
		icon=mediapath+"kidzclub_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Soundtracks For Kids[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6216+"/", folder=True,
		icon=mediapath+"kidzclub_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Christmas Carols[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6217+"/", folder=True,
		icon=mediapath+"kidzclub_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Playtime Music[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6218+"/", folder=True,
		icon=mediapath+"kidzclub_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Dance Party[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6219+"/", folder=True,
		icon=mediapath+"kidzclub_music.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)
	
@route(mode='kidzclub_western')
def Kidzclub_Western():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Roy Rodgers Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6072+"/", folder=True,
		icon=mediapath+"kidzclub_western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]The Lone Ranger[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6073+"/", folder=True,
		icon=mediapath+"kidzclub_western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]The Rifleman[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6075+"/", folder=True,
		icon=mediapath+"kidzclub_western.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Westerns: John Wayne[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6074+"/", folder=True,
		icon=mediapath+"kidzclub_western.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]My Friend Flicka[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6077+"/", folder=True,
		icon=mediapath+"kidzclub_western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Annie Oakley[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6078+"/", folder=True,
		icon=mediapath+"kidzclub_western.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Gunsmoke[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6076+"/", folder=True,
		icon=mediapath+"kidzclub_western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Disneys Zorro[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6080+"/", folder=True,
		icon=mediapath+"kidzclub_western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Animated Lone Ranger[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_6079+"/", folder=True,
		icon=mediapath+"kidzclub_western.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)
	
@route(mode='kidzclub_networks')
def Kidzclub_Networks():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Nick Jr. Kids Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6326+"/", folder=True,
		icon=mediapath+"kidzclub_network.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Cartoon Network Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6327+"/", folder=True,
		icon=mediapath+"kidzclub_network.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Universal Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6328+"/", folder=True,
		icon=mediapath+"kidzclub_network.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PBS Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6329+"/", folder=True,
		icon=mediapath+"kidzclub_network.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DC Kids Official Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6330+"/", folder=True,
		icon=mediapath+"kidzclub_network.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]WB Kids Official Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_6331+"/", folder=True,
		icon=mediapath+"kidzclub_network.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]CBC Kids Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6332+"/", folder=True,
		icon=mediapath+"kidzclub_network.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Marvel UK Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6333+"/", folder=True,
		icon=mediapath+"kidzclub_network.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Marvel Entertainment[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6334+"/", folder=True,
		icon=mediapath+"kidzclub_network.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Disney Junior Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6335+"/", folder=True,
		icon=mediapath+"kidzclub_network.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]CBeebies Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_6336+"/", folder=True,
		icon=mediapath+"kidzclub_network.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param
		
def add_link_info(name, iconimage, fanart):
	u = sys.argv[0] + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'false') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz) 

def addDirMain(name,url,zmode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&zmode="+str(zmode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def regex_get_all(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r


def get_setting(setting):
    return addon.getSetting(setting)


def set_setting(setting, string):
    return addon.setSetting(setting, string)


def get_string(string_id):
    return addon.getLocalizedString(string_id)

#xbmcplugin.endOfDirectory(plugin_handle)
