# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

import movies
import tromaGenres

from resources.lib.modules.common import *
from resources.lib.modules.docula import *
from resources.lib.modules.bfingers import *
from resources.lib.modules.diyfix import *
from resources.lib.modules.animate import *
from resources.lib.modules.kidzclub import *
from resources.lib.modules.super import *
from resources.lib.modules.sportz import *
from resources.lib.modules.moviechannels import *
from resources.lib.modules.troma import *
from resources.lib.modules.showVID import *

#from resources.lib.modules.movies import *
#from resources.lib.modules.tromaGenres import *

params = get_params()
mode = None

debug        = Addon_Setting(setting='debug')       
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.j1tv')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'
genreImage = 'special://home/addons/script.module.jhm/lib/resources/images/genres/'
path   = xbmcaddon.Addon().getAddonInfo('path').decode("utf-8")

@route(mode='main')
def Main():

	add_link_info('[B][COLORorange]=== J1TV ===[/COLOR][/B]', icon, fanart)
	
	addDirMain('[COLOR white][B]Butter Fingers[/B][/COLOR]',BASE,506,mediapath+'bfingers.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Troma Movies[/B][/COLOR]',BASE,507,mediapath+'troma.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate[/B][/COLOR]',BASE,504,mediapath+'animate.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Channels[/B][/COLOR]',BASE,510,mediapath+'channels.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Docula[/B][/COLOR]',BASE,502,mediapath+'docula.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Kidz Club[/B][/COLOR]',BASE,505,mediapath+'kidzclub.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Super Flix[/B][/COLOR]',BASE,508,mediapath+'super-icon.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sportz[/B][/COLOR]',BASE,509,mediapath+'sportz.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]DIY Fix[/B][/COLOR]',BASE,503,mediapath+'diyfix.png',mediapath+'fanart.jpg')
	
	add_link_info('[B][COLOR white] [/COLOR][/B]', icon, fanart)

@route(mode='bfingers_main')
def Bfingers_main():

	add_link_info('[B][COLORorange]== BUTTER FINGERS ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)
	
	addDirMain('[COLOR white][B]Featured Movies[/B][/COLOR]',BASE,404,mediapath+'featured.png',fanart)
	addDirMain('[COLOR white][B]Troma Movies[/B][/COLOR]',BASE,704,genreImage+'tromared.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Action Movies[/B][/COLOR]',BASE,0,mediapath+'action.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Animation Movies[/B][/COLOR]',BASE,1,mediapath+'animation.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Classic Movies[/B][/COLOR]',BASE,2,mediapath+'classic.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Comedy, Romance Movies[/B][/COLOR]',BASE,3,mediapath+'comedy.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Crime, Mystery, Noir, Movies[/B][/COLOR]',BASE,4,mediapath+'crime.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentaries[/B][/COLOR]',BASE,5,mediapath+'docs.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Drama & War Movies[/B][/COLOR]',BASE,6,mediapath+'drama.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Family, Animated, Anime Movies[/B][/COLOR]',BASE,7,mediapath+'family.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Horror Movies[/B][/COLOR]',BASE,8,mediapath+'horror.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Movie Mix[/B][/COLOR]',BASE,9,mediapath+'movie_mix.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Music Video[/B][/COLOR]',BASE,10,mediapath+'music.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Scifi Movies[/B][/COLOR]',BASE,11,mediapath+'scifi.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports, Games, Docs, Movies[/B][/COLOR]',BASE,12,mediapath+'sports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Toddler Video[/B][/COLOR]',BASE,13,mediapath+'toddlers.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Western Movies[/B][/COLOR]',BASE,14,mediapath+'western.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Playlist By Year[/B][/COLOR]',BASE,15,mediapath+'years.png',mediapath+'fanart.jpg')
	
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

@route(mode='BFgenrelist')
def BFgenreList():

	add_link_info('[B][COLORorange]== Choose Genre ==[/COLOR][/B]', genreImage+'GenreLogo.png', fanart)
	
	addDirMain('[COLOR white][B]All Movies[/B][/COLOR]',BASE,403,genreImage+'All.png', fanart)
	addDirMain('[COLOR white][B]Action Movies[/B][/COLOR]',BASE,410,genreImage+'Action.png', fanart)
	addDirMain('[COLOR white][B]Anime Movies[/B][/COLOR]',BASE,426,genreImage+'Anime.png', fanart)
	addDirMain('[COLOR white][B]Classic Movies[/B][/COLOR]',BASE,412,genreImage+'Classic.png', fanart)
	addDirMain('[COLOR white][B]Comedy Movies[/B][/COLOR]',BASE,413,genreImage+'Comedy.png', fanart)
	addDirMain('[COLOR white][B]Crime Movies[/B][/COLOR]',BASE,414,genreImage+'Crime.png', fanart)
	addDirMain('[COLOR white][B]Documentaries[/B][/COLOR]',BASE,415,genreImage+'Documentary.png', fanart)
	addDirMain('[COLOR white][B]Drama Movies[/B][/COLOR]',BASE,416,genreImage+'Drama.png', fanart)
	addDirMain('[COLOR white][B]Family Movies[/B][/COLOR]',BASE,417,genreImage+'Family.png', fanart)
	addDirMain('[COLOR white][B]Fantasy Movies[/B][/COLOR]',BASE,418,genreImage+'Fantasy.png', fanart)
	addDirMain('[COLOR white][B]Horror Movies[/B][/COLOR]',BASE,419,genreImage+'Horror.png', fanart)
	addDirMain('[COLOR white][B]Music Movies[/B][/COLOR]',BASE,420,genreImage+'Music.png', fanart)
	addDirMain('[COLOR white][B]Mystery Movies[/B][/COLOR]',BASE,427,genreImage+'Mystery.png', fanart)
	addDirMain('[COLOR white][B]Scifi Movies[/B][/COLOR]',BASE,421,genreImage+'Scifi.png', fanart)
	addDirMain('[COLOR white][B]Sports Movies[/B][/COLOR]',BASE,422,genreImage+'Sports.png', fanart)
	addDirMain('[COLOR white][B]Thriller Movies[/B][/COLOR]',BASE,423,genreImage+'Thriller.png', fanart)
	addDirMain('[COLOR white][B]Western Movies[/B][/COLOR]',BASE,424,genreImage+'Western.png', fanart)
	addDirMain('[COLOR white][B]Zombie Movies[/B][/COLOR]',BASE,425,genreImage+'Zombie.png', fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', genreImage+'GenreLogo.png', fanart)

@route(mode='sports_main')
def Sports_main():

	add_link_info('[B][COLORorange]== Sportz ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Live Sports[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3573+"/", folder=True,
		icon=mediapath+"LiveSports.png", fanart=mediapath+'fanart.jpg')
	
	addDirMain('[COLOR white][B]Game Sports[/B][/COLOR]',BASE,100,mediapath+'GameSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Motor Sports[/B][/COLOR]',BASE,101,mediapath+'motorsports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Euro Sports[/B][/COLOR]',BASE,103,mediapath+'eurosports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Womens Sports[/B][/COLOR]',BASE,104,mediapath+'WomensSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Womens Wrestling[/B][/COLOR]',BASE,105,mediapath+'WomansWrestling.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports: Wrestling[/B][/COLOR]',BASE,106,mediapath+'SportsWrestling.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports Documentaries[/B][/COLOR]',BASE,107,mediapath+'DocsSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports: Fishing[/B][/COLOR]',BASE,108,mediapath+'fishing.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Combat Sports[/B][/COLOR]',BASE,109,mediapath+'combat.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports: Hunting[/B][/COLOR]',BASE,102,mediapath+'hunting.png',mediapath+'fanart.jpg')
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

@route(mode='channels_main')
def Channels_main():

	add_link_info('[B][COLORorange]== Channels ==[/COLOR][/B]', mediapath+'channels.png', fanart)
	addDirMain('[COLOR white][B]Live Channels[/B][/COLOR]',BASE,120,mediapath+'channels-live.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Horror Channels[/B][/COLOR]',BASE,110,mediapath+'channels-horror.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sci-fi Channels[/B][/COLOR]',BASE,111,mediapath+'channels-scifi.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Family Channels[/B][/COLOR]',BASE,118,mediapath+'channels-family.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Anime Channels[/B][/COLOR]',BASE,114,mediapath+'channels-anime.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports Channels[/B][/COLOR]',BASE,117,mediapath+'channels-sports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Wrestling Channels[/B][/COLOR]',BASE,122,mediapath+'channels-wrestling.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Animation Channels[/B][/COLOR]',BASE,119,mediapath+'channels-animation.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary Channels[/B][/COLOR]',BASE,115,mediapath+'channels-docs.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Classic Movie Channels[/B][/COLOR]',BASE,116,mediapath+'channels-classic.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Mixed Movie Channels[/B][/COLOR]',BASE,113,mediapath+'channels-mixed.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Music Channels[/B][/COLOR]',BASE,121,mediapath+'channels-music.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]By Year Playlists[/B][/COLOR]',BASE,112,mediapath+'channels-years.png',mediapath+'fanart.jpg')
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)

@route(mode='super_main')
def Super_main():

	add_link_info('[B][COLORorange]== Super Flix ==[/COLOR][/B]', mediapath+'super-icon.png', fanart)
	addDirMain('[COLOR white][B]Marvel Comics[/B][/COLOR]',BASE,81,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]DC Comics[/B][/COLOR]',BASE,82,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]More Supers[/B][/COLOR]',BASE,83,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Super Channels[/B][/COLOR]',BASE,89,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Other Superheroes[/B][/COLOR]',BASE,92,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Super Documentary[/B][/COLOR]',BASE,90,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Super Fan Films[/B][/COLOR]',BASE,84,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Classic Super Serials[/B][/COLOR]',BASE,87,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]PJ Masks Cartoons[/B][/COLOR]',BASE,91,mediapath+'super.png',mediapath+'fanart.jpg')
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'super-icon.png', fanart)

@route(mode='troma_main')
def Troma_main():

	add_link_info('[B][COLORorange]== Troma Films ==[/COLOR][/B]', mediapath+'troma.png', fanart)

	addDirMain('[COLOR white][B]Troma: All Movies[/B][/COLOR]',BASE,703,mediapath+'troma.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Troma: Genre Listing[/B][/COLOR]',BASE,704,mediapath+'troma.png',mediapath+'fanart.jpg')

	Add_Dir(
		name="[COLOR white][B]Troma Crusaders[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_19200+"/", folder=True,
		icon=mediapath+"troma.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Tromazing Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_19201+"/", folder=True,
		icon=mediapath+"troma.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Your Own Filmmaking[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_19202+"/", folder=True,
		icon=mediapath+"troma.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Tromas Buried Treasure[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_19203+"/", folder=True,
		icon=mediapath+"troma.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Uncle LLoydies Diary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_19204+"/", folder=True,
		icon=mediapath+"troma.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'troma.png', fanart)

@route(mode='genrelist')
def tromaList():

	add_link_info('[B][COLORorange]== Choose Genre ==[/COLOR][/B]', mediapath+'troma.png', fanart)
	
	addDirMain('[COLOR white][B]Troma: All Movies[/B][/COLOR]',BASE,703,genreImage+'All.png', fanart)
	addDirMain('[COLOR white][B]Troma: Action Movies[/B][/COLOR]',BASE,710,genreImage+'Action.png', fanart)
	addDirMain('[COLOR white][B]Troma: Comedy Movies[/B][/COLOR]',BASE,711,genreImage+'Comedy.png', fanart)
	addDirMain('[COLOR white][B]Troma: Crime Movies[/B][/COLOR]',BASE,712,genreImage+'Crime.png', fanart)
	addDirMain('[COLOR white][B]Troma: Docs Movies[/B][/COLOR]',BASE,713,genreImage+'Documentary.png', fanart)
	addDirMain('[COLOR white][B]Troma: Fantasy Movies[/B][/COLOR]',BASE,714,genreImage+'Fantasy.png', fanart)
	addDirMain('[COLOR white][B]Troma: Horror Movies[/B][/COLOR]',BASE,715,genreImage+'Horror.png', fanart)
	addDirMain('[COLOR white][B]Troma: Music Movies[/B][/COLOR]',BASE,716,genreImage+'Music.png', fanart)
	addDirMain('[COLOR white][B]Troma: Scifi Movies[/B][/COLOR]',BASE,717,genreImage+'Scifi.png', fanart)
	addDirMain('[COLOR white][B]Troma: Thriller Movies[/B][/COLOR]',BASE,718,genreImage+'Thriller.png', fanart)
	addDirMain('[COLOR white][B]Troma: Zombies Movies[/B][/COLOR]',BASE,719,genreImage+'Zombie.png', fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'troma.png', fanart)

@route(mode='diyfix_main')
def Diyfix_main():

	add_link_info('[B][COLORorange]=== DIY FIX ===[/COLOR][/B]', mediapath+'diyfix.png', fanart)
	
	addDirMain('[COLOR white][B]Fix Musical Instruments[/B][/COLOR]',BASE,44,mediapath+'diy_musical.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sm. Appliance Repair[/B][/COLOR]',BASE,41,mediapath+'diy_gadgets.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Appliance Repair[/B][/COLOR]',BASE,42,mediapath+'diy_appliance.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Lawnmower Repair[/B][/COLOR]',BASE,45,mediapath+'diy_lawn.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Home Repair And More[/B][/COLOR]',BASE,46,mediapath+'diy_home.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Electronics Repair[/B][/COLOR]',BASE,47,mediapath+'diy_electronics.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Gardening And More[/B][/COLOR]',BASE,43,mediapath+'diy_garden.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Automotive Repair[/B][/COLOR]',BASE,48,mediapath+'diy_auto.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Pets Info And Tips[/B][/COLOR]',BASE,49,mediapath+'diy_pets.png',mediapath+'fanart.jpg')

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'diyfix.png', fanart)

@route(mode='docula_main')
def Docula_main():

	add_link_info('[B][COLORorange]== Docula ==[/COLOR][/B]', mediapath+'docula.png', fanart)
	
	addDirMain('[COLOR white][B]Documentary: Channels[/B][/COLOR]',BASE,22,mediapath+'docula_channels.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary: Crime[/B][/COLOR]',BASE,20,mediapath+'docula_crime.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary: History[/B][/COLOR]',BASE,21,mediapath+'docula_history.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary: For Kids[/B][/COLOR]',BASE,30,mediapath+'docula_kids.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary: Music[/B][/COLOR]',BASE,23,mediapath+'docula_music.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary: Mystery[/B][/COLOR]',BASE,24,mediapath+'docula_mystery.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary: Nature[/B][/COLOR]',BASE,25,mediapath+'docula_nature.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary: Scary[/B][/COLOR]',BASE,26,mediapath+'docula_scary.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary: Space[/B][/COLOR]',BASE,27,mediapath+'docula_space.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary: Sports[/B][/COLOR]',BASE,28,mediapath+'docula_sports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary: UFO[/B][/COLOR]',BASE,29,mediapath+'docula_ufo.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary: Wildlife[/B][/COLOR]',BASE,292,mediapath+'docula_wild.png',mediapath+'fanart.jpg')

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'docula.png', fanart)

@route(mode='animate_main')
def Animate_main():

	add_link_info('[B][COLORorange]== Ani-mate ==[/COLOR][/B]', mediapath+'animate.png', fanart)
	
	addDirMain('[COLOR white][B]Ani-mate: Toddlers[/B][/COLOR]',BASE,59,mediapath+'animate_toddlers.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Kids[/B][/COLOR]',BASE,50,mediapath+'animate_kids.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Anime[/B][/COLOR]',BASE,51,mediapath+'animate_anime.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Mixed[/B][/COLOR]',BASE,52,mediapath+'animate_mixed.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Scifi[/B][/COLOR]',BASE,53,mediapath+'animate_scifi.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Comedy[/B][/COLOR]',BASE,54,mediapath+'animate_comedy.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Heroes[/B][/COLOR]',BASE,55,mediapath+'animate_heroes.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Movies[/B][/COLOR]',BASE,56,mediapath+'animate_movies.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Action[/B][/COLOR]',BASE,57,mediapath+'animate_action.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Cartoons[/B][/COLOR]',BASE,58,mediapath+'animate_cartoons.png',mediapath+'fanart.jpg')

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'animate.png', fanart)

@route(mode='kidzclub_main')
def Kidzclub_main():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	addDirMain('[COLOR white][B]Kids Channels[/B][/COLOR]',BASE,695,mediapath+'kidzclub_channels.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Kids Network Channels[/B][/COLOR]',BASE,685,mediapath+'kidzclub_network.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Comedy Shows, Movies[/B][/COLOR]',BASE,63,mediapath+'kidzclub_comedy.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Kids Documentaries[/B][/COLOR]',BASE,65,mediapath+'kidzclub_docs.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Family Movies, Shows[/B][/COLOR]',BASE,67,mediapath+'kidzclub_family.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Heroes For Kids[/B][/COLOR]',BASE,68,mediapath+'kidzclub_heroes.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Kids Music Video[/B][/COLOR]',BASE,69,mediapath+'kidzclub_music.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Shows For Toddlers[/B][/COLOR]',BASE,64,mediapath+'kidzclub_toddlers.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Animation Movies, Shorts[/B][/COLOR]',BASE,61,mediapath+'kidzclub_animation.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Cartoons For Kids[/B][/COLOR]',BASE,62,mediapath+'kidzclub_cartoons.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Western Movies, Shows[/B][/COLOR]',BASE,66,mediapath+'kidzclub_western.png',mediapath+'fanart.jpg')

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)

#==============================================================================================

def addLink(name, url, zmode, iconimage, fanart):
        liz=xbmcgui.ListItem(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={"Title": name})		
        liz.setProperty('fanart_image', fanart)
        liz.setProperty('IsPlayable', 'true')
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&zmode="+str(zmode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)		
        return ok		

def add_link_info(name, iconimage, fanart):
	u = sys.argv[0] + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'false') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz) 

def addDirMain(name,url,zmode,iconimage,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&zmode="+str(zmode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

#==============================================================================================
		
params=get_params()
url=None
name=None
mode = None
iconimage=None
zmode=None
description=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        zmode=int(params["zmode"])
except:
        pass
print "Zmode: "+str(zmode)
print "URL: "+str(url)
print "Name: "+str(name)

#====== Bfingers ======

if zmode == 0:
	Action()
		
elif zmode == 1:
	Animation()		
		
elif zmode == 2:
	Classic()

elif zmode == 3:
	Comedy()
	
elif zmode == 4:
	Crime()

elif zmode == 5:
	Docs()

elif zmode == 6:
	Drama()

elif zmode == 7:
	Family()
	
elif zmode == 8:
	Horror()

elif zmode == 9:
	Movie_Mix()

elif zmode == 10:
	Music()

elif zmode == 11:
	Scifi()
	
elif zmode == 12:
	Sports()
	
elif zmode == 13:
	Toddlers()

elif zmode == 14:
	Western()

elif zmode == 15:
	Bfingers_Playlists()

#======= DOCULA =======

elif zmode == 20:
	CrimeDoc()
		
elif zmode == 21:
	History()		
		
elif zmode == 22:
	Docula_Channels()

elif zmode == 23:
	MusicDoc()
	
elif zmode == 24:
	Mystery()

elif zmode == 25:
	Nature()

elif zmode == 26:
	Scary()

elif zmode == 27:
	Space()
	
elif zmode == 28:
	Docula_sports()

elif zmode == 29:
	UFO()

elif zmode == 292:
	Docula_Wild()

elif zmode == 30:
	Docula_kids()
	
#===== DIY FIX =====

elif zmode == 41:
	Gadgets()		
		
elif zmode == 42:
	Appliance()

elif zmode == 43:
	Garden()
	
elif zmode == 44:
	DIY_Musical()

elif zmode == 45:
	Lawn()

elif zmode == 46:
	Home()

elif zmode == 47:
	Electronics()
	
elif zmode == 48:
	Auto()

elif zmode == 49:
	Pets()

#===== ANI-MATE =====

elif zmode == 50:
	Animate_Kids()
		
elif zmode == 51:
	Animate_Anime()		
		
elif zmode == 52:
	Animate_Mixed()

elif zmode == 53:
	Animate_Scifi()
	
elif zmode == 54:
	Animate_Comedy()

elif zmode == 55:
	Animate_Heroes()

elif zmode == 56:
	Animate_Movies()

elif zmode == 57:
	Animate_Action()
	
elif zmode == 58:
	Animate_Cartoons()

elif zmode == 59:
	Animate_Toddlers()

elif zmode == 60:
	Animate_Music()

#===== KIDZ CLUB =====
		
elif zmode == 61:
	Kidzclub_Animation()		
	
elif zmode == 62:
	Kidzclub_Cartoons()

elif zmode == 63:
	Kidzclub_Comedy()
	
elif zmode == 64:
	Kidzclub_Toddlers()

elif zmode == 65:
	Kidzclub_Docs()
	
elif zmode == 66:
	Kidzclub_Western()

elif zmode == 67:
	Kidzclub_Family()
	
elif zmode == 68:
	Kidzclub_Heroes()

elif zmode == 69:
	Kidzclub_Music()

elif zmode == 685:
	Kidzclub_Networks()

elif zmode == 695:
	Kidzclub_Channels()

#=====TROMA======

elif zmode == 32:
	tromadocs()

elif zmode == 33:
	Songs()

elif zmode == 34:
	Kids_music()
	
elif zmode == 35:
	troma_musical()
	
elif zmode == 36:
	tromaTV()
	
elif zmode == 37:
	Rock_Channels()
	
elif zmode == 38:
	Rap_Channels()
	
elif zmode == 39:
	troma_Video()

#===============

elif zmode == 703:
    tromaGenres.TromaListing.Genres("All")
	
elif zmode == 704:
    tromaList()

#===============

elif zmode == 710:
    tromaGenres.TromaListing.Genres("Action")

elif zmode == 711:
    tromaGenres.TromaListing.Genres("Comedy")

elif zmode == 712:
    tromaGenres.TromaListing.Genres("Crime")

elif zmode == 713:
    tromaGenres.TromaListing.Genres("Docs")

elif zmode == 714:
    tromaGenres.TromaListing.Genres("Fantasy")

elif zmode == 715:
    tromaGenres.TromaListing.Genres("Horror")

elif zmode == 716:
    tromaGenres.TromaListing.Genres("Music")

elif zmode == 717:
    tromaGenres.TromaListing.Genres("Scifi")

elif zmode == 718:
    tromaGenres.TromaListing.Genres("Thriller")

elif zmode == 719:
    tromaGenres.TromaListing.Genres("Zombie")

#=====Super======
		
elif zmode == 81:
	Marvel()		
		
elif zmode == 82:
	DC()

elif zmode == 83:
	More_supers()
	
elif zmode == 84:
	Fan_films()

elif zmode == 85:
	Spider_man()

elif zmode == 86:
	Justice_league()

elif zmode == 87:
	Serial()
	
elif zmode == 88:
	Super_movies()

elif zmode == 89:
	Super_channels()

elif zmode == 90:
	Superdocs()

elif zmode == 91:
	PJ_masks()

elif zmode == 92:
	Misc()

#=====Sports======

elif zmode == 100:
	GameSports()
		
elif zmode == 101:
	Motorsports()		
		
elif zmode == 102:
	Hunting()

elif zmode == 103:
	Eurosports()
	
elif zmode == 104:
	WomensSports()

elif zmode == 105:
	WomensWrestling()

elif zmode == 106:
	SportsWrestling()

elif zmode == 107:
	Docs_sports()
	
elif zmode == 108:
	Fishing()

elif zmode == 109:
	Combat()

#=====MovieChannels======

elif zmode == 110:
	HorrorChannel()
		
elif zmode == 111:
	ScifiChannel()		
		
elif zmode == 112:
	Playlists()

elif zmode == 113:
	MixedChannel()
	
elif zmode == 114:
	AnimeChannel()

elif zmode == 115:
	DocumentaryChannel()

elif zmode == 116:
	ClassicChannel()

elif zmode == 117:
	SportsChannel()
	
elif zmode == 118:
	FamilyChannel()

elif zmode == 119:
	AnimationChannel()

elif zmode == 120:
	LiveChannel()

elif zmode == 121:
	MusicChannel()

elif zmode == 122:
	WrestlingChannel()

#===== J1TV =====

elif zmode == 403:
    movies.movieListing.Genres("All")
	
elif zmode == 404:
    BFgenreList()

elif zmode == 405:
    Channels.channel_list()
	
elif zmode == 406:
    Channels.genres_list()

elif zmode == 407:
    Singles.singles_list()
	
elif zmode == 408:
    Singles.genres_list()

#=========================================

elif zmode == 410:
    movies.movieListing.Genres("Action")

#elif zmode == 411:
    #movies.movieListing.Genres("Animation")

elif zmode == 412:
    movies.movieListing.Genres("Classic")

elif zmode == 413:
    movies.movieListing.Genres("Comedy")

elif zmode == 414:
    movies.movieListing.Genres("Crime")

elif zmode == 415:
    movies.movieListing.Genres("Docs")

elif zmode == 416:
    movies.movieListing.Genres("Drama")

elif zmode == 417:
    movies.movieListing.Genres("Family")

elif zmode == 418:
    movies.movieListing.Genres("Fantasy")

elif zmode == 419:
    movies.movieListing.Genres("Horror")

elif zmode == 420:
    movies.movieListing.Genres("Music")

elif zmode == 421:
    movies.movieListing.Genres("Scifi")

elif zmode == 422:
    movies.movieListing.Genres("Sports")

elif zmode == 423:
    movies.movieListing.Genres("Thriller")

elif zmode == 424:
    movies.movieListing.Genres("Western")

elif zmode == 425:
    movies.movieListing.Genres("Zombie")

elif zmode == 426:
    movies.movieListing.Genres("Anime")

elif zmode == 427:
    movies.movieListing.Genres("Mystery")

#======= MENU =======
	
elif zmode == 502:
    Docula_main()
	
elif zmode == 503:
    Diyfix_main()
	
elif zmode == 504:
    Animate_main()
	
elif zmode == 505:
    Kidzclub_main()
	
elif zmode == 506:
    Bfingers_main()
	
elif zmode == 507:
    Troma_main()
	
elif zmode == 508:
    Super_main()
	
elif zmode == 509:
    Sports_main()
	
elif zmode == 510:
    Channels_main()
	
elif zmode == 511:
    Koding_Settings()

#=========================================
		
elif zmode == 801:
		
	#errorMsg="%s" % (url)
	#xbmcgui.Dialog().ok("url", errorMsg)

	Common.getVID(url)

#=========================================		

elif mode in j1tvlib.Common.get_singles_genres():
    Singles.genre_list(mode)

elif zmode is None and mode is None:
	Main()

else:		

    try: mode in Singles.get_singles(mode)
    except:
        pass	

    try: mode in Channels.get_channel(mode)
    except:
        pass	
		
xbmcplugin.endOfDirectory(plugin_handle)

#----------------------------------------------------------------
# A basic OK Dialog
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()
#----------------------------------------------------------------
# A basic OK Dialog
@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

#if __name__ == "__main__":
#    Run(default='main')
#    xbmcplugin.endOfDirectory(int(sys.argv[1]))