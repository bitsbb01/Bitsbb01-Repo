from slyguy.language import BaseLanguage

class Language(BaseLanguage):
    LIVE_TV     = 30000
    CH_LABEL    = 30001

_ = Language()