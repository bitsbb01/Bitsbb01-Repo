HEADERS = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36',
}

EPG_URL  = 'https://service-channels.clusters.pluto.tv/v1/guide'
PLAY_URL = 'https://service-stitcher.clusters.pluto.tv/stitch/hls/channel/{id}/master.m3u8?terminate=false&deviceType=web&deviceMake=web&deviceModel=web&sid={chno}&deviceId={id}&deviceVersion=DNT&appVersion=DNT&deviceDNT=0&userId=&advertisingId=&deviceLat=&deviceLon=&app_name=&appName=web&buildVersion=&appStoreUrl=&architecture=&includeExtendedEvents=false&marketingRegion=US&serverSideAds=false'
LOGO_URL = 'https://images.pluto.tv/channels/{id}/colorLogoPNG.png'

US = 'us'
UK = 'uk'
LOCAL = 'local'
CUSTOM = 'custom'

X_FORWARDS = {
    US: '185.236.200.172',
    UK: '185.86.151.11',
}

EPG_SCRAPED = {
    US: 'https://i.mjh.nz/PlutoTV/us.xml.gz',
    UK: 'https://i.mjh.nz/PlutoTV/uk.xml.gz',
}

REGIONS = [US, UK, LOCAL, CUSTOM]