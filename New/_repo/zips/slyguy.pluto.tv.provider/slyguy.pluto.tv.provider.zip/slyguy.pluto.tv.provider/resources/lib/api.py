import arrow

from slyguy import settings, mem_cache
from slyguy.session import Session
from slyguy.log import log
from slyguy.mem_cache import cached
from slyguy.exceptions import Error

from .constants import *
from .language import _

class APIError(Error):
    pass

class API(object):
    def new_session(self):
        self._session = Session(HEADERS)
        self._cache_key = self._region  = settings.getEnum('region', REGIONS, default=US)

        if self._region in X_FORWARDS:
            self._session.headers.update({'x-forwarded-for': X_FORWARDS[self._region]})

        elif self._region == CUSTOM:
            region_ip = settings.get('region_ip', '0.0.0.0')
            if region_ip != '0.0.0.0':
                self._session.headers.update({'x-forwarded-for': region_ip})
                self._cache_key = region_ip

    def channels(self):
        channels = mem_cache.get(self._cache_key)
        if channels:
            return channels

        channels = self.epg()
        if not channels:
            raise APIError(_.NO_CHANNELS)

        mem_cache.set(self._cache_key, channels, expires=(60*5))

        return channels

    def epg(self, start=None, stop=None):
        start = start or arrow.now().replace(minute=0, second=0, microsecond=0).to('utc')
        stop  = stop or start.shift(hours=6)

        def get_url(data):
            url = PLAY_URL.format(id=data['id'], chno=data['number'])

            if not data['isStitched']:
                for row in data.get('timelines', []):
                    try: url = row['episode']['sourcesWithClipDetails'][0]['sources'][0]['file']
                    except: pass
                    else: break

            return url

        params = {
            'deviceId': 'aa9b8a31-20b7-4fd6-a2bf-49d3972c6a58',
            'deviceMake': 'Chrome',
            'deviceType': 'web',
            'deviceVersion': '84.0.4147.105',
            'DNT': '0',
            'sid': '07be0e1c-e769-4fed-b880-d3c1684ec6c4',
            'appName': 'web',
            'appVersion': '5.6.0-05e6d11bfce7210bc262d7e9f2a96fc738b8ad86',
        }

        if start: params['start'] = start.format('YYYY-MM-DDTHH:MM:SSZZ')
        if stop: params['stop'] = stop.format('YYYY-MM-DDTHH:MM:SSZZ')

        data = self._session.get(EPG_URL, params=params).json()

        categories = {}
        for row in data.get('categories', []):
            categories[row['id']] = row['name']

        channels = {}
        for row in data.get('channels', []):
            channels[row['id']] = {
                'chno': row['number'], 
                'name': row['name'], 
                'group': categories[row['categoryID']], 
                'logo': LOGO_URL.format(id=row['id']),
                'url': get_url(row),
                'programs': row.get('timelines', []),
            }

        return channels